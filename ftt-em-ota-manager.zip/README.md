
# OTA Support Files for Firmware Updates

## Overview
An Overview OTA (Over-The-Air) update refer to the process of remotely updating firmware, software, or configurations on devices without requiring physical access. These updates are crucial for maintaining security, fixing bugs, and improving functionality. There are two main update features:

1. **Edge Update:**
   - EdgeUpdate leverages deployment files to deploy the latest version of a module through the Azure IoT portal.
   - Briefly, in the Azure IoT portal, you can create a deployment manifest (deployment file) that specifies the desired module version, target devices, and other configuration settings. The IoT Edge runtime then applies this deployment to the specified devices, ensuring they run the updated module.

2. **Non-Edge Update:**
   - Place all OTA support files (except ota_update.sh) in a folder named “ota_packages.”
   - Non-Edge updates require the following folder structure and support packages:
     ```
     ota_update.sh
     ota_packages/
         motor_driver.ko
         hall_sensor.ko
         # Add other files as needed
     ```
   - Compress the contents of the "ota_packages" folder using the "tar.gz" format.
   - Combine the firmware name and version using an underscore ("_") to create the compressed package name. For example:
     - Firmware name: `motor_driver`
     - Firmware version: `V_1_1`
     - Compressed package name: `motor_driver_V_1_1.tar.gz`

> Note: Remember while uploading the package in admin portal firmware name and firmware version should be like above. Otherwise, OTA update will get failed with firmware or version mismatch reasons.

Remember to replace the example values with your actual firmware name and version.

## OTA Update Process
1. **Detection:** The client device periodically checks for updates.
2. **Download:** If an update is available, the client downloads the update package.
3. **Verification:** The client verifies the integrity of the package.
4. **Installation:** The new firmware is installed, often requiring a reboot.

---

Contributor: Vijayapradap M (vijayapradap.m@happiestminds.com)
