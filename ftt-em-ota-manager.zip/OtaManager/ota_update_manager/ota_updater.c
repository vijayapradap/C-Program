/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      ota_updater.c
 * @brief     This module is responsible OTA update for non-edge update 
 * @author    Vijayapradap M
 * @version   1.0
 * @date      August 12 , 2024
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/

#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <sys/reboot.h>

/*=============================================================================
                              Project Includes
==============================================================================*/

#include "parson.h"

/*==============================================================================
                              Private Includes
==============================================================================*/

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/

/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

#define OTA_INFO "/etc/smart_oven/ota/ota_info.json"
#define OTA_PROGRESS "/etc/smart_oven/ota/ota_progress.txt"
#define OTA_STARTER "sh /etc/smart_oven/ota/ota_update.sh"
#define OTA_SCRIPT "/etc/smart_oven/ota/ota_update.sh"
#define OTA_IMAGE_DIR "/etc/smart_oven/ota/"
#define OTA_PACKAGE "/etc/smart_oven/last_update_package/"
#define OTA_LOGFILE "/etc/smart_oven/last_update_package/ota_update_manager.log"

// #define DERR "\x1B[31mERROR\x1B[0m"
// #define DINF "\x1B[32mINFO\x1B[0m"
// #define DWAR "\x1B[33mWARN\x1B[0m"
// #define DDBG "\x1B[34mDEBUG\x1B[0m"

#define DERR "ERROR"
#define DINF "INFO"
#define DWAR "WARN"
#define DDBG "DEBUG"

#define TIMESTAMP_FORMAT "%Y-%m-%d %H:%M:%S.%03d"

#define PRINT(LEVEL, FORMAT, ...) do { \
    time_t now = time(NULL); char timestamp[24], output[1024]; \
    struct tm *tm_info = localtime(&now); \
    strftime(timestamp, sizeof(timestamp), TIMESTAMP_FORMAT, tm_info); \
    sprintf(output, "%s %*s - %s(%i) - " FORMAT, \
    timestamp, -5, LEVEL, __func__, __LINE__, __VA_ARGS__); \
    xlogger(output); printf("%s", output); \
    fflush(stdout); } while(0);

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

typedef struct {
    bool isEdgeUpdate;
    char *pFirmwareName;
    char *pFirmwareVersion;
} ota_info_t;

ota_info_t stOtaInfo;

/*!
 * @brief               This function will store the logging information in file
 *
 * @param[in]           info - logging information to write in log file
 * @param[out]          void - nothing
 *
 * @retval              void
 */
void xlogger(char *info)
{
    if (access(OTA_LOGFILE, F_OK) == -1)
    {
        char *pTemp = NULL;
        asprintf(&pTemp, "sudo touch %s", OTA_LOGFILE);
        if (system(pTemp) != 0)
        {
            fprintf(stderr, "Error: unable to create the log file : %s\n", pTemp);
            free(pTemp);
            return;
        }
        free(pTemp);
    }

    FILE *fptr = NULL;
    fptr = fopen(OTA_LOGFILE, "a");
    if(NULL == fptr) {
        fprintf(stderr, "Error: File not existing or Permission denied\nExiting the program with status 1.\n");
        return;
    }

    fputs(info, fptr);
    fclose(fptr);
}

/*!
 * @brief               This function will looks for ota_info.json and parse details from it
 *
 * @param[in]           void - nothing
 * @param[out]          status - retuns operation success / failure status
 *
 * @retval              0 - success, 0 > failure
 */
int8_t fnParseOtaInfo( void )
{
    JSON_Value* pRecordValue = json_parse_file(OTA_INFO);
    if (pRecordValue == NULL)
    {
        printf("waiting for an update\n");
        // PRINT(DINF, "waiting for an update%s", "\n");

        char *sysCmd = NULL;
        asprintf(&sysCmd, "echo '0' > %s", OTA_PROGRESS);
        if (system(sysCmd) != 0)
        {
            PRINT(DERR, "unable to write fail status in ota_progress.txt%s", "\n");
        }
        free(sysCmd);

        return -1;
    }

    JSON_Object *pResponseObject = json_value_get_object( pRecordValue );

    if (json_object_has_value(pResponseObject, "reboot") == 1)
    {
        PRINT(DINF, "Hostmachine reboot command received%s", "\n\n");

        char *sysCmd = NULL;
        asprintf(&sysCmd, "rm -rf %s*", OTA_IMAGE_DIR);
        if (system(sysCmd) != 0)
        {
            PRINT(DERR, "unable to reset the ota_info.json%s", "\n");
        }
        else
        {
            PRINT(DINF, "successfully reseted the ota_info.json%s", "\n");
        }
        free(sysCmd);

        json_object_clear( pResponseObject );
        json_value_free( pRecordValue );

        FILE * filePtr = popen("test -s /etc/smart_oven/config/privacy_policy.json && echo \"1\" || echo \"0\"", "r");
        if ( filePtr == NULL )
        {
            PRINT(DERR, "file open failed command : %s", "\n");
        }
        else if ((char)fgetc(filePtr) == '0')
        {
            if ( system("nmcli connection delete id $(nmcli -t -f NAME connection show --active)") != 0 ) {
                PRINT(DERR, "unable to reset the save wifi networks%s", "\n");
            } else {
                PRINT(DINF, "successfully reseted the save wifi networks%s", "\n");
            }
            pclose(filePtr);
        }

        sleep(3);
        // Attempt to reboot the system
        if ( reboot(RB_AUTOBOOT) < 0 )
        {
            PRINT(DERR, "unable to reboot the system%s", "\n");
            return -1;
        }
    }

    PRINT(DINF, "New OTA update is available%s", "\n\n");

    stOtaInfo.isEdgeUpdate = json_object_get_boolean(pResponseObject, "is_edge_module");
    asprintf(&stOtaInfo.pFirmwareName, "%s", json_object_get_string(pResponseObject, "firmware_name"));
    asprintf(&stOtaInfo.pFirmwareVersion, "%s", json_object_get_string(pResponseObject, "firmware_version"));

    json_object_clear( pResponseObject );
    json_value_free( pRecordValue );

    PRINT(DINF, "is_edge_module   : %s\n", (stOtaInfo.isEdgeUpdate) ? "true" : "false");
    PRINT(DINF, "firmware_name    : %s\n", stOtaInfo.pFirmwareName);
    PRINT(DINF, "firmware_version : %s\n\n", stOtaInfo.pFirmwareVersion);

    return 0;
}

/*!
 * @brief               This function will check edge update status and progress information
 *
 * @param[in]           pCommand - command to check the iotedge list
 * @param[in]           pSubString - validate the status of updated package
 * @param[out]          status - retuns operation success / failure status
 *
 * @retval              0 - success, 0 > failure
 */
int8_t edgeUpdateManager(const char *pCommand, const char *pSubString)
{
    int8_t i8Ret = -1, percentage = 0;

    FILE *filePtr = NULL;
    char carrTempBuff[ 1024 ], progress[ 100 ];
    filePtr = popen(pCommand, "r");
    if (filePtr == NULL) {
        PRINT(DERR, "popen failed command : %s\n", pCommand);
        return i8Ret;
    }

    while (fgets(carrTempBuff, sizeof(carrTempBuff), filePtr) != NULL)
    {
        if ( strstr(carrTempBuff, pSubString) )
        {
            sprintf(progress, "echo '100' > %s", OTA_PROGRESS);
            if (system(progress) != 0)
            {
                PRINT(DERR, "unable to write ota update progress%s", "\n");
            }
            i8Ret = 0;
        }
        else if (strstr(carrTempBuff, "runningUp"))
        {
            uint8_t sec = 0;
            sscanf(carrTempBuff, "runningUp%hhdseconds", &sec);
            percentage = sec + 30;

            sprintf(progress, "echo '%d' > %s", percentage, OTA_PROGRESS);
            if (system(progress) != 0)
            {
                PRINT(DERR, "unable to write ota update progress%s", "\n");
            }
        }
        else if (strstr(carrTempBuff, "failed"))
        {
            sprintf(progress, "echo '10' > %s", OTA_PROGRESS);
            if (system(progress) != 0)
            {
                PRINT(DERR, "unable to write ota update progress%s", "\n");
            }
        }
        else
        {
            if (strstr(carrTempBuff, "minute") || strstr(carrTempBuff, "hour") || \
                strstr(carrTempBuff, "day") || strstr(carrTempBuff, "week") || strstr(carrTempBuff, "month"))
            {
                sprintf(progress, "echo '100' > %s", OTA_PROGRESS);
                if (system(progress) != 0)
                {
                    PRINT(DERR, "unable to write ota update progress%s", "\n");
                }
                i8Ret = 0;
            }
        }
    }

    pclose(filePtr);
    return i8Ret;
}

/*!
 * @brief               This function gets progress information
 *
 * @param[in]           void - nothing
 * @param[out]          progress - 0 to 100 update progress information
 *
 * @retval              positive - success, 0 > failure
 */
int8_t OTA_fnOtaProgress( void )
{
    char carrTempBuff[ 10 ];
    int8_t i8Percentage = 0;
    FILE* filePtr = popen("cat /etc/smart_oven/ota/ota_progress.txt", "r");

    if (filePtr == NULL) {
        PRINT(DERR, "file open failed command : %s", "\n");
        return -2;
    }

    if (fgets(carrTempBuff, sizeof(carrTempBuff), filePtr) != NULL) {
        i8Percentage = atoi(carrTempBuff);
    }
    pclose(filePtr);

    return i8Percentage;
}

/*!
 * @brief               This function will be responsible for edge and non-edge updates
 *
 * @param[in]           void - nothing
 *
 * @retval              void - nothing
 */
void fnOtaUpdateProgress( void )
{
    char *sysCmd = NULL;
    int8_t i8Ret = 1;
    int progress = 0;

    if (stOtaInfo.isEdgeUpdate)
    {
        uint8_t timeout = 0;
        bool successFlag = false;
        do {
            asprintf(&sysCmd, "iotedge list | grep %s:%s | awk '{print $2 $3 $4 $5}'", stOtaInfo.pFirmwareName, stOtaInfo.pFirmwareVersion);

            if (edgeUpdateManager(sysCmd, "runningUpaminute" ) == 0)
            {
                successFlag = true;
                PRINT(DINF, "image updated successfully%s", "\n");
            }
            else
            {
                PRINT(DINF, "waiting for an update completion%s", "\n");
                sleep(5);
            }

            free(sysCmd);

        } while(!successFlag && timeout++ < 60);
        
        if (successFlag == false) {
            goto failed;
        } 
    }
    else
    {
        sleep(2);
       
        asprintf(&sysCmd, "tar xf %s%s_%s.tar.gz -C %s", OTA_IMAGE_DIR, stOtaInfo.pFirmwareName, stOtaInfo.pFirmwareVersion, OTA_IMAGE_DIR);
        if (system(sysCmd) != 0)
        {
            PRINT(DERR, "unable extract the downloaded ota package\ncmd : %s\n", sysCmd);
            free(sysCmd);
            goto failed;
        }
        else
        {
            PRINT(DINF, "downloaded package extracted successfully : %s\n", sysCmd);
            free(sysCmd);
        }

        sleep(2);

        if (access(OTA_SCRIPT, X_OK) == 0)
        {
            PRINT(DINF, "Shell script already has execute permission.%s", "\n"); 
        }
        else
        {
            if (chmod(OTA_SCRIPT, 0755) == 0) {
                PRINT(DINF, "Execute permission granted to %s.\n", OTA_SCRIPT);
            } else {
                PRINT(DERR, "Error granting execute permission%s", "\n");
                goto failed;
            }
        }

        sleep(2);

        if (system(OTA_STARTER) != 0)
        {
            PRINT(DERR, "unable to start the non-edge ota update%s", "\n");
            goto failed;
        }
        else 
        {
            PRINT(DINF, "ota script executed successfully%s", "\n");

            asprintf(&sysCmd, "rm -rf %s*.tar.gz", OTA_PACKAGE);
            if (system(sysCmd) != 0)
            {
                PRINT(DERR, "unable to remove the previous package : %s\n", sysCmd);
            }
            else
            {
                PRINT(DINF, "successfully removed old packages%s", "\n");
            }
            free(sysCmd);

            asprintf(&sysCmd, "mv %s%s_%s.tar.gz  %s", OTA_IMAGE_DIR, stOtaInfo.pFirmwareName, stOtaInfo.pFirmwareVersion, OTA_PACKAGE);
            if (system(sysCmd) != 0)
            {
                PRINT(DERR, "unable to update the last updated package : %s\n", sysCmd);
            }
            else
            {
                PRINT(DINF, "successfully updated the new updated package%s", "\n");
            }
            free(sysCmd);
        }
    }

    sleep(10);
    goto remove;

failed:

    asprintf(&sysCmd, "echo '-1' > %s", OTA_PROGRESS);
    if (system(sysCmd) != 0)
    {
        PRINT(DERR, "unable to write fail status in ota_progress.txt%s", "\n");
    }
    else
    {
        PRINT(DINF, "successfully written failure information in ota_progress.txt%s", "\n");
    }
    free(sysCmd);
    sleep(10);

remove:

    asprintf(&sysCmd, "rm -rf %s*", OTA_IMAGE_DIR);
    if (system(sysCmd) != 0)
    {
        PRINT(DERR, "unable to reset the ota_info.json%s", "\n");
    }
    else
    {
        PRINT(DINF, "successfully reseted the ota_info.json%s", "\n");
    }
    free(sysCmd);

    free(stOtaInfo.pFirmwareName);
    free(stOtaInfo.pFirmwareVersion);
}

int main()
{
    char *pTemp = NULL;
    if (access(OTA_PACKAGE, F_OK) == -1)
    {
        
        asprintf(&pTemp, "sudo mkdir %s", OTA_PACKAGE);
        if (system(pTemp) != 0)
        {
            PRINT(DERR, "unable to create the last update package folder%s", "\n");
        }
        else
        {
            PRINT(DINF, "successfully created the last update package folder%s", "\n");
        }
        free(pTemp);
    }

    asprintf(&pTemp, "rm -rf %s*", OTA_IMAGE_DIR);
    if (system(pTemp) != 0)
    {
        PRINT(DERR, "unable to reset the ota_info.json%s", "\n");
    }
    else
    {
        PRINT(DINF, "successfully reseted the ota_info.json%s", "\n");
    }
    free(pTemp);

    while(1)
    {
        if (fnParseOtaInfo() == 0)
        {
            fnOtaUpdateProgress();
        }
        sleep(2);
    }
    return 0;
}

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/