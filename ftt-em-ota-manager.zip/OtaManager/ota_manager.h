/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      ota_manager.h
 * @brief     Common header for ota manager
 * @author    Vijayapradap M (vijayapradap.m@happpiestminds.com)
 * @version   1.0
 * @date      July 12, 2024
 *
 ******************************************************************************
 */

#ifndef OTA_COMMON_MODULE_H_
#define OTA_COMMON_MODULE_H_

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "iothub_module_client_ll.h"
#include "iothub_client_options.h"
#include "iothub_message.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "iothubtransportmqtt.h"
#include "iothub.h"
#include "time.h"
#include <sys/time.h>
/*==============================================================================
                              Project Includes
==============================================================================*/
#include "parson.h"
/*==============================================================================
                              Exported Defines
==============================================================================*/

#define DERR "ERROR" ///< Log level ERROR
#define DINF "INFO" ///< Log level INFO
#define DWAR "WARN" ///< Log level WARN
#define DDBG "DEBUG" ///< Log level DEBUG

#define TIMESTAMP_FORMAT "%Y-%m-%d %H:%M:%S.%03d" ///< Timestamp macro with milliseconds
#define UUID_LEN 32 ///< Maximum length of device UUID

extern char xDeviceUUID[UUID_LEN]; ///< @var to keep stored device UUID for logging

/* Macro to log for debugging purposes */
// #define PRINT(LEVEL, FORMAT, ...) printf("%s : %s() in %s, line %i:\t" FORMAT, \
//     LEVEL, __func__, __FILE__, __LINE__, __VA_ARGS__)

// #define PRINT(LEVEL, FORMAT, ...) { printf("%s : %s() in %s, line %i:\t" FORMAT, \
//     LEVEL, __func__, __FILE__, __LINE__, __VA_ARGS__); \
//     fflush(stdout); }

/* Macro to log for debugging purposes */
// #define PRINT(LEVEL, FORMAT, ...) do { \
//     time_t now;  time(&now); \
//     char* timestamp = ctime(&now); \
//     timestamp[strlen(timestamp) - 1] = '\0'; \
//     printf("%s : %s %s() in %s, line %i:\t" FORMAT, \
//     LEVEL, timestamp, __func__, __FILE__, __LINE__, __VA_ARGS__); \
//     fflush(stdout); } while(0);

#define PRINT(LEVEL, FORMAT, ...) do { \
    time_t now = time(NULL); char timestamp[24]; \
    struct tm *tm_info = localtime(&now); \
    if ( xDeviceUUID[0] == '\0' ) OTA_fnGetDeviceUUID(); \
    strftime(timestamp, sizeof(timestamp), TIMESTAMP_FORMAT, tm_info); \
    printf("%s %*s-{deviceId:%s} - %s(%i) - " FORMAT, \
    timestamp, -5, LEVEL, xDeviceUUID, __func__, __LINE__, __VA_ARGS__); \
    fflush(stdout); } while(0); ///< Macro for logging events with timestamp, device UUID, function, line and event message

/*==============================================================================
                              Exported Macros
==============================================================================*/

#define RESULT_OK                   200 ///< Direct method result OK
#define RESULT_PARTIAL_CONTENT      206 ///< Direct method failed with Paritial content
#define RESULT_BAD_REQUEST          400 ///< Direct method failed with Bad request
#define RESULT_METHOD_NOT_ALLOWED   405 ///< Direct method failed with Method not allowed
#define RESULT_NOT_ACCEPTABLE       406 ///< Direct method failed with Not acceptable

// #define RESULT_OK                   200 ///< Direct method result OK
// #define RESULT_PARTIAL_CONTENT      -1 ///< Direct method result failure
// #define RESULT_BAD_REQUEST          -1 ///< Direct method result failure
// #define RESULT_METHOD_NOT_ALLOWED   -1 ///< Direct method result failure
// #define RESULT_NOT_ACCEPTABLE       -1 ///< Direct method result failure

#define OTA_UPDATE_REQUEST	        1001 ///< OTA Update available req msgID from Device Manager
#define OTA_UPDATE_REQUEST_ACK		1002 ///< OTA Update receive ack msgID to Device Manager
#define OTA_UPDATE_STARTED			1003 ///< OTA Update started msgID to Device Manager (user accepted)
#define OTA_UPDATE_STARTED_ACK      1004 ///< OTA Update started ack msgID from Device Manager
#define OTA_UPDATE_PROGRESS			1005 ///< OTA Update inprocess msgID to Device Manager
#define OTA_UPDATE_PROGRESS_ACK     1006 ///< OTA Update inprocess ack msgID from Device Manager
#define OTA_UPDATE_COMPLETED		1007 ///< OTA Update completed msgID to Device Manager
#define OTA_UPDATE_COMPLETED_ACK    1008 ///< OTA Update completed ack msgID from Device Manager
#define OTA_UPDATE_FAILED			1009 ///< OTA Update failed msgID to Device Manager
#define OTA_UPDATE_FAILED_ACK       1010 ///< OTA Update failed ack msgID from Device Manager

#define OTA_UPDATE_REQ_TO_UI        1011 ///< OTA Update available msgID to UI
#define OTA_UPDATE_REQ_UI_ACK       1012 ///< OTA Update receive ack msgID from UI
#define OTA_UPDATE_PROG_TO_UI       1013 ///< OTA Update inprocess msgID to UI
#define OTA_UPDATE_PROG_UI_ACK      1014 ///< OTA Update inprocess ack msgID from UI
#define OTA_UPDATE_SUCCESS_TO_UI    1015 ///< OTA Update success msgID to UI
#define OTA_UPDATE_SUCCESS_UI_ACK   1016 ///< OTA Update success ack msgID from UI
#define OTA_UPDATE_FAILURE_TO_UI    1017 ///< OTA Update failure msgID to UI
#define OTA_UPDATE_FAILURE_UI_ACK   1018 ///< OTA Update failure ack msgID from UI
#define HOSTMACHINE_REBOOT          1019 ///< hostmachine reboot either factory reset or ota
#define HOSTMACHINE_REBOOT_ACK      1020 ///< ack for hostmachine reboot either factory reset or ota

/* Route at which ota service reads the messages published from other modules */
#define OTA_INPUT_ROUTE "ota_manager_in" ///< OTA manager input route for receive messages

/* Route at which ota service publishes the messages to other Modules */
#define OTA_OUTPUT_ROUTE "ota_manager_out" ///< OTA manager output route for sent messages

/* ota service method name to communicate through direct method  */
#define OTA_DIRECT_METHOD "method_ota_manager" ///< OTA manager method name to receive direct method messages

/*==============================================================================
                              Exported Enums
==============================================================================*/

/// @brief Methods implemented in OTA Manager for communication @enum eMethod_t
typedef enum {
    eDirectMethod, ///< method direct enumerator
    eRouteMethod ///< method route enumerator
} eMethod_t;

/// @brief While OTA update these are the possible status ota_manager must report. @enum eStatusCode_t
typedef enum {
    eUpdatedSuccessfully = 0, ///< ota proccess completed successfully
    eDownloadInprocess, ///< ota package downloading inprocess from blob
    eDownloadFailed, ///< ota package download failed from blob
    eDownloadSuccess, ///< ota package downloaded successfully
	eUpdateInprocess, ///< ota image update inprocess
	eTimeoutFailure, ///< ota image update failure with timeout
	eRetryFailure, ///< ota image update failed with retry
	ePermissionDenied, ///< ota image update failed with permission issues
	eFileCorrupted, ///< ota image update failed with corrupted file
	eChecksumMismatch, ///< ota image update failed with checksum mismatch
	eFilenameMismatch, ///< ota image failed with filename mismatch
	eVersionMismatch, ///< ota image failed with version mismatch
	eInvalidBlobUrl, ///< ota image failed with invalid blob url
    eRetryAttempt ///< ota image failed and attempting retry
} eStatusCode_t;

/// @brief Possible responses from Fourground services (user) @enum eUserRes_t
typedef enum {
    eAccepted, ///< user accepted the update
    eCookingInprocess, ///< cooking inprocess 
    eRemindLater, ///< user pressed remind me later
    eIdleTimeUpdateAccepted, ///< user accepted the idle time update
    eIdleUpdateAccepted, ///< idle time accepted for further update
    eUpdateAvail ///< default flag updated after update
} eUserRes_t;

/*==============================================================================
                              Exported Structures
==============================================================================*/
/// @struct otaImageInfo_t @brief structure for load all image data for execution
typedef struct
{
    bool bIsImageTypeEdge; ///< boolean to store firmware type edge or non-edge
    char *pUpdateInfo; ///< brief information about the ota update
    bool bUserAcceptance; ///< user acceptance flag for further update
    uint8_t u8UserResponse; ///< user responses @ref @enum eUserRes_t

    /// @struct stEdgeInfo @brief structure to store edge image details
    struct {
        char *pEdgeSolutions; ///< edge firmware name info
        char *pEdgeSolutionVersion; ///< edge firmware version info
    } stEdgeInfo;
    
    /// @struct stFirmwareInfo @brief structure to store non-edge image details
    struct {
        char *pVersion; ///< non-edge firmware version info
        char *pFileName; ///< non-edge firmware name info
        char *pBlobUrl; ///< non-edge firmware blob url info to download package
        char *pChecksum; ///< non-edge firmware checksum info
        uint8_t u8TimeoutTime; ///< non-edge firmware download package timeout in sec
        uint8_t u8RetryCount; ///< non-edge firmware download package retry count
        uint8_t u8RetryInterval; ///< non-edge firmware retry interval in min
    } stFirmwareInfo;

} otaImageInfo_t;

/// @struct stErrCodeMsg_t @brief structure to store error code and corresponding error messages
typedef struct {
    eStatusCode_t eStatusCode; ///< ota update error codes
    char *pStatusMsg; ///< brief message of all error codes
} stErrCodeMsg_t;

/*==============================================================================
                              Exported functions prototypes
==============================================================================*/
/**
 * @brief This function for get device UUID
 * 
 * @param[out] xDeviceUUID UUID stored in this variable
 */
void OTA_fnGetDeviceUUID( void );

/**
 * @brief This function for get current epoch timestamp
 * 
 * @param[out] uint64_t it returns the current epoch timestamp with milliseconds
 * @return uint64_t it returns the current epoch timestamp with milliseconds
 */
uint64_t OTA_fnEpochTimestamp(void);

/**
 * @brief This function for get iothub client handle
 * 
 * @param[out] IOTHUB_MODULE_CLIENT_LL_HANDLE returns the IoT Hub assigned handle
 * @return IOTHUB_MODULE_CLIENT_LL_HANDLE the IoT Hub assigned handle
 */
IOTHUB_MODULE_CLIENT_LL_HANDLE OTA_fnGetHandle( void );

/**
 * @brief This function for publish the given data to given route
 * 
 * @param[in] iotHubModuleClientHandle IOTHUB_MODULE_CLIENT_LL_HANDLE IoT hub handle
 * @param[in] pJsonMessage information / data need to publish through route
 * @param[in] pOutputRoute route information to publish the data
 * 
 * @return IOTHUBMESSAGE_DISPOSITION_RESULT indicating how client has acknowledged the incoming device-to-cloud message.
 */
IOTHUBMESSAGE_DISPOSITION_RESULT OTA_fnPublishingData(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle, const char *pJsonMessage, const char *pOutputRoute);

/**
 * @brief This function for controls all update selection and execution
 * 
 * @param[in] eMethod enum parameter for select the method / route
 * @param[in] pReceivedJsonMessage data from callback from route / direct method
 * @param[out] response return data or reponse for direct method
 * @param[out] response_size return data or response size for direct method
 * @return 0 or 200 indicates success and 0 > || < 0 failure
 */
int16_t OTA_fnOtaUpdateHandler( eMethod_t eMethod, const unsigned char *pReceivedJsonMessage, unsigned char **response, size_t *response_size );

/**
 * @brief Thread initiated for non-edge package download and possible error checks
 * 
 * @param[in] argv  Argument params that passed to this thread. NULL is here
 * @return 0 indicates success and 0 > || 0 < failure
 */
int OTA_fnNonEdgeHandler( void *argv );

/**
 * @brief Thread initiated to get the connection on IoT-Hub
 * 
 * @param[in] argv  Argument params that passed to this thread. NULL is here
 * @return int 0 indicates success and 0 > || 0 < failure
 */
int OTA_fnIotHubInitHandler( void *argv );

/*==============================================================================
                              Footer
==============================================================================*/

#endif /* OTA_COMMON_MODULE_H_ */

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/