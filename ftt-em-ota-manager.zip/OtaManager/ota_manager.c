/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      ota_manager.c
 * @brief     This module is responsible for OTA update functionalities
 * @author    Vijayapradap M (vijayapradap.m@happiestminds.com)
 * @version   1.0
 * @date      July 12 , 2024
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/
#define _GNU_SOURCE

#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/stat.h>

/*=============================================================================
                              Project Includes
==============================================================================*/

#include "ota_manager.h"

/*==============================================================================
                              Private Includes
==============================================================================*/

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/

/// @brief @var @struct otaImageInfo_t declaration for further use
static otaImageInfo_t stOtaImageInfo;
/// @brief @var @enum eStatusCode_t for update status code returns
volatile eStatusCode_t eOtaUpdateStatus;
/// @brief @var package download from blob trigger flag
static bool gbBlobDownloadFlag = false;
/// @brief @var package download status flag
static bool gbDownloadSuccess = false;
/// @brief @var register timer enable flag
static bool bTimerRegister = false;

/// @brief @struct stErrCodeMsg_t stored possible status code and brief info
static stErrCodeMsg_t stErrCodeMsg[] = {
    {   eUpdatedSuccessfully,   "Update updated successfully" },
    {   eDownloadInprocess,     "Image download inprocess" },
    {   eDownloadFailed,        "Image download failed" },
    {   eDownloadSuccess,       "Image downloaded successfully" },
	{   eUpdateInprocess,       "Image update inprocess" },
	{   eTimeoutFailure,        "Update failed : timeout" },
	{   eRetryFailure,          "Update failed : retry " },
	{   ePermissionDenied,      "Update failed : permission denied" },
	{   eFileCorrupted,         "Update failed : file corrupted" },
	{   eChecksumMismatch,      "Update failed : checksum mismatch" },
	{   eFilenameMismatch,      "Update failed : filename mismatch" },
	{   eVersionMismatch,       "Update failed : version mismatch" },
	{   eInvalidBlobUrl,        "Update failed : blob url invalid" },
    {   eRetryAttempt,          "Image download retry attempt" },
};

/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

/// @brief Timer handler for notifying update interval basis
/// @param signum Here is SIGALRM
void OTA_fnWatchDogHandler( int signum );

/// @brief Function to read the progress status information 
/// @return progress and status of an ota update
int8_t OTA_fnOtaProgress( void );

/// @brief Function writes the ota information in ota_info.json
void OTA_fnUpdateOtaInfo( void );

/// @brief Function writes last updated ota info locally
/// @return 0 - success, -1 - failure 
int8_t OTA_fnOtaUpdatedInfo( void );

/// @brief Function updates the updated version in device_config.json
void OTA_fnOtaUpdatedVersion( void );

/// @brief Function read last updated ota info locally
/// @return 0 - success, -1 - failure
int8_t OTA_fnReadLastOtaInfo( void );

/// @brief Function perform linux commands and validate with given value
/// @param pCommand linux command to execute
/// @param pSubString value need to validate with the command
/// @return 0 - success, -1 - failure
static int8_t OTA_fnSystemCommand(const char *pCommand, const char *pSubString);

/// @brief Function to structure json formatted data using passing argument for route / direct message
/// @param[in] u16Cmd route_message_id to sent message
/// @param[in] bStatus status code along with message. cpCommand must be NULL for status
/// @param[in] cpCommand command information need to pass along with message
/// @param[out] deviceMethodResponse get structured json message with all information
void OTA_fnSentResponse ( uint16_t u16Cmd, bool bStatus, char* cpCommand, char **deviceMethodResponse );

/// @brief Function to structure json formatted data using passing argument for progress update
/// @param[in] u16Cmd route_message_id to sent message
/// @param[in] u8Progress progress data on update process
/// @param[in] pStatus status info on update process
/// @param[out] deviceMethodResponse get structured json message with all information
void OTA_fnUpdateProgress ( uint16_t u16Cmd, uint8_t u8Progress, char *pStatus, char **deviceMethodResponse );

/// @brief Function to structure json formatted data using passing argument for reported properties sent
/// @param u8Progress progress data on update process
/// @param eStatusCode possible status code from stErrCodeMsg
/// @param pStatusMsg corresponding status code message from stErrCodeMsg
/// @param deviceMethodResponse get structured json message with all information
void OTA_fnSendReportedProperties( uint8_t u8Progress, eStatusCode_t eStatusCode, char *pStatusMsg, char **deviceMethodResponse );

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void OTA_fnWatchDogHandler( int signum )
{
    (void)signum;

    char *pAckResponse = NULL;
    OTA_fnSentResponse( OTA_UPDATE_REQ_TO_UI, 0, stOtaImageInfo.pUpdateInfo, &pAckResponse );
    OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
    free(pAckResponse);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
uint64_t OTA_fnEpochTimestamp( void )
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t OTA_fnOtaUpdatedInfo( void )
{
    FILE* file = fopen("OtaUpdate.dat", "w");
    if (file != NULL) {
        fwrite(&stOtaImageInfo, sizeof(stOtaImageInfo), 1, file);
        fclose(file);
        PRINT(DINF, "Successfully saved last update info%s", "\n");
        return 0;
    
    } else {
        PRINT(DERR, "Failed to save update info%s", "\n");
        return -1;
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t OTA_fnReboot( void )
{
    const char *json_content = "{\"reboot\":true}";
    FILE *file = fopen("/tmp/storage/ota_info.json", "w");
    if (file != NULL) {
        fprintf(file, "%s", json_content);
        fclose(file);
        PRINT(DINF, "Successfully initiated hostmachine reboot%s", "\n");
        return 0;
    } else {
        PRINT(DERR, "Failed to initiated hostmachine reboot%s", "\n");
        return 1;
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void OTA_fnOtaUpdatedVersion( void )
{
    char *pmodule = NULL;
    JSON_Value* pDeviceValue = json_parse_file("/var/tmp/device_config.json");

    if ( pDeviceValue == NULL) {
        PRINT(DERR, "unable to find the device_config.json file%s", "\n");
    } else {
        if (system("rm -f /var/tmp/device_config.json") == 0) {
            PRINT(DINF, "successfully removed old file%s", "\n");
        } else {
            PRINT(DERR, "Failed to remove old file%s", "\n");
        }

        JSON_Object* pDeviceObject = json_value_get_object( pDeviceValue );
        asprintf(&pmodule, "software_version.%s", stOtaImageInfo.stEdgeInfo.pEdgeSolutions );
        PRINT(DINF, "path : %s and version : %s\n", pmodule, stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion);
        json_object_dotset_string(pDeviceObject, pmodule, stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion );
        if (json_serialize_to_file_pretty(pDeviceValue, "/var/tmp/device_config.json") == 0) {
		    PRINT(DINF, "successfully updated the version in device_config.json file%s", "\n");
        } else {
            PRINT(DERR, "Failed to update version in device_config.json file%s", "\n");
        }
        free(pmodule);
	    json_value_free( pDeviceValue );
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t OTA_fnReadLastOtaInfo( void )
{
    otaImageInfo_t tempOtaImageInfo;
    FILE* file = fopen("OtaUpdate.dat", "r");
    if (file != NULL) {
        fread(&tempOtaImageInfo, sizeof(tempOtaImageInfo), 1, file);
        fclose(file);
        PRINT(DINF, "Successfully read last update info%s", "\n");

    } else {
        PRINT(DERR, "There is no last OTA update%s", "\n");
        return -1;
    }

    PRINT(DINF, "************** Last Update Information **************%s", "\n");
    PRINT(DINF, "Description : %s\n", tempOtaImageInfo.pUpdateInfo);
    PRINT(DINF, "Version     : %s\n", (tempOtaImageInfo.bIsImageTypeEdge) ? tempOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion : tempOtaImageInfo.stFirmwareInfo.pVersion);
    PRINT(DINF, "**************************END************************%s", "\n");

    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void OTA_fnSentResponse ( uint16_t u16Cmd, bool bStatus, char* cpCommand, char **deviceMethodResponse ) {
    
    JSON_Value *pResonseValue = json_value_init_object();
    JSON_Object *pResponseObject = json_value_get_object( pResonseValue );

    json_object_set_number(pResponseObject, "route_message_id", u16Cmd);
    if (cpCommand == NULL) {
        json_object_set_number(pResponseObject, "status", bStatus );
    } else {
        json_object_set_string(pResponseObject, "command", cpCommand);
    }
    json_object_set_number(pResponseObject, "timestamp", OTA_fnEpochTimestamp());

    asprintf(*(&deviceMethodResponse), "%s", json_serialize_to_string_pretty(pResonseValue));
    
    json_object_clear(pResponseObject);
    json_value_free(pResonseValue);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void OTA_fnUpdateProgress ( uint16_t u16Cmd, uint8_t u8Progress, char *pStatus, char **deviceMethodResponse ) {
    
    JSON_Value *pResonseValue = json_value_init_object();
    JSON_Object *pResponseObject = json_value_get_object( pResonseValue );

    json_object_set_number(pResponseObject, "route_message_id", u16Cmd);
    json_object_set_number(pResponseObject, "progress", u8Progress);
    json_object_set_string(pResponseObject, "status", pStatus );
    json_object_set_number(pResponseObject, "timestamp", OTA_fnEpochTimestamp());

    asprintf(*(&deviceMethodResponse), "%s", json_serialize_to_string_pretty(pResonseValue));
    
    json_object_clear(pResponseObject);
    json_value_free(pResonseValue);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void OTA_fnSendReportedProperties( uint8_t u8Progress, eStatusCode_t eStatusCode, char *pStatusMsg, char **deviceMethodResponse ) {
    
    JSON_Value *pResonseValue = json_value_init_object();
    JSON_Object *pResponseObject = json_value_get_object( pResonseValue );
    uint16_t u16RouteId;

    if ( eStatusCode >= eDownloadInprocess && eStatusCode <= eDownloadSuccess )
        u16RouteId = OTA_UPDATE_STARTED;
    else if ( u8Progress == 0 && eStatusCode == eUpdateInprocess )
        u16RouteId = OTA_UPDATE_STARTED;
    else if ( u8Progress > 0 && eStatusCode == eUpdateInprocess )
        u16RouteId = OTA_UPDATE_PROGRESS;
    else if ( eStatusCode > eUpdateInprocess )
        u16RouteId = OTA_UPDATE_FAILED;
    else
        u16RouteId = OTA_UPDATE_COMPLETED;

    json_object_set_number(pResponseObject, "route_message_id", u16RouteId);

    if ( stOtaImageInfo.bIsImageTypeEdge ) {
        json_object_dotset_string(pResponseObject, "ota_update.firmware_name", stOtaImageInfo.stEdgeInfo.pEdgeSolutions);
        json_object_dotset_string(pResponseObject, "ota_update.firmware_version", stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion);
    } else {
        json_object_dotset_string(pResponseObject, "ota_update.firmware_name", stOtaImageInfo.stFirmwareInfo.pFileName);
        json_object_dotset_string(pResponseObject, "ota_update.firmware_version", stOtaImageInfo.stFirmwareInfo.pVersion);
    }
    json_object_dotset_boolean(pResponseObject, "ota_update.is_user_accepted", ( stOtaImageInfo.u8UserResponse == eAccepted ) ? true : false );
    json_object_dotset_number(pResponseObject, "ota_update.progress", u8Progress);

    json_object_dotset_number(pResponseObject, "ota_update.update_status.status_code", eStatusCode);
    json_object_dotset_string(pResponseObject, "ota_update.update_status.message", pStatusMsg);
    json_object_set_number(pResponseObject, "timestamp", OTA_fnEpochTimestamp());

    asprintf(*(&deviceMethodResponse), "%s", json_serialize_to_string_pretty(pResonseValue));

    json_object_clear(pResponseObject);
    json_value_free(pResonseValue);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int16_t OTA_fnOtaUpdateHandler( eMethod_t eMethod, const unsigned char *pReceivedJsonMessage, unsigned char **response, size_t *response_size ) {

    uint16_t u16Ret = 0, u16RouteMessageId = 0;
    bool bStatus = false, bUpdateFailed = false;
    char *pAckResponse = NULL;

    /* JSON objects to parse the incoming Desired Properties from the Cloud */
    JSON_Value* pRootValue = NULL, *pResonseValue = json_value_init_object();
    JSON_Object* pRootObject = NULL, *pResponseObject = json_value_get_object( pResonseValue );

    pRootValue = json_parse_string( (const char *) pReceivedJsonMessage );

    pRootObject = json_value_get_object( pRootValue );
    u16RouteMessageId = json_object_get_number( pRootObject ,"route_message_id" );

    switch( u16RouteMessageId ) {

        case OTA_UPDATE_REQUEST:

            // OTA_fnReadLastOtaInfo();
            pRootObject = json_object_get_object( pRootObject, "ota_update" );

            stOtaImageInfo.bIsImageTypeEdge = json_object_get_boolean( pRootObject ,"is_iot_edge" );
            PRINT(DINF, "Update request received from cloud %s", "\n");

            if ( stOtaImageInfo.bIsImageTypeEdge ) {

                asprintf(&stOtaImageInfo.stEdgeInfo.pEdgeSolutions, "%s", json_object_get_string(pRootObject, "firmware_name"));
                asprintf(&stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion, "%s", json_object_get_string(pRootObject, "firmware_version"));

                if ( stOtaImageInfo.stEdgeInfo.pEdgeSolutions == NULL || stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion == NULL )
                {
                    OTA_fnSentResponse( OTA_UPDATE_REQUEST_ACK, 1, NULL, &pAckResponse );
                    OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                    if (eMethod == eDirectMethod) {
                        char *deviceMethodResponse = pAckResponse;
                        *response_size = strlen(deviceMethodResponse);
                        *response = (unsigned char *)malloc(*response_size);
                        (void)memcpy(*response, deviceMethodResponse, *response_size);
                    }
                    free(pAckResponse);
                    u16Ret = RESULT_PARTIAL_CONTENT;
                    goto cleanBuild;
                }
                bStatus = true;
                
            } else {

                asprintf(&stOtaImageInfo.stFirmwareInfo.pFileName, "%s", json_object_get_string(pRootObject, "firmware_name"));
                asprintf(&stOtaImageInfo.stFirmwareInfo.pVersion, "%s", json_object_get_string(pRootObject, "firmware_version"));
                asprintf(&stOtaImageInfo.stFirmwareInfo.pChecksum, "%s", json_object_get_string(pRootObject, "md5sum_checksum"));
                asprintf(&stOtaImageInfo.stFirmwareInfo.pBlobUrl, "%s", json_object_get_string(pRootObject, "blob_url"));

                stOtaImageInfo.stFirmwareInfo.u8TimeoutTime = json_object_get_number(pRootObject, "timeout_time");
                stOtaImageInfo.stFirmwareInfo.u8RetryCount = json_object_get_number(pRootObject, "fail_retry_count");
                stOtaImageInfo.stFirmwareInfo.u8RetryInterval = json_object_get_number(pRootObject, "fail_retry_interval");

                if ( stOtaImageInfo.stFirmwareInfo.pVersion == NULL || stOtaImageInfo.stFirmwareInfo.pFileName == NULL ||
                    stOtaImageInfo.stFirmwareInfo.pBlobUrl == NULL || stOtaImageInfo.stFirmwareInfo.pChecksum == NULL )
                {
                    OTA_fnSentResponse( OTA_UPDATE_REQUEST_ACK, 1, NULL, &pAckResponse );
                    OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                    if (eMethod == eDirectMethod) {
                        char *deviceMethodResponse = pAckResponse;
                        *response_size = strlen(deviceMethodResponse);
                        *response = (unsigned char *)malloc(*response_size);
                        (void)memcpy(*response, deviceMethodResponse, *response_size);
                    }
                    free(pAckResponse);
                    u16Ret = RESULT_PARTIAL_CONTENT;
                    goto cleanBuild;
                }
                bStatus = true;
            }

            if ( bStatus ) {
                asprintf(&stOtaImageInfo.pUpdateInfo, "%s", json_object_get_string(pRootObject, "update_description"));
                stOtaImageInfo.bUserAcceptance = json_object_get_boolean( pRootObject ,"user_acceptance" );
                stOtaImageInfo.u8UserResponse = eUpdateAvail;
            }

            if ( stOtaImageInfo.bIsImageTypeEdge ) {
                OTA_fnSentResponse( OTA_UPDATE_REQ_TO_UI, 0, stOtaImageInfo.pUpdateInfo, &pAckResponse );
                OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                free(pAckResponse);

                gbBlobDownloadFlag = false;
            }
            else {
                gbBlobDownloadFlag = true;
            }

            OTA_fnSentResponse( OTA_UPDATE_REQUEST_ACK, (bStatus) ? 0 : 1, NULL, &pAckResponse );
            u16Ret = RESULT_OK;

            break;

        case OTA_UPDATE_REQ_UI_ACK:

            stOtaImageInfo.u8UserResponse = (uint8_t)json_object_get_number( pRootObject ,"status" );

            if( stOtaImageInfo.u8UserResponse != eAccepted && stOtaImageInfo.u8UserResponse != eIdleUpdateAccepted )
            {
                char *pTemp = NULL;

                asprintf(&pTemp, "%s", (stOtaImageInfo.u8UserResponse == 1) ? "Cooking inprogress" : \
                    (stOtaImageInfo.u8UserResponse == 2) ? "Remind later" : "Idle time update accepted");

                PRINT(DINF, "User / UI response for update %d : %s\n", stOtaImageInfo.u8UserResponse, pTemp);

                if ( stOtaImageInfo.u8UserResponse == eCookingInprocess || stOtaImageInfo.u8UserResponse == eRemindLater ) { 
                    if (!bTimerRegister) {
                        signal( SIGALRM, OTA_fnWatchDogHandler );
                        bTimerRegister = true;
                    }
                    alarm(3600);
                    // alarm(120);
                }

                free(pTemp);
                goto no_reply;

            } else {

                PRINT(DINF, "Request accepted by user%s", "\n");

                OTA_fnUpdateOtaInfo();

                eOtaUpdateStatus = eUpdateInprocess;
                OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                free(pAckResponse);

                OTA_fnUpdateProgress( OTA_UPDATE_PROG_TO_UI, 0 , stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
            }
            u16Ret = RESULT_OK;
            break;
        case OTA_UPDATE_STARTED_ACK:
            if ( gbBlobDownloadFlag || (json_object_get_number( pRootObject ,"status" ) != 0 && !stOtaImageInfo.bIsImageTypeEdge) )
            {
                OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                goto exit;
            }
            else if ( (!gbBlobDownloadFlag && !gbDownloadSuccess) && ( !stOtaImageInfo.bIsImageTypeEdge) )
            {
                PRINT(DERR, "Non-edge update image download failed. Clearing image details %s", "\n");
                goto cleanAll;
            }
            else if (eOtaUpdateStatus == eDownloadSuccess)
            {
                goto no_reply;
            }
        case OTA_UPDATE_PROG_UI_ACK:
        case OTA_UPDATE_PROGRESS_ACK:

            if ( json_object_get_number( pRootObject ,"status" ) != 0 )
            {
                if ( u16RouteMessageId == OTA_UPDATE_PROGRESS_ACK ) {
                    OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                } else {
                    OTA_fnUpdateProgress( OTA_UPDATE_PROG_TO_UI, 0 , stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                }
            }
            else
            {
                int8_t i8Percentage = OTA_fnOtaProgress();

                if (i8Percentage < 0)
                {
                    if (i8Percentage == -1)
                        eOtaUpdateStatus = eFileCorrupted;

                    if ( u16RouteMessageId == OTA_UPDATE_PROG_UI_ACK )
                        OTA_fnUpdateProgress( OTA_UPDATE_FAILURE_TO_UI, i8Percentage , stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                    
                    if ( u16RouteMessageId == OTA_UPDATE_PROGRESS_ACK)
                        bUpdateFailed = true;
                }
                else if (i8Percentage == 100)
                {
                    eOtaUpdateStatus = eUpdatedSuccessfully;
                    OTA_fnOtaUpdatedVersion();
                    if ( u16RouteMessageId == OTA_UPDATE_PROG_UI_ACK )
                        OTA_fnUpdateProgress( OTA_UPDATE_SUCCESS_TO_UI, i8Percentage , stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                }
                else
                {
                    eOtaUpdateStatus = eUpdateInprocess;
                    if ( u16RouteMessageId == OTA_UPDATE_PROG_UI_ACK )
                        OTA_fnUpdateProgress( OTA_UPDATE_PROG_TO_UI, i8Percentage , stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                }
                if ( u16RouteMessageId == OTA_UPDATE_PROGRESS_ACK || u16RouteMessageId == OTA_UPDATE_STARTED_ACK)
                    OTA_fnSendReportedProperties( i8Percentage, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
            }
            u16Ret = RESULT_OK;
            break;
        case OTA_UPDATE_COMPLETED_ACK:
        case OTA_UPDATE_SUCCESS_UI_ACK:
        case OTA_UPDATE_FAILED_ACK:
        case OTA_UPDATE_FAILURE_UI_ACK:
            u16Ret = RESULT_OK;
            goto no_reply;
            break;
        case HOSTMACHINE_REBOOT:
            PRINT(DINF, "Hostmachine Reboot command received :%d\n", u16RouteMessageId);
            u16Ret = OTA_fnReboot();
            OTA_fnSentResponse( HOSTMACHINE_REBOOT_ACK, (bool)u16Ret, NULL, &pAckResponse );
            u16Ret = RESULT_OK;
            break;
        default:
        {
            char *invalid = NULL;
            asprintf( &invalid, "Invalid request ID :%d", u16RouteMessageId );
            PRINT(DERR, "Invalid request ID :%d\n", u16RouteMessageId);
            OTA_fnSentResponse( 10101, 0, invalid, &pAckResponse );
            free(invalid);
            u16Ret = RESULT_BAD_REQUEST;
            break;
        }
    }

exit:

    if ( eMethod == eDirectMethod )
    {
        char *deviceMethodResponse = pAckResponse;
        *response_size = strlen(deviceMethodResponse);
        *response = (unsigned char *)malloc(*response_size);
        (void)memcpy(*response, deviceMethodResponse, *response_size);
    }
    else
    {
        OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
    }
    free(pAckResponse);

    if (!bUpdateFailed)
        return u16Ret;

cleanAll:

    /* cleaning allocated memory in description pointers */
    if (stOtaImageInfo.pUpdateInfo != NULL)
        free(stOtaImageInfo.pUpdateInfo);
    else
        goto no_reply;

cleanBuild:

    if ( stOtaImageInfo.bIsImageTypeEdge ) {
        /* cleaning allocated memory in edge solutions pointers */
        if (stOtaImageInfo.stEdgeInfo.pEdgeSolutions != NULL)
        {
            free(stOtaImageInfo.stEdgeInfo.pEdgeSolutions);
            free(stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion);
        }
    } else {
        /* cleaning allocated memory in build details pointers */
        if (stOtaImageInfo.stFirmwareInfo.pBlobUrl != NULL)
        {
            free(stOtaImageInfo.stFirmwareInfo.pBlobUrl);
            free(stOtaImageInfo.stFirmwareInfo.pChecksum);
            free(stOtaImageInfo.stFirmwareInfo.pFileName);
            free(stOtaImageInfo.stFirmwareInfo.pVersion);
        }
    }

no_reply:

    return u16Ret;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int8_t OTA_fnSystemCommand(const char *pCommand, const char *pSubString) {
    int8_t i8Ret = 1;

    FILE *filePtr = NULL;
    char carrTempBuff[ 1024 ];
    filePtr = popen(pCommand, "r");
    if (filePtr == NULL) {
        PRINT(DERR, "file open failed command : %s\n", pCommand);
        return 1;
    }
    while (fgets(carrTempBuff, sizeof(carrTempBuff), filePtr) != NULL)
    {
        if ( strstr(carrTempBuff, pSubString) )
        {
            PRINT(DINF, "command : %s executed successfully\n", pCommand);
            i8Ret = 0;
            break;
        }
    }
    if ( i8Ret )
        PRINT(DINF, "command : %s failed to execute\n", pCommand);

    pclose(filePtr);
    return i8Ret;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t OTA_fnOtaProgress( void ) {

    char carrTempBuff[ 10 ];
    int8_t i8Percentage = 0;
    FILE* filePtr = popen("cat /tmp/storage/ota_progress.txt", "r");

    if (filePtr == NULL) {
        PRINT(DERR, "file open failed command : %s", "\n");
        return -2;
    }

    if (fgets(carrTempBuff, sizeof(carrTempBuff), filePtr) != NULL) {
        i8Percentage = atoi(carrTempBuff);
    }
    pclose(filePtr);

    return i8Percentage;
}

void OTA_fnUpdateOtaInfo( void )
{
    JSON_Value *pResonseValue = json_value_init_object();
    JSON_Object *pResponseObject = json_value_get_object( pResonseValue );

    json_object_set_boolean(pResponseObject, "is_edge_module", stOtaImageInfo.bIsImageTypeEdge);

    if (stOtaImageInfo.bIsImageTypeEdge) {

        json_object_set_string(pResponseObject, "firmware_name", stOtaImageInfo.stEdgeInfo.pEdgeSolutions);
        json_object_set_string(pResponseObject, "firmware_version", stOtaImageInfo.stEdgeInfo.pEdgeSolutionVersion);
    
    } else {

        json_object_set_string(pResponseObject, "firmware_name", stOtaImageInfo.stFirmwareInfo.pFileName);
        json_object_set_string(pResponseObject, "firmware_version", stOtaImageInfo.stFirmwareInfo.pVersion);
    }

    PRINT(DINF, "OTA Info update to userspace status : %d\n", json_serialize_to_file_pretty( pResonseValue, "/tmp/storage/ota_info.json" ));

    json_object_clear( pResponseObject );
    json_value_free( pResonseValue );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
char* calculate_md5sum(const char *filepath)
{
    char *command = NULL;
    asprintf(&command, "md5sum %s | awk '{print $1}'", filepath);

    FILE *fp = popen(command, "r");
    if (fp == NULL) {
        PRINT(DERR, "file open failed command : %s", "\n");
        return NULL;
    }
	free(command);

    static char md5sum[33];
    fgets(md5sum, sizeof(md5sum), fp);

    pclose(fp);
    return md5sum;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int OTA_fnUpdateManager( void )
{
    const char *file1 = "/app/bin/ota_update_manager";
    const char *file2 = "/var/bin/ota_update_manager";
    const char *restart_file = "/var/bin/restart";

    struct stat buffer;
    if ((stat(file2, &buffer) == 0) != 1)
    {
        PRINT(DINF, "ota_update_manager not available. So, Initialization started.%s", "\n");
        goto START;
    }

    char *md5sum1 = calculate_md5sum(file1);
    char *md5sum2 = calculate_md5sum(file2);
    char *sysCmd = NULL;

    if (md5sum1 == NULL || md5sum2 == NULL)
    {
        PRINT(DERR, "Failed to calculate MD5 sums%s", "\n");
        return -1;
    }

    if ( !strcmp(md5sum1, md5sum2) )
    {
        PRINT(DINF, "MD5 sums do not match. Updating file...%s","\n");
        if (remove(file2) != 0) {
            PRINT(DERR, "Unable to remove %s\n",file2);
            return -2;
        }
START:
        asprintf(&sysCmd, "cp %s %s", file1, file2);
        if (system(sysCmd) != 0) {
            PRINT(DERR, "Unable to copy from %s to %s\n",file1, file2);
            free(sysCmd);
            return -3;
        }
        free(sysCmd);

        asprintf(&sysCmd, "touch %s", restart_file);
        if (system(sysCmd) != 0) {
            PRINT(DERR, "Failed to touch restart file%s", "\n");
            free(sysCmd);
            return -4;
        }
        free(sysCmd);

        PRINT(DINF, "File updated and restart file created.%s", "\n");
    }
    else
    {
        PRINT(DINF, "MD5 sums match. No update needed.%s", "\n");
    }
    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int OTA_fnNonEdgeHandler( void *argv )
{
    (void)argv;
    char *pSysCmd = NULL, *pAckResponse = NULL;
    uint8_t u8RetryCount = 0, u8RetryTemp = 0, u8TimeNow = 0;
    bool bDownloadEnable = false;

    OTA_fnUpdateManager();

    while( true )
    {
        u8RetryTemp = ( stOtaImageInfo.stFirmwareInfo.u8RetryCount == 0 ) ? 1 : stOtaImageInfo.stFirmwareInfo.u8RetryCount;

        if ( u8RetryCount < u8RetryTemp && gbBlobDownloadFlag )
        {
            bDownloadEnable = true;
            if ( u8RetryCount != 0 )
            {
                OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                free(pAckResponse);

                if ( eOtaUpdateStatus == eTimeoutFailure )
                {
                    uint16_t u16Sleep = ( stOtaImageInfo.stFirmwareInfo.u8RetryInterval * 60 );
                    sleep( u16Sleep );
                    eOtaUpdateStatus = eRetryAttempt;

                    OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
                    OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                    free(pAckResponse);
                }
                else
                {
                    gbBlobDownloadFlag = false;
                    gbDownloadSuccess = false;
                    bDownloadEnable = false;
                    u8RetryCount = 0;
                }
            }
        }
        else if ( gbBlobDownloadFlag )
        {
            if ( stOtaImageInfo.stFirmwareInfo.u8RetryCount != 0 )
                eOtaUpdateStatus = eRetryFailure;

            OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
            OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
            free(pAckResponse);

            gbBlobDownloadFlag = false;
            gbDownloadSuccess = false;
            u8RetryCount = 0;
        }

        if ( bDownloadEnable )
        {
            if( u8RetryCount == 0 )
                system("rm *.tar.gz");

            asprintf(&pSysCmd, "wget --spider %s 2>&1 | grep 'Remote file exists'", stOtaImageInfo.stFirmwareInfo.pBlobUrl);
            int result = system(pSysCmd);
            if (result != 0) {
                PRINT(DERR, "Remote file exists check getting failed : %s\n", stOtaImageInfo.stFirmwareInfo.pBlobUrl);
                free(pSysCmd);
                eOtaUpdateStatus = eInvalidBlobUrl;
                bDownloadEnable = false;
                u8RetryCount++;
                continue;
            }
            free(pSysCmd);
            PRINT(DINF, "Remote file exists file can be downloaded : %s\n", stOtaImageInfo.stFirmwareInfo.pBlobUrl);

            eOtaUpdateStatus = eDownloadInprocess;
            OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
            OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
            free(pAckResponse);

            asprintf(&pSysCmd, "%s --tries=1 --timeout=%d %s 2>&1 | grep '100%%'", ( u8RetryCount == 0) ? "wget" : "wget -c", \
                stOtaImageInfo.stFirmwareInfo.u8TimeoutTime, stOtaImageInfo.stFirmwareInfo.pBlobUrl);
            result = system(pSysCmd);
            if (result != 0) {
                PRINT(DERR, "wget getting failed cmd : %s\n", pSysCmd);
                free(pSysCmd);
                eOtaUpdateStatus = eTimeoutFailure;
                bDownloadEnable = false;
                u8RetryCount++;
                continue;
            }
            free(pSysCmd);
            PRINT(DINF, "wget: image downloaded successfully%s", "\n");

            asprintf(&pSysCmd, "ls | grep %s", stOtaImageInfo.stFirmwareInfo.pFileName);
            if ( OTA_fnSystemCommand(pSysCmd, stOtaImageInfo.stFirmwareInfo.pFileName) != 0 ) {
                free(pSysCmd);
                eOtaUpdateStatus = eFilenameMismatch;
                bDownloadEnable = false;
                u8RetryCount++;
                continue;
            }
            free(pSysCmd);
            PRINT(DINF, "firmware name verified successfully%s", "\n");

            asprintf(&pSysCmd, "ls | grep %s", stOtaImageInfo.stFirmwareInfo.pVersion);
            if ( OTA_fnSystemCommand(pSysCmd, stOtaImageInfo.stFirmwareInfo.pFileName) != 0 ) {
                free(pSysCmd);
                eOtaUpdateStatus = eVersionMismatch;
                bDownloadEnable = false;
                u8RetryCount++;
                continue;
            }
            free(pSysCmd);
            PRINT(DINF, "firmware version verified successfully%s", "\n");

            asprintf(&pSysCmd, "md5sum %s_%s.tar.gz | awk '{print $1}'", stOtaImageInfo.stFirmwareInfo.pFileName, stOtaImageInfo.stFirmwareInfo.pVersion);
            if ( OTA_fnSystemCommand( pSysCmd, stOtaImageInfo.stFirmwareInfo.pChecksum ) != 0 ) {
                free(pSysCmd);
                eOtaUpdateStatus = eChecksumMismatch;
                bDownloadEnable = false;
                u8RetryCount++;
                continue;
            }
            free(pSysCmd);
            PRINT(DINF, "checksum validation verified successfully%s", "\n");

            asprintf(&pSysCmd, "mv %s_%s.tar.gz /tmp/storage/", stOtaImageInfo.stFirmwareInfo.pFileName, stOtaImageInfo.stFirmwareInfo.pVersion);
            result = system(pSysCmd);
            if (result != 0) {
                PRINT(DERR, "moving package failed cmd : %s\n", pSysCmd);
                free(pSysCmd);
                eOtaUpdateStatus = ePermissionDenied;
                bDownloadEnable = false;
                u8RetryCount++;
                continue;
            }
            free(pSysCmd);
            PRINT(DINF, "image moved to further installation successfully%s", "\n");

            eOtaUpdateStatus = eDownloadSuccess;
            gbBlobDownloadFlag = false;
            u8RetryCount = 0;
            gbDownloadSuccess = true;
            bDownloadEnable = false;

            OTA_fnSendReportedProperties( 0, eOtaUpdateStatus, stErrCodeMsg[eOtaUpdateStatus].pStatusMsg, &pAckResponse );
            OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
            free(pAckResponse);

            OTA_fnSentResponse( OTA_UPDATE_REQ_TO_UI, 0, stOtaImageInfo.pUpdateInfo, &pAckResponse );
            OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
            free(pAckResponse);
        }

        if ( stOtaImageInfo.u8UserResponse == eIdleTimeUpdateAccepted )
        {
            time_t raw_time;
            struct tm local_time;
            time(&raw_time);
            localtime_r(&raw_time, &local_time);

            int current_hour = local_time.tm_hour;

            if (current_hour >= 2 && current_hour < 4)
            // if (current_hour >= 14 && current_hour < 20)
            {
                OTA_fnSentResponse( OTA_UPDATE_REQ_TO_UI, 0, stOtaImageInfo.pUpdateInfo, &pAckResponse );
                OTA_fnPublishingData( OTA_fnGetHandle(), pAckResponse, OTA_OUTPUT_ROUTE);
                free(pAckResponse);

                stOtaImageInfo.u8UserResponse = eUpdateAvail;
                u8TimeNow = 0;
            }
            else
            {
                if (u8TimeNow == 0)
                {
                    PRINT(DINF, "Time Now = HH:MM = %02d:%2d\n", local_time.tm_hour, local_time.tm_min);
                }
                sleep(60);

                if (u8TimeNow++ > 30)
                    u8TimeNow = 0;
            }
        }
        else
        {
            sleep(5);
        }
    }
    return THREADAPI_OK;
}

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/
