/**
 * @mainpage The OTA (Over-The-Air) Manager
 * This is the main page of the OTA Manager
 * 
 * An Overview OTA (Over-The-Air) update refer to the process of remotely updating firmware, software, or configurations on devices without requiring physical access.
 * These updates are crucial for maintaining security, fixing bugs, and improving functionality. 
 * 
 * There are two main update features:
 * 1. Edge Module Update
 * 2. Non-Edge Firmware Update
 * 
 * Visit below link for more details 
 * 
 * 
 * @author Vijayapradap M (vijayapradap.m@happiestminds.com)
 * @version 1.0
 * @date 2024-08-13
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 */

/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      main.c
 * @brief     This module is responsible edge and non-edge OTA update process 
 * @author    Vijayapradap M (vijayapradap.m@happiestminds.com)
 * @version   1.0
 * @date      July 12 , 2024
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/

/*=============================================================================
                              Project Includes
==============================================================================*/

#include "ota_manager.h"

#ifndef MODULE_TWIN

// #define MODULE_TWIN

#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/platform.h"
#include "iothub_module_client_ll.h"
#include "iothub_client_options.h"
#include "iothub_message.h"
#include "iothubtransportmqtt.h"

#endif

/*==============================================================================
                              Private Includes
==============================================================================*/

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/

char xDeviceUUID[UUID_LEN];

/*==============================================================================
                              Static Variables
==============================================================================*/

static IOTHUB_MODULE_CLIENT_LL_HANDLE gIotHubModuleHandle;

/*==============================================================================
                              Static Functions
==============================================================================*/

/**
 * @brief OTA_fnInitializeConnection function makes connection between
 * IoTHub and OtaManager Module
 * 
 * @return success - IOTHUB_MODULE_CLIENT_LL_HANDLE 
 * @return failure - NULL
 */
static IOTHUB_MODULE_CLIENT_LL_HANDLE OTA_fnInitializeConnection( void );

/**
 * @brief OTA_fnDeInitializeConnection function invokes the de-initialization of initliazed
 * IOTHUB_MODULE_CLIENT_LL_HANDLE handle by  OTA_fnInitializeConnection
 * 
 */
static void OTA_fnDeInitializeConnection( void );

/**
 * @brief This function invokes to register callback for incoming messages through route method
 * 
 * @return int 0 on Success and 1 for Failure to register callback
 */
static int OTA_fnSetupCallbackForRouteMessages( void );

/**
 * @brief This function invokes to register callback for incoming messages through direct method
 * 
 * @return int 0 on Success and 1 for Failure to register callback 
 */
static int OTA_fnSetupCallbackForDirectMethod( void );

/**
 * @brief This callback makes confirmation on publishing messages through route method
 * 
 * @param[in] result Result of the telemetry send operation.
 * @param[in] userContextCallback User specified context that will be provided to the callback. This can be @c NULL.
 */
static void OTA_fnSendConfirmationCb( IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback );

/**
 * @brief This callback receives the incoming messages through route method and invokes the firmware selection function
 * for further OTA update process
 * 
 * @param message The incoming message received from IoT Hub.
 * @param userContextCallback User specified context that will be provided to the callback. This can be @c NULL.
 * @return IOTHUBMESSAGE_DISPOSITION_RESULT indicating how client has acknowledged the incoming cloud-to-device message.
 */
static IOTHUBMESSAGE_DISPOSITION_RESULT OTA_fnReceiveMessageProcessCb(IOTHUB_MESSAGE_HANDLE message, void* userContextCallback );

/**
 * @brief This callback receives the incoming messages through direct method and invokes the firmware selection function
 * for further OTA update process
 * 
 * @param method_name Name of method being invoked.
 * @param payload Request payload received from IoT Hub.
 * @param size Number of bytes in @c payload.
 * @param response Response of the request, as specified by the application.  This should NOT include the null-terminator.
 * @param response_size Number of bytes application specifies in @c response.
 * @param userContextCallback Context that application specified during initial API call to receive device or module method calls.
 * @return int HTTP style return code to indicate success or failure of the method call.
 */
static int OTA_fnModuleDirectMethodCb( const char *method_name, const unsigned char *payload, size_t size, 
    unsigned char **response, size_t *response_size, void *userContextCallback);

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void OTA_fnGetDeviceUUID( void ) {

    JSON_Value* pDeviceValue = json_parse_file("/var/tmp/dps_config.json");

    if ( pDeviceValue == NULL) {
        strcpy( xDeviceUUID, "xyz_device_id" );
        PRINT(DERR, "unable to read the deviceUuid%s", "\n");
    } else {
        JSON_Object* pDeviceObject = json_value_get_object( pDeviceValue );
        strncpy( xDeviceUUID, json_object_get_string( pDeviceObject,"registration_id" ), UUID_LEN );
        json_value_free( pDeviceValue );
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
IOTHUB_MODULE_CLIENT_LL_HANDLE OTA_fnGetHandle( void ) {
    return gIotHubModuleHandle;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void OTA_fnSendConfirmationCb( IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback )
{
    // IOTHUB_MESSAGE_HANDLE *messageInstance = (IOTHUB_MESSAGE_HANDLE *)userContextCallback;
    PRINT(DINF, "Acknowledgement Recieved for Publishing message with result = %d\r\n", result);
    /* Frees all resources associated with the given message handle */
    // IoTHubMessage_Destroy( messageInstance );
}

#ifdef MODULE_TWIN

static void OTA_fnModuleTwinCallback(MODULE_TWIN_UPDATE_STATE update_state, const unsigned char* payLoad, size_t size, void* userContextCallback)
{
    (void)userContextCallback;

    PRINT(DINF, "Module Twin update received (state=%s, size=%zu): %s\r\n", 
        MU_ENUM_TO_STRING(MODULE_TWIN_UPDATE_STATE, update_state), size, payLoad);

    OTA_fnOtaUpdateHandler(eRouteMethod, payLoad, NULL, &size);
}

static void OTA_fnReportedStateCallback(int status_code, void* userContextCallback)
{
    (void)userContextCallback;
    PRINT(DINF, "Module Twin reported properties update completed with result: %d\r\n", status_code);
}

#endif

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
IOTHUBMESSAGE_DISPOSITION_RESULT OTA_fnPublishingData(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle, const char *pJsonMessage, const char *pOutputRoute)
{
    IOTHUB_CLIENT_RESULT ePublishMessageStatus;
    IOTHUB_MESSAGE_HANDLE publishMessageHandle, pPublicMessageHandle;
    
    /* Creates a new IoT hub message from a null terminated string. */
    publishMessageHandle = IoTHubMessage_CreateFromString( pJsonMessage );
    // pPublicMessageHandle = (IOTHUB_MESSAGE_HANDLE *) malloc (sizeof(IOTHUB_MESSAGE_HANDLE));
    pPublicMessageHandle = IoTHubMessage_Clone(publishMessageHandle);

    if ( iotHubModuleClientHandle != NULL )
    {
        if (pPublicMessageHandle == NULL )
        {
            ePublishMessageStatus = IOTHUB_CLIENT_ERROR;
        }
        else
        {
            /* Returns Enumeration specifying the status of calls to IoT Hub client. */
            ePublishMessageStatus = IoTHubModuleClient_LL_SendEventToOutputAsync( iotHubModuleClientHandle, pPublicMessageHandle, 
                pOutputRoute, OTA_fnSendConfirmationCb, (void *)pPublicMessageHandle);
            
            if ( ePublishMessageStatus != IOTHUB_CLIENT_OK )
            {
                IoTHubMessage_Destroy(pPublicMessageHandle);
                PRINT(DERR, "failed to publish message on Route : %d : %s \n",ePublishMessageStatus, pOutputRoute );
            }
            else
            {
                PRINT(DINF, "Published Message on Route : <'%s'> Successfully \n \n\n", pJsonMessage );
            }
        }
    }
    else
    {
        PRINT(DERR, "Invalid Client handle%s", "\n");
    }

    return ePublishMessageStatus;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int OTA_fnModuleDirectMethodCb(const char *method_name, const unsigned char *payload, size_t size, unsigned char **response, size_t *response_size, void *userContextCallback) 
{
    (void)userContextCallback;
    int result = 0;

    if ( strcmp((char *)OTA_DIRECT_METHOD, method_name) == 0 ) {
        result = OTA_fnOtaUpdateHandler(eDirectMethod, payload, response, response_size);
    } else {

        JSON_Value *pResonseValue = json_value_init_object();
        JSON_Object *pResponseObject = json_value_get_object(pResonseValue);

        PRINT(DERR,"method name missing / invalid !!%s", "\r\n");
        json_object_set_string(pResponseObject, "Response", "Method Missing or Invalid");
        result = RESULT_METHOD_NOT_ALLOWED;

        char *deviceMethodResponse = json_serialize_to_string_pretty(pResonseValue);
        *response_size = strlen(deviceMethodResponse);
        *response = (unsigned char *)malloc(*response_size);
        (void)memcpy(*response, deviceMethodResponse, *response_size);

        json_value_free(pResonseValue);
    }
    return result;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static IOTHUBMESSAGE_DISPOSITION_RESULT OTA_fnReceiveMessageProcessCb(IOTHUB_MESSAGE_HANDLE message, void* userContextCallback)
{
    IOTHUBMESSAGE_DISPOSITION_RESULT result;
    IOTHUB_CLIENT_RESULT clientResult;
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle = (IOTHUB_MODULE_CLIENT_LL_HANDLE)userContextCallback;

    unsigned const char* messageBody;
    size_t contentSize;

    if (IoTHubMessage_GetByteArray(message, &messageBody, &contentSize) != IOTHUB_MESSAGE_OK)
        messageBody = "<null>";
    else
        PRINT(DINF, "Received Message Data: [%s]\r\n", messageBody);

    if( messageBody != NULL )
    {
        OTA_fnOtaUpdateHandler(eRouteMethod, messageBody, NULL, &contentSize);
        result = IOTHUBMESSAGE_ACCEPTED;
    }
    else
    {
        PRINT(DERR, "Recieved Message is an Empty String !!!%s", "\n");
        result = IOTHUBMESSAGE_ABANDONED;
    }

    return result;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static IOTHUB_MODULE_CLIENT_LL_HANDLE OTA_fnInitializeConnection()
{
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;

    if (IoTHub_Init() != 0)
    {
        PRINT(DERR, "Failed to initialize the platform%s", "\n");
        iotHubModuleClientHandle = NULL;
    }
    else if ((iotHubModuleClientHandle = IoTHubModuleClient_LL_CreateFromEnvironment(MQTT_Protocol)) == NULL)
    {
        PRINT(DERR, "IoTHubModuleClient_LL_CreateFromEnvironment failed%s", "\n");
    }
    else
    {
        // bool traceOn = true;
        // IoTHubModuleClient_LL_SetOption(iotHubModuleClientHandle, OPTION_LOG_TRACE, &traceOn);
    }

    return iotHubModuleClientHandle;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void OTA_fnDeInitializeConnection( void )
{
    if (gIotHubModuleHandle != NULL)
    {
        IoTHubModuleClient_LL_Destroy(gIotHubModuleHandle);
    }
    IoTHub_Deinit();
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int OTA_fnSetupCallbackForRouteMessages( void )
{
    if (IoTHubModuleClient_LL_SetInputMessageCallback( gIotHubModuleHandle, OTA_INPUT_ROUTE, OTA_fnReceiveMessageProcessCb, (void*)gIotHubModuleHandle) != IOTHUB_CLIENT_OK )
    {
        PRINT(DERR, "IoTHubModuleClient_LL_SetInputMessageCallback failed%s", "\n");
        return 1;
    }
    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int OTA_fnSetupCallbackForDirectMethod( void )
{
    if (IoTHubModuleClient_LL_SetModuleMethodCallback( gIotHubModuleHandle, OTA_fnModuleDirectMethodCb, NULL ) != IOTHUB_CLIENT_OK)
    {
        PRINT(DERR, "IoTHubModuleClient_LL_SetModuleMethodCallback failed%s", "\n");
        return 1;
    }
    return 0;
}

#ifdef MODULE_TWIN

static int OTA_fnSetupCallbackForModuleTwin(void)
{
    // const char* reportedState = "{ 'device_property': 'new_value' }";
    // size_t reportedStateSize = strlen(reportedState);

    if ( IoTHubModuleClient_LL_SetModuleTwinCallback(gIotHubModuleHandle, OTA_fnModuleTwinCallback, gIotHubModuleHandle) != IOTHUB_CLIENT_OK) {
        PRINT(DERR, "IoTHubModuleClient_LL_SetModuleTwinCallback failed%s", "\n");
        return 1;
    }
    // if ( IoTHubModuleClient_LL_SendReportedState(gIotHubModuleHandle, (const unsigned char*)reportedState, 
    //     reportedStateSize, OTA_fnReportedStateCallback, gIotHubModuleHandle) != IOTHUB_CLIENT_OK) {
    //     PRINT(DERR, "IoTHubModuleClient_LL_SendReportedState failed%s", "\n");
    //     goto exit;
    // }

    return 0;
}

#endif

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int OTA_fnIotHubInitHandler(void *argv)
{
    (void)argv;

    srand((unsigned int)time(NULL));

    if ( (gIotHubModuleHandle = OTA_fnInitializeConnection()) == NULL ) {
        PRINT(DERR, "IoTHub module client Initialization getting failed%s","\n\n");
        return THREADAPI_ERROR;
    }
    PRINT(DINF, "IoTHub module client Initialized successfully%s", "\n\n");

    if( OTA_fnSetupCallbackForRouteMessages() != 0 ) {
        PRINT(DERR, "setting module callback getting failed%s","\n\n");
        goto exit;
    }
    PRINT(DINF, "IoTHub module callback registered successfully%s", "\n\n");

    if( OTA_fnSetupCallbackForDirectMethod() != 0 ) {
        PRINT(DERR, "setting direct method callback getting failed%s","\n\n");
        goto exit;
    }
    PRINT(DINF, "IoTHub direct method callback registered successfully%s", "\n\n");

#ifdef MODULE_TWIN

    if( OTA_fnSetupCallbackForModuleTwin() != 0 ) {
        PRINT(DERR, "setting device twin callback getting failed%s","\n\n");
        goto exit;
    }
    PRINT(DINF, "IoTHub device twin callback registered successfully%s", "\n\n");

#endif

    PRINT(DINF, "Waiting for incoming messages %s", "\n");
    
    int beat = 0;
    while (true)
    {
        if( beat++ > 1000 ) {
            PRINT(DINF, "Waiting for incoming messages %s", "\n");
            beat = 0;
        }

        IoTHubModuleClient_LL_DoWork(gIotHubModuleHandle);
        ThreadAPI_Sleep(200);
    }

exit:
    OTA_fnDeInitializeConnection();
    PRINT(DINF, "IoTHub module client Deinitializated successfully%s","\n\n");
    return THREADAPI_OK;
}

/**
 * @brief Main entry of OTA_Manager program
 */
int main(void)
{
    THREAD_HANDLE stModuleHandle, stDownloadHandle;

    if ( ThreadAPI_Create ( &stModuleHandle, OTA_fnIotHubInitHandler, NULL ) != THREADAPI_OK ) {
        PRINT(DERR, "Creating thread getting failed%s", "\n");
    }

    if ( ThreadAPI_Create ( &stDownloadHandle, OTA_fnNonEdgeHandler, NULL ) != THREADAPI_OK ) {
        PRINT(DERR, "Creating thread getting failed%s", "\n");
    }

    ThreadAPI_Join(stModuleHandle, NULL);
    ThreadAPI_Join(stDownloadHandle, NULL);
    return 0;
}

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/