#ifndef __MODEM_H__
#define __MODEM_H__

/********************************************************************************
 *      Copyright: 2024 Eaden FTT. All rights reserved.
 *                 All trademarks are owned or licensed by Organization Name,
 *                 its subsidiaries or affiliated companies.
 *
 *       Filename: modem.h
 *    Description: Modem SET/GET, power-on/off all possible controls will be
 *    		   controlled over this functions
 *
 *        Version: 1.0.0
 *         Author: happiest minds
 *          Date : April, 03, 2024
 *
 ********************************************************************************/

#include "../inc/hw_interface_liberrors.h"

#define I2C_DEVICE      "/dev/i2c-1"
#define I2C_ADDR        0x20
#define M_INDEXPATH     "Modem/"

#define BUFF_SIZE       255

typedef struct {
        uint8_t u8Mode;
        uint8_t u8GpsSvs;
        uint8_t u8GlonassSvs;
        uint8_t u8BeidouSvs;
        double dLat;
        char cNs;
        double dLong;
        char cEw;
        uint32_t u32Date;
        struct {
                uint8_t u8Day;
                uint8_t u8Month;
                uint8_t u8Year;
        } stDate;
        double dUtc;
        struct {
                uint8_t u8Hour;
                uint8_t u8Min;
                uint8_t u8Sec;
                uint8_t u8Msec;
        } stUtc;
        double dAlt;
        double dSpeed;
        double dCourse;
        double dPdop;
        double dHdop;
        double dVdop;
        double dTdop;
} stGnssData_t;

typedef struct {
        char *cpName;
        char *cpKey;
        char *cpCmd;
} stModemInfo_t;

/*!
 * @brief		This function for power on/off the modem
 *
 * @param[in]		enable - 'true' for turn on or 'false' for turn off modem
 *
 * @retval eReturn_ok 	Operation success
 * @retval eReturn_err_io	unable to access ioctl
 * @retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnPowerOnModem(bool enable);    // 1 turn-on, 0 turn-off

/*!
 * @brief		This function for Enable the internet over the machine
 *
 * @param[in]		Nothing (void)
 *
 * @retval eReturn_ok 	Operation success	
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnEnableInternet(void);

/*!
 * @brief		This function for Power-on GPS to get location details
 *
 * @param[in]		Nothing (void)
 *
 * @retval eReturn_ok 	Operation success	
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnPowerOnGps(void);

/*!
 * @brief		This function for Restart the 4G modem
 *
 * @param[in]		Nothing (void)
 *
 * @retval eReturn_ok 	Operation success	
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnModemRestart(void);

/*!
 * @brief		This function to get the lat, long data from GPS
 *
 * @param[out]		cpLatLongitude - to load the gps location data
 *
 * @retval eReturn_ok 	Operation success	
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnGetLatLongData(char *cpLatLongitude);

/*!
 * @brief		This function to set and get the possible settings/details
 * 			of the 4G Modem
 *
 * @param[in]		cpInfoKey - get / set parameter detail
 * @param[in]		cpOutputInfo - when get info, it will act as output
 * 			cpOutputInfo - when set info, it will act as input data
 * 					need to be written
 *
 * @retval eReturn_ok 	Operation success
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnSetGetModemInfo(char *cpInfoKey, char *cpOutputInfo);

/*!
 * @brief		This function to get all GPS parameter in a structure
 *
 * @param[in]		stGnssData_t - structure to get all details
 *
 * @retval eReturn_ok 	Operation success
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
int8_t HW_MODEM_fnGetGPSData(stGnssData_t *stGnssTemp);

#endif
