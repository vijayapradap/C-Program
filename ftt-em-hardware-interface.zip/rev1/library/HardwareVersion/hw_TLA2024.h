#ifndef TLA2024_H
#define TLA2024_H

/**
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      hw_TLA2024.h
 * @brief     This is the header file for ADC HW Version.
 *            Macros, structs, function prototypes defined here.
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <stdint.h>
/*==============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                             Type Defines
==============================================================================*/

/*==============================================================================
                              Macros
==============================================================================*/
#define I2CDeviceDefaultName "/dev/i2c-1"
#define FailTryCount 10

#define I2CADDRESS_1                    (0x48)    
#define tla2024                         (2)
#define TLA2024_CONVERSIONDELAY         (1000U) 

#define TLA2024_REG_CONFIG_DR_1600SPS   (0x0080)

#define TLA2024_REG_POINTER_MASK        (0x03)      
#define TLA2024_REG_POINTER_CONVERT     (0x00)
#define TLA2024_REG_POINTER_CONFIG      (0x01)
#define TLA2024_REG_CONFIG_OS_MASK      (0x8000)
#define TLA2024_REG_CONFIG_OS_SINGLE    (0x8000) 

#define TLA2024_REG_CONFIG_CQUE_NONE    (0x0003)
#define TLA2024_REG_CONFIG_CLAT_NONLAT  (0x0000)
#define TLA2024_REG_CONFIG_CPOL_ACTVLOW (0x0000)
#define TLA2024_REG_CONFIG_CMODE_TRAD   (0x0000)
#define TLA2024_REG_CONFIG_MODE_SINGLE  (0x0100)
#define TLA2024_REG_CONFIG_OS_BUSY      (0x0000)

#define TLA2024_REG_CONFIG_MUX_SINGLE_0 (0x4000)
#define TLA2024_REG_CONFIG_MUX_SINGLE_1 (0x5000)
#define TLA2024_REG_CONFIG_MUX_SINGLE_2 (0x6000)
#define TLA2024_REG_CONFIG_MUX_SINGLE_3 (0x7000)

#define TLA2024_REG_CONFIG_PGA_6_144V   (0x0000)
#define TLA2024_REG_CONFIG_PGA_4_096V   (0x0200)
#define TLA2024_REG_CONFIG_PGA_2_048V   (0x0400)
#define TLA2024_REG_CONFIG_PGA_1_024V   (0x0600)
#define TLA2024_REG_CONFIG_PGA_0_512V   (0x0800)
#define TLA2024_REG_CONFIG_PGA_0_256V   (0x0A00)

#define TLA2024_REG_CONFIG_DR_128SPS    (0x0000)
#define TLA2024_REG_CONFIG_DR_250SPS    (0x0020)
#define TLA2024_REG_CONFIG_DR_490SPS    (0x0040)
#define TLA2024_REG_CONFIG_DR_920SPS    (0x0060)
#define TLA2024_REG_CONFIG_DR_1600SPS   (0x0080)
#define TLA2024_REG_CONFIG_DR_2400SPS   (0x00A0)
#define TLA2024_REG_CONFIG_DR_3300SPS   (0x00C0)
#define TLA2024_REG_CONFIG_DR_860SPS    (0x00E0)

/*==============================================================================
                              Enums
==============================================================================*/
typedef enum 
{
    GAIN_TWOTHIRDS = TLA2024_REG_CONFIG_PGA_6_144V,
    GAIN_ONE = TLA2024_REG_CONFIG_PGA_4_096V,
    GAIN_TWO = TLA2024_REG_CONFIG_PGA_2_048V,
    GAIN_FOUR = TLA2024_REG_CONFIG_PGA_1_024V,
    GAIN_EIGHT = TLA2024_REG_CONFIG_PGA_0_512V,
    GAIN_SIXTEEN = TLA2024_REG_CONFIG_PGA_0_256V
} adsGain_t;

typedef enum
{
    SPS_128 = TLA2024_REG_CONFIG_DR_128SPS,
    SPS_250 = TLA2024_REG_CONFIG_DR_250SPS,
    SPS_490 = TLA2024_REG_CONFIG_DR_490SPS,
    SPS_920 = TLA2024_REG_CONFIG_DR_920SPS,
    SPS_1600 = TLA2024_REG_CONFIG_DR_1600SPS,
    SPS_2400 = TLA2024_REG_CONFIG_DR_2400SPS,
    SPS_3300 = TLA2024_REG_CONFIG_DR_3300SPS,
    SPS_860 = TLA2024_REG_CONFIG_DR_860SPS
} adsSps_t;

/*==============================================================================
                              Structures
==============================================================================*/
typedef struct TLA2024
{
  const char* m_i2cDeviceName;
  uint16_t m_i2cAddress;      
  uint32_t m_conversionDelay;
  uint16_t   m_adsType;
  uint16_t m_bitShift;
  adsGain_t m_gain;
  adsSps_t  m_sps;
}TLA2024_t;

/*==============================================================================
                              functions prototypes
==============================================================================*/
void HW_ADC_fnInit();
static void HW_ADC_fnEndTransmission();
int32_t HW_ADC_fnReadHWVersion();
uint16_t HW_ADC_fnReadSingleEnded(uint8_t channel);
void HW_ADC_fnSetConversionDelay(void);
static uint16_t HW_ADC_fnReadRegister(const char* i2cDeviceName, uint8_t i2cAddress, uint8_t reg);
static void HW_ADC_fnWriteRegister(const char* i2cDeviceName, uint8_t i2cAddress, uint8_t reg, uint16_t value);

/*==============================================================================
                              Footer
==============================================================================*/

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd. *********END OF FILE****/

#endif /** TLA2024_H */