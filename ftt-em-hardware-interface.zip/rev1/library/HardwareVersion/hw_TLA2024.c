/**
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      hw_TLA2024.c
 * @brief     This is application source file for reading the hw version by calculating ADC voltage.
 *            
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/*==============================================================================
*         					  Project includes
================================================================================*/
#include "hw_TLA2024.h"
/*==============================================================================
                              Private Includes
==============================================================================*/
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
#include "../inc/hw_interface_liberrors.h"
/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/
static int32_t sgi32_i2cHandle;
TLA2024_t gst_tla2024;
/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/


/*!
 * @brief <b> This function is for begin transmission </b>
 *
 * @param[in] i2cDeviceName char pointer containing Device Name
 * @param[in] i2cAddress containing i2c address
 * @param[out] none
 *
 * @return int32_t - 0 on success or -1 on failure
 */
static int32_t HW_ADC_fnBeginTransmission(const char* i2cDeviceName, uint8_t i2cAddress) 
{
	for (size_t i = 0; i < FailTryCount; i++)
	{
		sgi32_i2cHandle = open(i2cDeviceName, O_RDWR);
		if (sgi32_i2cHandle >= 0)
			break;

		if (i >= FailTryCount - 1)
		{
			return -1;
		}

		usleep(1000);
	}

	for (size_t i = 0; i < FailTryCount; i++)
	{
		if (ioctl(sgi32_i2cHandle, I2C_SLAVE, i2cAddress) >= 0)
			break;

		if (i >= FailTryCount - 1)
		{
			return -1;
		}

		usleep(1000);
	}

	return 1;
}

/*!
 * @brief <b> This function is for end transmission </b>
 *
 * @param[in] none
 * @param[out] none
 *
 * @return none
 */
static void HW_ADC_fnEndTransmission(void) {
	close(sgi32_i2cHandle);
}

/*!
 * @brief <b> This function is for write in registers </b>
 *
 * @param[in] i2cDeviceName char pointer containing Device Name
 * @param[in] i2cAddress containing i2c address
 * @param[in] reg register address to write into
 * @param[in] value value to be written
 * @param[out] none
 *
 * @return none
 */
static void HW_ADC_fnWriteRegister(const char* i2cDeviceName, uint8_t i2cAddress, uint8_t reg, uint16_t value) {
	if (HW_ADC_fnBeginTransmission(i2cDeviceName, i2cAddress) < 0)
		return;

	int32_t rc;
	unsigned char buf[3] = { reg, (uint8_t)(value >> 8) , (uint8_t)(value & 0xFF) };
	rc = write(sgi32_i2cHandle, buf, 3);
	if (rc == -1) {
		if (i2cAddress == I2CADDRESS_1)
			MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: SingleEnded\n");
		else
			MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: Differential\n");

		MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: Write Error\n");
	};
	HW_ADC_fnEndTransmission();
}

/*!
 * @brief <b> This function is for read in registers </b>
 *
 * @param[in] i2cDeviceName char pointer containing Device Name
 * @param[in] i2cAddress containing i2c address
 * @param[in] reg register address to read from
 * @param[out] none
 *
 * @return none
 */
static uint16_t HW_ADC_fnReadRegister(const char* i2cDeviceName, uint8_t i2cAddress, uint8_t reg) 
{
	if (HW_ADC_fnBeginTransmission(i2cDeviceName, i2cAddress) < 0)
 	{
		return 0xFF;
	}
	int32_t rc;
	unsigned char buf[1] = { reg };
	rc = write(sgi32_i2cHandle, buf, 1);
	if (rc == -1) {
		if (i2cAddress == I2CADDRESS_1)
			MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: SingleEnded\n");
		else
			MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: Differential\n");

		MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: Write Error\n");
	}

	unsigned char readbuf[2] = {  };
	rc = read(sgi32_i2cHandle, readbuf, 2);
	if (rc == -1) {
		if (i2cAddress == I2CADDRESS_1)
			MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: SingleEnded\n");
		else
			MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: Differential\n");

		MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: hw_ADC_fnReadRegister: Read Error\n");
	}

	HW_ADC_fnEndTransmission();
	uint16_t registerValue = ((readbuf[0] << 8) | readbuf[1]);
	return registerValue;
}

/*!
 * @brief <b> This function is to initialise ADC </b>
 *
 * @param[in] None
 * @param[out] None
 *
 * @return None
 */
void HW_ADC_fnInit()
{
	gst_tla2024.m_i2cDeviceName = I2CDeviceDefaultName;
	gst_tla2024.m_i2cAddress = I2CADDRESS_1;
	gst_tla2024.m_conversionDelay = TLA2024_CONVERSIONDELAY;
	gst_tla2024.m_adsType = tla2024;
	gst_tla2024.m_bitShift = 4;
	gst_tla2024.m_gain = GAIN_TWOTHIRDS;
	gst_tla2024.m_sps = SPS_1600;
	//HW_ADC_fnSetConversionDelay();
}
struct TLA2024 gst_tla2024 = { I2CDeviceDefaultName, I2CADDRESS_1, TLA2024_CONVERSIONDELAY, tla2024, 4, GAIN_TWOTHIRDS, SPS_1600};

/*!
 * @brief <b> This function is for reading the HW Version </b>
 *
 * @param[in] None
 * @param[out] None
 *
 * @return int16_t HW Version
 */
int32_t HW_ADC_fnReadHWVersion()
{
	int32_t i32_adc0, i32_adc1;
    i32_adc0 = HW_ADC_fnReadSingleEnded(0);
    i32_adc1 = HW_ADC_fnReadSingleEnded(1);
	int32_t i32_adcVolt = (i32_adc0 - i32_adc1) * 3; 
	printf("value of adc voltage: %d\n" ,i32_adcVolt);

	int32_t i32_hwVersion = -1;

	if(i32_adcVolt >= 1750 && i32_adcVolt <=1850)
	{
		i32_hwVersion = 0;
	}
	else if(i32_adcVolt >= 0 && i32_adcVolt <= 50)
	{
		i32_hwVersion = 1;
	}
	else if(i32_adcVolt >= 850 && i32_adcVolt <=950)
	{
		i32_hwVersion = 2;
	}
	else if(i32_adcVolt >= 550 && i32_adcVolt <= 650)
	{
		i32_hwVersion = 3;
	}
	else if(i32_adcVolt >= 1150 && i32_adcVolt <= 1250)
	{
		i32_hwVersion = 4;
	}
	return i32_hwVersion;
}

/*!
 * @brief <b> This function Gets a single-ended ADC reading from the specified channel </b>
 *
 * @param[in] channel ADC channel to read
 * @param[out] None
 *
 * @return the ADC reading
 */
uint16_t HW_ADC_fnReadSingleEnded(uint8_t channel) {
	if (channel > 3) {
		return 0;
	}

	uint16_t config =
		TLA2024_REG_CONFIG_CQUE_NONE | 
		TLA2024_REG_CONFIG_CLAT_NONLAT |
		TLA2024_REG_CONFIG_CPOL_ACTVLOW |
		TLA2024_REG_CONFIG_CMODE_TRAD |
		TLA2024_REG_CONFIG_MODE_SINGLE;

	config |= gst_tla2024.m_gain;

	config |= gst_tla2024.m_sps;

	switch (channel) {
		case (0):
			config |= TLA2024_REG_CONFIG_MUX_SINGLE_0;
			break;
		case (1):
			config |= TLA2024_REG_CONFIG_MUX_SINGLE_1;
			break;
		case (2):
			config |= TLA2024_REG_CONFIG_MUX_SINGLE_2;
			break;
		case (3):
			config |= TLA2024_REG_CONFIG_MUX_SINGLE_3;
			break;
	}

	config |= TLA2024_REG_CONFIG_OS_SINGLE;

	HW_ADC_fnWriteRegister(gst_tla2024.m_i2cDeviceName, gst_tla2024.m_i2cAddress, TLA2024_REG_POINTER_CONFIG, config);

	usleep(gst_tla2024.m_conversionDelay);
	do
	{
		usleep(10);
	} while (TLA2024_REG_CONFIG_OS_BUSY == (HW_ADC_fnReadRegister(gst_tla2024.m_i2cDeviceName, gst_tla2024.m_i2cAddress, TLA2024_REG_POINTER_CONFIG) & TLA2024_REG_CONFIG_OS_MASK));

	return HW_ADC_fnReadRegister(gst_tla2024.m_i2cDeviceName, gst_tla2024.m_i2cAddress, TLA2024_REG_POINTER_CONVERT) >> gst_tla2024.m_bitShift;
}

/*!
 * @brief <b> This function set the conversion delay </b>
 *
 * @param[in] none
 * @param[out] None
 *
 * @return none
 */
void HW_ADC_fnSetConversionDelay()
{
	if (gst_tla2024.m_adsType == tla2024)
	{
		switch (gst_tla2024.m_sps)
		{
		case SPS_128:
			gst_tla2024.m_conversionDelay = 1000000 / 128;
			break;
		case SPS_250:
			gst_tla2024.m_conversionDelay = 1000000 / 250;
			break;
		case SPS_490:
			gst_tla2024.m_conversionDelay = 1000000 / 490;
			break;
		case SPS_920:
			gst_tla2024.m_conversionDelay = 1000000 / 920;
			break;
		case SPS_1600:
			gst_tla2024.m_conversionDelay = 1000000 / 1600;
			break;
		case SPS_2400:
			gst_tla2024.m_conversionDelay = 1000000 / 2400;
			break;
		case SPS_3300:
			gst_tla2024.m_conversionDelay = 1000000 / 3300;
			break;
		case SPS_860:
			gst_tla2024.m_conversionDelay = 1000000 / 3300;
			break;
		default:
			gst_tla2024.m_conversionDelay = 8000;
			break;
		}
	}
	else
	{
		switch (gst_tla2024.m_sps)
		{
		case SPS_128:
			gst_tla2024.m_conversionDelay = 1000000 / 8;
			break;
		case SPS_250:
			gst_tla2024.m_conversionDelay = 1000000 / 16;
			break;
		case SPS_490:
			gst_tla2024.m_conversionDelay = 1000000 / 32;
			break;
		case SPS_920:
			gst_tla2024.m_conversionDelay = 1000000 / 64;
			break;
		case SPS_1600:
			gst_tla2024.m_conversionDelay = 1000000 / 128;
			break;
		case SPS_2400:
			gst_tla2024.m_conversionDelay = 1000000 / 250;
			break;
		case SPS_3300:
			gst_tla2024.m_conversionDelay = 1000000 / 475;
			break;
		case SPS_860:
			gst_tla2024.m_conversionDelay = 1000000 / 860;
			break;
		default:
			gst_tla2024.m_conversionDelay = 125000;
			break;
		}
	}
	gst_tla2024.m_conversionDelay += 100;
}
