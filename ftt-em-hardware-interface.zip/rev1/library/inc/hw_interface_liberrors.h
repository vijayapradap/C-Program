#ifndef HW_INTERFACE_LIBERRORS_H_
#define HW_INTERFACE_LIBERRORS_H_
/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 ******************************************************************************
 *
 * @file      hw_interface_liberrors.h
 * @brief     This is the header file for power supply board communication with
 *            main board over uart using mwo protocol
  ******************************************************************************
 */


/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include <sys/fcntl.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <syslog.h>

/*==============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                             Type Defines
==============================================================================*/

/*==============================================================================
                              Macros
==============================================================================*/

#define HW_LIB_FAILURE          -1
#define HW_LIB_SUCCESS          0
#define HW_LIB_IVALID_PARAMS    1
#define HW_LIB_CS_FAILURE       2
#define HW_LIB_JSON_FAILURE     3
#define EOK                     0
#define EFAILURE                -1


/*MWO protocol specific*/
#define MWOP_UNSUPPORT_CMD     21
#define MWOP_IVALID_DATA       22

/*==============================================================================
                              Enums
==============================================================================*/

/** enums for possible return type/results */
typedef enum {
        eReturn_ok = 0,
        eReturn_err_unknown = 1,
        eReturn_err_oom = 2, // out of memory
        eReturn_err_oor = 3, // out of range
        eReturn_err_oob = 4, // out of buffer
        eReturn_err_arg = 5, // invalid argument
        eReturn_err_timeout = 6, // time out
        eReturn_err_open_file = 7,
        eReturn_err_create_thread = 8,
        eReturn_err_deny = 9,
        eReturn_err_unsupport = 10,
        eReturn_err_create_msgq = 11,
        eReturn_err_msg_send    = 12,
        eReturn_err_json_format = 13, //Json
        eReturn_err_io = 14,  //IO
} eRetStatus_t;

/*==============================================================================
                              Structures
==============================================================================*/

/** Structure for defining error code and actual error in strings */
typedef struct {
        eRetStatus_t eError;
        char *cpErrorMsg;
} stErrMsg_t;

/*==============================================================================
                              functions prototypes
==============================================================================*/

/*==============================================================================
                              Footer
==============================================================================*/


#endif /* HW_INTERFACE_LIBERRORS_H_ */

/************ (C) COPYRIGHT (c) 2024  Eaden Technology Pte Ltd *********END OF FILE****/
