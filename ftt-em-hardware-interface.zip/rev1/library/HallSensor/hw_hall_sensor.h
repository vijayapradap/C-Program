#ifndef __HALL_SENSOR_H__
#define __HALL_SENSOR_H__

/********************************************************************************
 *      Copyright: 2024 Eaden FTT. All rights reserved.
 *                 All trademarks are owned or licensed by Organization Name,
 *                 its subsidiaries or affiliated companies.
 *
 *       Filename: hall_sensor.h
 *    Description: This hall sensor module count the motor's rpm
 *
 *        Version: 1.0.0
 *         Author: happiest minds
 * 	    Date : April, 03, 2024
 *
 ********************************************************************************/

/*==============================================================================
                              System Includes
==============================================================================*/

/*==============================================================================
                              Project Includes
==============================================================================*/
#include "../inc/hw_interface_liberrors.h"

/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                             Type Defines
==============================================================================*/

/*==============================================================================
                              Macros
==============================================================================*/

/*==============================================================================
                              Enums
==============================================================================*/

/*==============================================================================
                              Structures
==============================================================================*/

/*==============================================================================
                              functions prototypes
==============================================================================*/

/*!
 * @brief		This function initialize the hall sensor
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval 0 		Success
 * @retval -1		Failure
 */
//int8_t HW_HALLSENSOR_fnInit(void);
int8_t HW_HALLSENSOR_fnInit(int8_t *i8_pUartPort);

/*!
 * @brief		This function deinitialize the hall sensor
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
void HW_HALLSENSOR_fnDeinit(void);

/*!
 * @brief		This function read the value from hall sensor
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 */
int8_t HW_HALLSENSOR_fnRead(void);

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd. *********END OF FILE****/

#endif
