/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      fill_light.h
 * @brief     This is the header file for controlling fill light with
 *            main board

 ******************************************************************************
 */


#ifndef _FILL_LIGHT_H_
#define _FILL_LIGHT_H_


/*==============================================================================
*         system includes
================================================================================*/
#include <stdint.h>


/*!
@brief		<b>function to initialize the fill light </b>
@param[in]	None
@param[out]	None
@retval EOK: if fill light init is done
@retval EFAILURE: -1 for error 
*/
//int32_t HW_FILL_LIGHT_fninit();
int32_t HW_FILL_LIGHT_fnInit(int8_t *i32_pI2C_Path);
/*!
@brief		<b>function to turn on fill light </b>
@param[in]	None
@param[out]	None
@retval EOK: if fill light is on
@retval EFAILURE: -1 for error 
*/
int32_t HW_FILL_LIGHT_fnTurnOn();
/*!
@brief		<b>function to turn off fill light </b>
@param[in]	None
@param[out]	None
@retval EOK: if fill light is off
@retval EFAILURE: -1 for error  
*/
int32_t HW_FILL_LIGHT_fnTurnOff();


#endif

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/
