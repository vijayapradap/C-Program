/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      hw_brightness_control.h
 * @brief     This is the header file for controlling brightness of LCD

 ******************************************************************************
 */
 
#ifndef _BRIGHTNESSCONTROL_H_
#define _BRIGHTNESSCONTROL_H_

/*!
@brief		<b>function to initialize the 7 inch screen for brightness control using system commands </b>
@param[in]	None
@param[out]	None
@retval None 
*/
void HW_BrightnessCTRL_fnInit7Inch();

/*!
@brief		<b>function to initialize the 15 inch screen for brightness control using system commands </b>
@param[in]	None
@param[out]	None
@retval None 
*/
void HW_BrightnessCTRL_fnInit15Inch();

/*!
@brief		<b>function to control LCD brightness by changing duty cycle </b>
@param[in]	None
@param[out]	None
@retval EOK: if 15 inch LCD brightness is controlled
@retval EFAILURE: -1 for error 
*/
int32_t HW_BrightnessCTRL_fnControl7Inch(int32_t);

/*!
@brief		<b>function to control LCD brightness by changing duty cycle </b>
@param[in]	None
@param[out]	None
@retval EOK: if 15 inch LCD brightness is controlled
@retval EFAILURE: -1 for error 
*/
int32_t HW_BrightnessCTRL_fnControl15Inch(int32_t);

#endif