/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      hw_brightness_control.c
 * @brief     This is the source file for controlling brightness for 7 and 15 inch LCD

 ******************************************************************************
 */


/*==============================================================================
*         system includes
================================================================================*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*==============================================================================
*         Project includes
================================================================================*/
#include "hw_brightness_control.h"
#include "../inc/hw_interface_liberrors.h"

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
void HW_BrightnessCTRL_fnInit7Inch()
{
    system("echo 0 | sudo tee /sys/class/pwm/pwmchip3/export > /dev/null 2>&1");
    system("echo 2000 | sudo tee  /sys/class/pwm/pwmchip3/pwm0/period > /dev/null 2>&1");
    system("echo 1 | sudo tee /sys/class/pwm/pwmchip3/pwm0/enable > /dev/null 2>&1");
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
void HW_BrightnessCTRL_fnInit15Inch()
{
    system("sudo gpioset 1 15=1");
    system("echo 0 | sudo tee /sys/class/pwm/pwmchip2/export > /dev/null 2>&1");
    system("echo 5000000 | sudo tee  /sys/clss/pwm/pwmchip2/pwm0/period > /dev/null 2>&1");
    system("echo 1 | sudo tee /sys/class/pwm/pwmchip2/pwm0/enable > /dev/null 2>&1");
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BrightnessCTRL_fnControl7Inch(int32_t i32_Percentage7Inch)
{
    char command[150];
    int32_t i32_DutyCycle = 20*i32_Percentage7Inch;
    sprintf(command, " echo %d | sudo tee  /sys/class/pwm/pwmchip3/pwm0/duty_cycle > /dev/null 2>&1 ",i32_DutyCycle);
    int32_t i32_RetVal =  system(command);
    if(0 != i32_RetVal)
    {
        return i32_RetVal;
    }
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BrightnessCTRL_fnControl15Inch(int32_t i32_Percentage15Inch)
{
    char command[100];
    int32_t i32_DutyCycle = 50000*i32_Percentage15Inch;
    sprintf(command, " echo %d | sudo tee  /sys/class/pwm/pwmchip2/pwm0/duty_cycle > /dev/null 2>&1 ",i32_DutyCycle);
    int32_t i32_RetVal =  system(command);
    if(0 != i32_RetVal)
    {
        return i32_RetVal;
    }
    return EOK;
}
