/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 /******************************************************************************
 * @file      power_supply_board.c
 * @brief     This is the source file for power supply board communication with
 *            main board over uart using mwo protocol to control magentron, exhaust
 *            and inverter fan
  ******************************************************************************/

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>
#include <stdint.h>
#include <pthread.h>

/*=============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Private Includes
==============================================================================*/
#include "hw_power_supply_board.h"
#include "../inc/hw_interface_liberrors.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
/*=============================================================================
                              Private Macros
==============================================================================*/
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

#define CONFIG_READ_BUF_SIZE   1024
/*==============================================================================
                              External/Public Variables
==============================================================================*/
PSB_fnDoorStateCallback_t fptr_fnDoorStateCallback = NULL;
PSB_fnFreqBoardExceptionCallback_t fptr_fnFreqBoardExceptionCallback = NULL;

/*==============================================================================
                              Static Variables
==============================================================================*/
static int32_t sgi32_UartFd;

static int8_t sai8_MwopOvenStatuData[] = "{\
\"i32_HeatingState\":%d,\
\"i8_DoorState\":%d,\
\"f32_TotalVoltage\":%.2f,\
\"f32_FreqVoltage\":%.2f,\
\"f32_TotalCurrent\":%.2f,\
\"f32_FreCurrent\":%.2f,\
\"i32_TotalPower\":%d,\
\"i32_FrePower\":%d,\
\"i32_FreTemp\":%d\
}";

static int8_t sai8_MwopPaeReportData[] = "{\
\"i32_HeatingState\":%d,\
\"i8_DoorState\":%d,\
\"f32_TotalVoltage\":%.2f,\
\"f32_FreqVoltage\":%.2f,\
\"f32_TotalCurrent\":%.2f,\
\"f32_FreCurrent\":%.2f,\
\"i32_TotalPower\":%d,\
\"i32_FrePower\":%d,\
\"i32_FreTemp\":%d,\
\"i32_Exception\":%d\
}";

/* Input power */
int32_t m_ipower[] =
{
	1555,
	1535,
	1500,
	1495,
	1475,
	1459,
	1451,
	1435,
	1417,
	1403,
	1390,
	1373,
	1357,
	1346,
	1329,
	1304,
	1285,
	1267,
	1253,
	1241,
	1223,
	1207,
	1191,
	1178,
	1163,
	1145,
	1134,
	1115,
	1101,
	1070,
	1056,
	1040,
	1027,
	1014,
	998,
	984,
	971,
	954,
	935,
	926,
	908,
	891,
	877,
	847,
	829,
	820,
	803,
	786,
	777,
	759,
	743,
	726,
	716,
	697,
	678,
	664,
	641,
	619,
	609,
	591,
	576,
	564,
	545,
	528,
	516,
	501,
	486,
	469,
	449,
	429,
	408,
	393,
	378,
	359,
	348,
	329,
	312,
	300,
	288,
	269,
	249,
	232,
	208,
	194,
	176,
	155,
};

/* Inverter board input frequency */
int32_t m_ifre[] =
{
	500,
	530,
	560,
	590,
	620, 
	650, 
	680, 
	710, 
	740, 
	770, 
	800, 
	830, 
	860, 
	890, 
	920, 
	950, 
	980, 
	1010,
	1040,
	1070,
	1100,
	1130,
	1160,
	1190,
	1220,
	1250,
	1280,
	1310,
	1340,
	1370,
	1400,
	1430,
	1460,
	1490,
	1520,
	1550,
	1580,
	1610,
	1640,
	1670,
	1700,
	1730,
	1760,
	1790,
	1820,
	1850,
	1880,
	1910,
	1940,
	1970,
	2000,
	2030,
	2060,
	2090,
	2120,
	2150,
	2180,
	2210,
	2240,
	2270,
	2300,
	2330,
	2360,
	2390,
	2420,
	2450,
	2480,
	2510,
	2540,
	2570,
	2600,
	2630,
	2660,
	2690,
	2720,
	2750,
	2780,
	2810,
	2840,
	2870,
	2900,
	2930,
	2960,
	2990,
	3020,
	3050,
};



float64_t m_frequence[] =
{
    45.408,
    45.500,
    45.592,
    45.684,
    45.777,
    45.870,
    45.964,
    46.058,
    46.152,
    46.247,
    46.390,
    46.486,
    46.630,
    46.727,
    46.873,
    47.019,
    47.167,
    47.316,
    47.465,
    47.666,
    47.818,
    48.022,
    48.176,
    48.383,
    48.592,
    48.802,
    49.015,
    49.229,
    49.445,
    49.718,
    49.939,
    50.217,
    50.498,
    50.783,
    51.071,
    51.362,
    51.657,
    52.015,
    52.317,
    52.684,
    53.056,
    53.370,
    53.753,
    54.205,
    54.600,
    55.000,
    55.474,
    55.887,
    56.376,
    56.875,
    57.309,
    57.824,
    58.348,
    58.959,
    59.504,
    60.060,
    60.707,
    61.285,
    61.960,
    62.562,
    63.265,
    63.984,
    64.627,
    65.377,
    66.145,
    66.931,
    67.736,
    68.561,
    69.406,
    70.273,
    71.161,
    72.187,
    73.125,
    74.087,
    75.075,
    76.089,
    77.131,
    78.203,
    79.444,
    80.581,
    81.751,
    82.955,
    84.196,
    85.474,
    86.791,
    88.150,
    89.552,
    90.816,
    92.305,
    93.843,
    95.232,
    96.871,
    98.566,
    100.100,
    101.911,
    103.551,
    105.245,
    106.995,
    108.804,
    110.675,
    112.612,
    114.618,
    116.697,
    118.852,
    120.764,
    123.073,
    125.125,
    127.606,
    129.812,
    132.096,
    134.462
};

int32_t m_temperature[] =
{
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59,
    60,
    61,
    62,
    63,
    64,
    65,
    66,
    67,
    68,
    69,
    70,
    71,
    72,
    73,
    74,
    75,
    76,
    77,
    78,
    79,
    80,
    81,
    82,
    83,
    84,
    85,
    86,
    87,
    88,
    89,
    90,
    91,
    92,
    93,
    94,
    95,
    96,
    97,
    98,
    99,
    100,
    101,
    102,
    103,
    104,
    105,
    106,
    107,
    108,
    109,
    110,
};

/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

/*!
@brief		<b> This function is for reading json configuration for power supply board. </b>
@param[in]	 None
@param[out]	 pst_PSBConfig - pointer to PSBConfig_t structure to store read values.
@retval 	int32_t -  errno number or 0 on success
*/
int32_t PSB_fnReadConfig(PSBConfig_t *pst_PSBConfig)
{
    int32_t i32_RetVal = 0;
	int8_t i8_buffer[CONFIG_READ_BUF_SIZE];
    int32_t i32_len = 0;

    /* open the config file*/
	FILE *fp = fopen(PSB_CONFIGFILE, "r");
	if (NULL == fp)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadConfig: Unable to open the file %s, errno = %d\n", PSB_CONFIGFILE, errno);
		return errno;
	}

	/*read the file contents into a string buffer*/
    memset(i8_buffer, 0, CONFIG_READ_BUF_SIZE);
	i32_len = fread(i8_buffer, sizeof(i8_buffer[0]), ARRAY_SIZE(i8_buffer), fp);
    if (!i32_len)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadConfig:  fread() failed: %d\n", i32_len);
        fclose(fp);
        return HW_LIB_FAILURE;
    }

	fclose(fp);

	/* parse the JSON data */
	cJSON *json = cJSON_Parse(i8_buffer);
	if (NULL == json)
    {
		const int8_t *pi8_error_ptr = cJSON_GetErrorPtr();
		if (pi8_error_ptr != NULL)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadConfig: cJSON_Parse Error: %s, errno = %d\n", pi8_error_ptr, errno);
		}
		cJSON_Delete(json);
		return HW_LIB_JSON_FAILURE;
	}

	/* access the JSON data */
	cJSON *PSBConfig = cJSON_GetObjectItemCaseSensitive(json, "power_supply_board");
    
    /*read baudrate config*/
	cJSON *PSBConfigPortName = cJSON_GetObjectItemCaseSensitive(PSBConfig, "uart_port");
	if (cJSON_IsString(PSBConfigPortName) && (NULL != PSBConfigPortName->valuestring))
    {
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadConfig: uart_port: %s\n", PSBConfigPortName->valuestring);
        strcpy(pst_PSBConfig->i8_uartPort, PSBConfigPortName->valuestring);

        /*read baudrate config*/
	    cJSON *PSBConfigBaudrate = cJSON_GetObjectItemCaseSensitive(PSBConfig, "baudrate");
	    if (cJSON_IsNumber(PSBConfigBaudrate))
        {
            MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadConfig: baudrate: %d\n", PSBConfigBaudrate->valueint);
            pst_PSBConfig->i32_baudrate = PSBConfigBaudrate->valueint;

            /*read console_debug config*/
            cJSON *PSBConfigConsoleDebug = cJSON_GetObjectItemCaseSensitive(json, "console_debug");
	        if(NULL != PSBConfigConsoleDebug)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadConfig: console_debug:  %d\n",  cJSON_IsTrue(PSBConfigConsoleDebug));
                pst_PSBConfig->b_consolDebug = cJSON_IsTrue(PSBConfigConsoleDebug);
            }
            else
            {
                i32_RetVal = HW_LIB_JSON_FAILURE;
            }
        }
        else
        {
            i32_RetVal = HW_LIB_JSON_FAILURE;
        }
    }
    else
    {
        i32_RetVal = HW_LIB_JSON_FAILURE;
    }

    /*delete the JSON object*/
	cJSON_Delete(json);
	return i32_RetVal;
}


/*!
@brief		<b> This function is for initializing UART by rading the configs from particular. </b>
@param[in]	 None
@param[out]	 None
@retval 	int32_t - uart init status
*/
int32_t PSB_fnUartInit(int8_t i8_uartPort[], int32_t i32_baudrate, bool b_consolDebug)
{
    PSBUartConfig_t  st_PSBUartConfig;

    memset(&st_PSBUartConfig, 0, sizeof(PSBUartConfig_t));

    st_PSBUartConfig.i32_databits = 8;
    st_PSBUartConfig.i32_stopbits = 1;
    st_PSBUartConfig.i8_parity = 'n';
    st_PSBUartConfig.i8_hardflow = 0;

    int32_t i32_ReturnValue = 0;
    sgi32_UartFd = 0;

    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnUartInit: i8_uartPort %s, i32_baudrate %d,"
                            " b_consolDebug %d\n", i8_uartPort, i32_baudrate, b_consolDebug);

   /*Enable or disable condole debug based on config value*/
    MLOG_fnSetConsole(b_consolDebug);

    /* O_NOCTTY The port never becomes the controlling terminal of the process.*/
    sgi32_UartFd = open(i8_uartPort, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (HW_LIB_FAILURE == sgi32_UartFd)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartInit: Open %s failed, ret = %d errno = %d!\n", \
                        i8_uartPort, sgi32_UartFd, errno);
        return errno;
    }

    st_PSBUartConfig.i32_baudrate =  i32_baudrate;
    i32_ReturnValue = PSB_fnUartSetOpt(st_PSBUartConfig);

    if(EOK == i32_ReturnValue)
    {
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnUartInit: Initalizations completed\n");
    }
    else
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartInit: Initalizations failed\n");
    }
    return i32_ReturnValue;
}

/*!
@brief	    <b> This function is for doing uart setup w.r.t configurations sent from init function. </b>
@param[in]  PSBUartConfig_t - structure contanining params for uart setup, baudrate, databits
            stopbits, parity nits
@param[out]	 None
@retval 	int32_t - uart init status
*/
int32_t PSB_fnUartSetOpt(PSBUartConfig_t st_PSBUartConfig)
{
    static int32_t sai32_speed_arr[] = {B38400, B19200, B9600, B4800, B2400, B1200, B300};
    static int32_t sai32_name_arr[] = {38400, 19200, 9600, 4800, 2400, 1200, 300};
    struct termios st_newtio;
    struct termios st_oldtio;
    int32_t i; /* loop count*/

    memset(&st_newtio, 0, sizeof(st_newtio));
    memset(&st_oldtio, 0, sizeof(st_oldtio));

    if (EOK != tcgetattr(sgi32_UartFd, &st_oldtio) )
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartSetOpt: tcgetattr failed! errno %d\n", errno);
        return errno;
    }
    st_newtio.c_cflag |= CLOCAL | CREAD;
    st_newtio.c_cflag &= ~CSIZE;

    /* set tty speed */
    for (i = 0; i < sizeof(sai32_speed_arr) / sizeof(int); i++)
    {
        if (st_PSBUartConfig.i32_baudrate == sai32_name_arr[i])
        {
            cfsetispeed(&st_newtio, sai32_speed_arr[i]);
            cfsetospeed(&st_newtio, sai32_speed_arr[i]);
        }
    }

    /* set data bits */
    switch (st_PSBUartConfig.i32_databits)
    {
        case eDATABITS_5:
            st_newtio.c_cflag |= CS5;
            break;
        case eDATABITS_6:
            st_newtio.c_cflag |= CS6;
            break;
        case eDATABITS_7:
            st_newtio.c_cflag |= CS7;
            break;
        case eDATABITS_8:
            st_newtio.c_cflag |= CS8;
            break;
        default:
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartSetOpt: unsupported data size %d\n", st_PSBUartConfig.i32_databits);
            return HW_LIB_FAILURE;
            break;
    }

    /* set parity */
    switch (st_PSBUartConfig.i8_parity)
    {
        case 'n':
        case 'N':
            st_newtio.c_cflag &= ~PARENB;    /* Clear parity enable */
            st_newtio.c_iflag &= ~INPCK;     /* Disable input parity check */
            break;
        case 'o':
        case 'O':
            st_newtio.c_cflag |= (PARODD | PARENB); /* Odd parity instead of even */
            st_newtio.c_iflag |= INPCK;     /* Enable input parity check */
            break;
        case 'e':
        case 'E':
            st_newtio.c_cflag |= PARENB;    /* Enable parity */
            st_newtio.c_cflag &= ~PARODD;   /* Even parity instead of odd */
            st_newtio.c_iflag |= INPCK;     /* Enable input parity check */
            break;
        default:
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartSetOpt: unsupported parity %d\n",st_PSBUartConfig.i8_parity);
            return HW_LIB_FAILURE;
    }

    /* set stop bits */
    switch (st_PSBUartConfig.i32_stopbits)
    {
        case eSTOPBITS_1:
            st_newtio.c_cflag &= ~CSTOPB;
            break;
        case eSTOPBITS_2:
            st_newtio.c_cflag |= CSTOPB;
            break;
        default:
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartSetOpt: unsupported stop bits %d\n", st_PSBUartConfig.i32_stopbits);
            return HW_LIB_FAILURE;
    }

    if (st_PSBUartConfig.i8_hardflow)
    {
        st_newtio.c_cflag |= CRTSCTS;
    }
    else
    {
        st_newtio.c_cflag &= ~CRTSCTS;
    }

    st_newtio.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    st_newtio.c_iflag &= ~ (INLCR | ICRNL | IGNCR);
    st_newtio.c_oflag &= ~(ONLCR | OCRNL);
    st_newtio.c_cc[VTIME] = 1;	/* Time-out value (tenths of a second) [!ICANON]. */
    st_newtio.c_cc[VMIN] = 0;	/* Minimum number of bytes read at once [!ICANON]. */

    tcflush(sgi32_UartFd, TCIOFLUSH);

    if (tcsetattr(sgi32_UartFd, TCSANOW, &st_newtio) != 0)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnUartSetOpt: tcsetattr failed\n");
        return HW_LIB_FAILURE;
    }

    return EOK;
}

/*!
@brief	    <b> This function is for sending data over UART. </b>
@param[in]  int8_t *pui8_Buff - set command's buffer to be sent
            ui8_size size of the buffer to be sent
@param[out]	 None
@retval 	int8_t - return status of write function
*/
int32_t PSB_fnSendCommand(uint8_t *pui8_Buff, uint8_t ui8_size)
{
   if ((pui8_Buff == NULL) || (ui8_size == 0))
    {
        MLOG_fnOutput(LOG_WARNING, "LOG_WARNING: fnSendCommand: Fault and error: Invalid params\n");
        return HW_LIB_IVALID_PARAMS;
    }

    /* Introduce a delay to ensure the command interval is greater than 50ms*/
    usleep(50000);

    /* Flush the input and output buffers before sending*/
    tcflush(sgi32_UartFd, TCIOFLUSH);


    /* Write data to the UART */
    int32_t i32_ret = write(sgi32_UartFd, pui8_Buff, ui8_size);
    if (i32_ret != ui8_size) 
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSendCommand: Uart write failed (%d), errno = %d,"
                        " errmsg = %s!\n", i32_ret, errno, strerror(errno));
        return errno;
    }

    MLOG_fnOutput(LOG_DEBUG, "\nLOG_DEBUG: PSB_fnSendCommand: ======================================\n");
    MLOG_fnOutput(LOG_DEBUG, "\nLOG_DEBUG: PSB_fnSendCommand:Number ofBytes written %d: ", ui8_size);
    for(int i = 0; i < ui8_size; i++)
    {
        MLOG_fnOutput(LOG_DEBUG, "%02X ", pui8_Buff[i]);
    }
    MLOG_fnOutput(LOG_DEBUG, "\nLOG_DEBUG: PSB_fnSendCommand======================================\n");
    return EOK;
} 

/*!
@brief	    <b> This function is for reading data over UART. </b>
@param[in]  i32_size size of buffer to be read
            i32_msec timeout value for select function
@param[out]	*pui8_Buff - buffer to be filled by rading
@retval 	int32_t - return status of read function, the number of bytes read
*/
int32_t PSB_fnReadData(uint8_t *pui8_Buff, int32_t i32_size , int32_t i32_msec)
{
   
    int32_t i32_ret = 0;
    struct timeval st_tv;

    int32_t i32_btotal = 0;
    int32_t i32_bread = 0;
    int8_t *i8_buf = pui8_Buff;

    fd_set rfds;

    /*Check for invalid parameters */
    if (pui8_Buff == NULL || i32_size  <= 0)
    {
        return HW_LIB_IVALID_PARAMS;
    }

    /* Loop until the desired length of data is received*/
    while (i32_btotal < i32_size )
    {
        /*Clear the file descriptor set and add the UART file descriptor*/
        FD_ZERO(&rfds);
        FD_SET(sgi32_UartFd, &rfds);

        /*Set the timeout values for the select function*/
        st_tv.tv_sec = i32_msec / 1000;  /* Set the receive wait time in seconds*/
        st_tv.tv_usec = (i32_msec % 1000) * 1000;  /* Convert remaining milliseconds to microseconds*/

        /*Use the select function to wait for data to be available for reading*/
        i32_ret = select(sgi32_UartFd + 1, &rfds, NULL, NULL, &st_tv);

        /* Handle errors during select */
        if ((i32_ret < 0) && (errno != EINTR)) 
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadData: Select failed with error %d\n", errno);
            return errno;
        }

        /* Check if the select function timed out*/
        if (i32_ret == 0)
        {
            if (i32_btotal > 0)
            {
                break;  /* Exit the loop if some data has been received*/
            }
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadData:  timeout without receiving any data\n");
            return HW_LIB_FAILURE;  /* Return -1 for timeout without receiving any data*/
        }

        /* Check if the file descriptor is ready for reading*/
        if (i32_ret)
        {
            if (FD_ISSET(sgi32_UartFd, &rfds))
            {
                /*Attempt to read data from the UART*/
                if ((i32_bread = read(sgi32_UartFd, i8_buf, i32_size  - i32_btotal)) > 0)
                {
                    i32_btotal += i32_bread;
                    i8_buf += i32_bread;
                }

                /* Handle errors during read*/
                if (i32_bread < 0)
                {
                    if (errno != EWOULDBLOCK) 
                    {
                        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadData: select ret == 0, i32_bread < 0!!!\n");
                        return errno;
                    }
                }
            }
        }
    }

    /* Check if any data has been received*/
    if (0 >= i32_btotal)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadData: select i32_btotal <= 0!!!\n");
        return HW_LIB_FAILURE;
    } 
    else 
    {
        return i32_btotal;  /* Return the total number of bytes received*/
    }

}

/*!
@brief	    <b> This function is for reading set and Read command response of MWO protocol. </b>
@param[in]  i32_size size of buffer to be read
@param[out]	*pui8_Recv_buff - buffer to be filled by rading
@retval 	int32_t - return status of read function, the number of bytes read or errno values
                    returned from PSB_fnReadData
*/
int32_t PSB_fnGetCmdResponse(uint8_t *pui8_Recv_buff, uint8_t ui8_size)
{
    int32_t i32_TotalByte = 0;
    int32_t i32_ReceivedByte = 0;
    
    if (0 == ui8_size)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnGetCmdResponse: HW_LIB_IVALID_PARAMS ui8_size is %d\n", ui8_size);
        return HW_LIB_IVALID_PARAMS;
    }

    memset(pui8_Recv_buff , 0 , ui8_size);
            
    i32_ReceivedByte = PSB_fnReadData(pui8_Recv_buff, ui8_size, 200);
    if(ui8_size != i32_ReceivedByte)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnGetCmdResponse: recevied bytes i32_ReceivedByte %d,"
                        " should be %d\n", i32_ReceivedByte, ui8_size);
        return i32_ReceivedByte;/*return the error values returned from PSB_fnReadData*/
    }

    MLOG_fnOutput(LOG_DEBUG, "\nLOG_DEBUG: PSB_fnGetCmdResponse: i32_ReceivedByte:\n");
    for(int32_t i32_i = 0; i32_i < ui8_size; i32_i++)
    {
        MLOG_fnOutput(LOG_DEBUG, "0x%02X ", pui8_Recv_buff[i32_i]);
    }
    return EOK;
}


/*!
@brief	    <b> This function is for calculating Domain Xor value dataframe checksum. </b>
@param[in]  aui8_InputForCS - array of bytes for mwo command for check sum to be calcualted
            ui8_len - length of command array
            uint8_t - pointer to checksum variable to where the  cs to be stored
@param[out]	*pui8_CheckSum - pointer in which the calculated checksum should be filled
@retval 	EOK upon success
            HW_LIB_IVALID_PARAMS if invalid paramterws recived
*/
int32_t PSB_fnGetChecksum(uint8_t aui8_InputForCS[], uint8_t ui8_len, uint8_t *pui8_CheckSum)
{
    if ((NULL == aui8_InputForCS) || (ui8_len <= 0))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnGetChecksum: HW_LIB_IVALID_PARAMS aui8_InputForCS"
                        " should not be null, ui8_len is %d\n", ui8_len);
        return HW_LIB_IVALID_PARAMS;
    }
    uint8_t ui8_TempCS = 0; /*aui8_InputForCS[0];*/
    int32_t i32_i = 0;
    for ( i32_i = 0; i32_i < ui8_len; i32_i++)
    {
        ui8_TempCS ^= aui8_InputForCS[i32_i];
    }
    *pui8_CheckSum = ui8_TempCS;

    return EOK;
}

/*!
@brief	    <b> This function is reading the fan status by sending mwo commands. </b>
@param[in]  uint8_t ui8_FanFunCode - MWOP function code of specific fan to be read
@param[out]	*pst_FanSatatus - pointer in which the status of the fan should be filled
@retval 	i32_ret - EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
*/

int32_t PSB_fnReadFanStatus(uint8_t ui8_FanFunCode, FanSatatus_t *pst_FanSatatus)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = EOK;
    uint8_t ui8_RetryCounts = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x01*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = ui8_FanFunCode; /*0x80 or 0x81 or 0x82*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    if(EOK != (PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum)))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadFanStatus: PSB_fnGetChecksum failed!\n");
        return HW_LIB_CS_FAILURE;
    }

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    do
    {
        i32_ret = PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN);
        if (EOK != i32_ret)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadFanStatus: PSB_fnSendCommand failed, \
                            i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        usleep(200);  /* Sleep for 200 microseconds*/

        i32_ret = PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN);
        if (EOK != i32_ret)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadFanStatus: PSB_fnGetCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", \
                        i32_ret, ui8_RetryCounts);

            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        i32_ret = PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN);
        if (EOK != i32_ret)
        {
            for (int32_t i32_i = 0; i32_i < MWOP_READ_CMD_FAN_ACK_TOTAL_LEN; i32_i++)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadFanStatus: MWO debug uart recv buff[%d]"
                                " = %02x\n", i32_i, aui8_RecvBuff[i32_i]);
            }
            tcflush(sgi32_UartFd, TCIOFLUSH);
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadFanStatus: PSB_fnValidateReadCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            continue;
        }
    
        pst_FanSatatus->state = aui8_RecvBuff[MWOP_DATA_IDX];
        pst_FanSatatus->speed = (((aui8_RecvBuff[MWOP_DATA_IDX+1] & 0xFF) << 8) |
                                (aui8_RecvBuff[MWOP_DATA_IDX+2]  & 0xFF));
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadFanStatus: pst_FanSatatus->state %d, pst_FanSatatus->speed %d \n",\
                     pst_FanSatatus->state, pst_FanSatatus->speed);
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadFanStatus:aui8_RecvBuff[%d] %d,"
                        " aui8_RecvBuff[%d] %d \n", MWOP_DATA_IDX+1, aui8_RecvBuff[MWOP_DATA_IDX+1],
                        MWOP_DATA_IDX+2, aui8_RecvBuff[MWOP_DATA_IDX+2]);
        break;
    } while (ui8_RetryCounts++ < MAX_RW_RETRYS);

    return i32_ret;
}

/*!
@brief	    <b> This function is to validate the fan status got from read commands. </b>
@param[in]  eMWOP_MSG_TYPE_t e_msgtype - the enum value of the MWOP command resopnse to be parsed
            *pui8_buf - structure pointer in which the received buffer stored
            ui8_size - size of the buffer received for read command response
@param[out]	None
@retval 	EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
            MWOP_IVALID_DATA for invalid mwo data
            MWOP_UNSUPPORT_CMD FOR UNSUPPORTED MWO command
*/
int32_t PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_t e_msgtype, uint8_t *pui8_buf, uint8_t ui8_size)
{
    uint8_t ui8_CheckSum = 0;
    uint16_t ui16_speed = 0;

    if (MWOP_START_CODE != pui8_buf[MWOP_START_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: MWOP MWOP_START_CODE %02X!\n",\
                     pui8_buf[MWOP_START_CODE_IDX]);
        return MWOP_IVALID_DATA;
    }

    if (MWOP_CMD_READ_RES != pui8_buf[MWOP_CMD_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: MWOP MWOP_CMD_READ_RES %02X!\n",\
                      pui8_buf[MWOP_CMD_CODE_IDX]);
        return MWOP_IVALID_DATA;
    }

    switch (e_msgtype)
    {
        case eMWOP_MSG_TYPE_READ_FAN_ACK:
            if((MWOP_FUNC_SET_MAG_FAN != pui8_buf[MWOP_FUNC_CODE_IDX]) &&
                (MWOP_FUNC_SET_INV_FAN != pui8_buf[MWOP_FUNC_CODE_IDX]) &&
                (MWOP_FUNC_SET_EXHAUST_FAN != pui8_buf[MWOP_FUNC_CODE_IDX]))
            {
                MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: MWOP INVALID_FUNC_CODE %02X!\n",\
                              pui8_buf[MWOP_FUNC_CODE_IDX]);
                return MWOP_IVALID_DATA;
            }

    if (MWOP_READ_RES_ACK_DATALEN != pui8_buf[MWOP_DATALEN_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Invalid data len(%d),"
                        " should be(%d)\n", pui8_buf[MWOP_DATALEN_IDX],MWOP_READ_RES_ACK_DATALEN);
        return MWOP_IVALID_DATA;
    }

    if ((0 != pui8_buf[MWOP_DATA_IDX]) && (1 != pui8_buf[MWOP_DATA_IDX]))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Invalid status(%d),"
                        " should be 0 or 1\n", pui8_buf[MWOP_DATA_IDX]);
        return MWOP_IVALID_DATA;
    }

    ui16_speed = ((( pui8_buf[MWOP_DATA_IDX +1] & 0xFF) << 8) | ( pui8_buf[MWOP_DATA_IDX +2]  & 0xFF));
    if((0 > ui16_speed) || (100 < ui16_speed))
    {
         MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Invalid speed(%d),"
                        " should be 0 - 100\n", ui16_speed);
        return MWOP_IVALID_DATA;
    }

    if (EOK != PSB_fnGetChecksum(  pui8_buf, ui8_size-1, &ui8_CheckSum))
    {
         MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: PSB_fnGetChecksum failed !\n");
        return HW_LIB_CS_FAILURE;
    }
    else if (ui8_CheckSum != pui8_buf[MWOP_DATA_IDX+MWOP_READ_RES_ACK_DATALEN])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Invalid cs(%02X),"
                   " should be(%02X)\n", pui8_buf[MWOP_DATA_IDX+1], ui8_CheckSum);
        return MWOP_IVALID_DATA;
    }
    break;

    case eMWOP_MSG_TYPE_READ_SV_ACK:
        if(MWOP_FUNC_READ_SOFTVER != pui8_buf[MWOP_FUNC_CODE_IDX])
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: MWOP INVALID_FUNC_CODE %02X!\n",\
                            pui8_buf[MWOP_FUNC_CODE_IDX]);
            return MWOP_IVALID_DATA;
        }

        if (MWOP_READ_SV_DATALEN != pui8_buf[MWOP_DATALEN_IDX])
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Invalid data len(%d),"
                            " should be(%d)\n", pui8_buf[MWOP_DATALEN_IDX],MWOP_READ_SV_DATALEN);
            return MWOP_IVALID_DATA;
        }

        if (EOK != PSB_fnGetChecksum(  pui8_buf, ui8_size-1, &ui8_CheckSum))
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: PSB_fnGetChecksum failed !\n");
            return HW_LIB_CS_FAILURE;
        }
        else if (ui8_CheckSum != pui8_buf[MWOP_DATA_IDX+MWOP_READ_SV_DATALEN])
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Invalid cs(%02X),"
                        " should be(%02X)\n", pui8_buf[MWOP_DATA_IDX+1], ui8_CheckSum);
            return MWOP_IVALID_DATA;
        }
        break;
        default:
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateReadCmdResponse: Unsupport type(%d)!\n", e_msgtype);
            return MWOP_UNSUPPORT_CMD;
            break;
    }

    return EOK;
}


/*!
@brief	    <b> This function is to validate the fan status got from set commands. </b>
@param[in]  eMWOP_MSG_TYPE_t e_msgtype - the enum value of the MWOP command resopnse to be parsed
            uint8_t *pui8_buf - structure pointer in which the received buffer stored
            uint8_t ui8_size - size of the buffer received for set command response
@param[out]	None
@retval 	EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
            MWOP_IVALID_DATA for invalid mwo data
            MWOP_UNSUPPORT_CMD FOR UNSUPPORTED MWO command
*/
int32_t PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_t e_msgtype, uint8_t *pui8_buf, uint8_t ui8_size)
{
    uint8_t ui8_CheckSum = 0;
    
    if (MWOP_START_CODE != pui8_buf[MWOP_START_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: Invalid MWOP_START_CODE %02X,"
                        " should be(%02X)\n", pui8_buf[MWOP_START_CODE_IDX], MWOP_START_CODE );
        return MWOP_IVALID_DATA;
    }

    if (MWOP_CMD_SET_RES != pui8_buf[MWOP_CMD_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: Invalid MWOP_CMD_SET_RES %02X,"
                        " should be(%02X)\n", pui8_buf[MWOP_CMD_CODE_IDX], MWOP_CMD_SET_RES );
        return MWOP_IVALID_DATA;
    }

    switch (e_msgtype)
    {
        case eMWOP_MSG_TYPE_SET_FAN_ACK:
            if((MWOP_FUNC_SET_MAG_FAN != pui8_buf[MWOP_FUNC_CODE_IDX]) &&
                (MWOP_FUNC_SET_INV_FAN != pui8_buf[MWOP_FUNC_CODE_IDX]) &&
                (MWOP_FUNC_SET_EXHAUST_FAN != pui8_buf[MWOP_FUNC_CODE_IDX]))
            {
                MLOG_fnOutput(LOG_ERR, "LOG_ERR: PSB_fnValidateSetCmdResponse: INVALID_FUNC_CODE %02X,"
                                " should be %02X or %02X or %02X!\n", pui8_buf[MWOP_FUNC_CODE_IDX],\
                                MWOP_FUNC_SET_MAG_FAN, MWOP_FUNC_SET_INV_FAN, MWOP_FUNC_SET_EXHAUST_FAN);
                return MWOP_IVALID_DATA;
            }
            break;
        case eMWOP_MSG_TYPE_SET_HEATING_ACK:
            if(MWOP_FUNC_SET_HEATING != pui8_buf[MWOP_FUNC_CODE_IDX])
            {
                MLOG_fnOutput(LOG_ERR, "LOG_ERR: %s: INVALID_FUNC_CODE %02X,"
                                " should be %02X or %02X or %02X!\n", __func__, pui8_buf[MWOP_FUNC_CODE_IDX],\
                                MWOP_FUNC_SET_MAG_FAN, MWOP_FUNC_SET_INV_FAN, MWOP_FUNC_SET_EXHAUST_FAN);
                return MWOP_IVALID_DATA;
            }
            break;
        default:
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: Unsupport type(%d)!\n", e_msgtype);
            return MWOP_UNSUPPORT_CMD;
            break;
    }

    if (MWOP_SET_ACK_DATALEN != pui8_buf[MWOP_DATALEN_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: Invalid data len(%d),"
                        " should be(%d)\n", pui8_buf[MWOP_DATALEN_IDX],MWOP_SET_ACK_DATALEN);
        return MWOP_IVALID_DATA;
    }

    if (0 != pui8_buf[MWOP_DATA_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: Invalid status(%d),"
                    " should be 0\n", pui8_buf[MWOP_DATA_IDX]);
        return MWOP_IVALID_DATA;
    }

    if (EOK != PSB_fnGetChecksum( pui8_buf, ui8_size-1, &ui8_CheckSum))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: PSB_fnGetChecksum failed !\n");
        return HW_LIB_CS_FAILURE;
    }
    else if (ui8_CheckSum != pui8_buf[MWOP_DATA_IDX+1])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateSetCmdResponse: Invalid cs(%02X),"
                        "should be(%02X)\n",  pui8_buf[MWOP_DATA_IDX+1], ui8_CheckSum);
        return MWOP_IVALID_DATA;
    }

    return EOK;
}

/*!
@brief	    <b> This function is to send fan's set command. </b>
@param[in]  ui8_FanFunCode - the function code of fan to set(0x80/0x81/0x82)
            uint8_t ui8_state - state of the fan to be set(start/stop)
            uint16_t ui16_speed - speed of the fan to be set(0-100)
@param[out]	None
@retval 	i32_ret - EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
*/

int32_t PSB_fnSetFan(uint8_t ui8_FanFunCode, uint8_t ui8_state, uint16_t ui16_speed)
{
    uint8_t ui8_FanSetCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = EOK;
    uint8_t ui8_RetryCounts = 0;

    ui8_FanSetCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    ui8_FanSetCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_SET_REQ; /*0x02*/
    ui8_FanSetCmd[MWOP_FUNC_CODE_IDX] = ui8_FanFunCode; /*0x80 or 0x81 or 0x82*/
    ui8_FanSetCmd[MWOP_DATALEN_IDX] = MWOP_FAN_DATALEN; /*0x03*/
    ui8_FanSetCmd[MWOP_DATA_IDX] = (ui8_state & 0xFF); /*0x03*/
    ui8_FanSetCmd[MWOP_DATA_IDX + 1] = ((ui16_speed >> 8) & 0xFF) ; /*fan speed byte 1*/
    ui8_FanSetCmd[MWOP_DATA_IDX + 2] = (ui16_speed & 0xFF) ; /*fan speed byte 0*/

    /*calculate get check sum byte*/
    if(EOK != PSB_fnGetChecksum(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN-1, &ui8_CheckSum))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSetFan: PSB_fnGetChecksum failed !\n");
        return HW_LIB_CS_FAILURE;
    }

    ui8_FanSetCmd[MWOP_DATA_IDX + 3] = ui8_CheckSum;

    do
    {
        i32_ret = PSB_fnSendCommand(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN);
        if (i32_ret != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSetFan: PSB_fnSendCommand failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        usleep(200);  /*Sleep for 200 microseconds*/

        i32_ret = PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);
        if (i32_ret != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSetFan: PSB_fnGetCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        i32_ret = PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_FAN_ACK, aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);
        if (i32_ret != EOK)
        {
            for (int32_t i32_i = 0; i32_i < MWOP_SET_ACK_TOTAL_LEN; i32_i++)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnSetFan: MWO debug uart "
                                "recv buff[%d] = %02X\n", i32_i, aui8_RecvBuff[i32_i]);
            }
            tcflush(sgi32_UartFd, TCIOFLUSH);
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSetFan: PSB_fnValidateSetCmdResponse"
                            "failed, i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            continue;
        }
        break;
} while(ui8_RetryCounts++ < MAX_RW_RETRYS);

    return i32_ret;
}

/*!
@brief	    <b> This function is to validate the data received as PAE(proacrive esaclation) report.
            or data received for read command of microwave oven status </b>
@param[in]  uint8_t ui8_CmdOrRead - read command number or PAE command number
            uint8_t *pui8_buf - structure pointer in which the received buffer stored
            uint8_t ui8_size - size of the buffer received as PAE report or raed oven oven status cmd
@param[out]	None
@retval 	EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
            MWOP_IVALID_DATA for invalid mwo data
*/
int32_t PSB_fnValidateOvenStatusData(uint8_t ui8_ReadCmdOrPAE, uint8_t *pui8_buf, uint8_t ui8_size)
{
    uint8_t ui8_CheckSum = 0;

    if (MWOP_START_CODE != pui8_buf[MWOP_START_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateOvenStatusData: Invalid MWOP_START_CODE %02X,"
                        " should be(%02X)\n", pui8_buf[MWOP_START_CODE_IDX], MWOP_START_CODE );
        return MWOP_IVALID_DATA;
    }

    if (ui8_ReadCmdOrPAE != pui8_buf[MWOP_CMD_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateOvenStatusData: Invalid MWOP_CMD_PAE_REPORT %02X,"
                        " should be(%02X)\n", pui8_buf[MWOP_CMD_CODE_IDX], ui8_ReadCmdOrPAE );
        return MWOP_IVALID_DATA;
    }

    if (MWOP_FUNC_READ_STATUS != pui8_buf[MWOP_FUNC_CODE_IDX])
    {
        MLOG_fnOutput(LOG_ERR, "LOG_ERR: PSB_fnValidateOvenStatusData: MWOP_FUNC_READ_STATUS %02X,"
                        " should be %02X!\n", pui8_buf[MWOP_FUNC_CODE_IDX], MWOP_FUNC_READ_STATUS);
        return MWOP_IVALID_DATA;
    }

    if (MWOP_READ_PAE_STATUS_DATALEN != pui8_buf[MWOP_DATALEN_IDX])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateOvenStatusData: Invalid data len(%d),"
                        " should be(%d)\n", pui8_buf[MWOP_DATALEN_IDX], MWOP_READ_PAE_STATUS_DATALEN);
        return MWOP_IVALID_DATA;
    }

    if (EOK != PSB_fnGetChecksum( pui8_buf, ui8_size-1, &ui8_CheckSum))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateOvenStatusData: PSB_fnGetChecksum failed !\n");
        return HW_LIB_CS_FAILURE;
    }
    else if (ui8_CheckSum != pui8_buf[ui8_size - 1])
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnValidateOvenStatusData: Invalid cs(%02X),"
                        "should be(%02X)\n",  pui8_buf[ui8_size - 1], ui8_CheckSum);
        return MWOP_IVALID_DATA;
    }

    return EOK;
}


void lookupCompFrequence(double fre, int *i_low, int *i_high)
{
    int start, end, mid;
    int array_size = sizeof(m_frequence)/sizeof(m_frequence[0]);

    if (fre < m_frequence[0]) {
        *i_low = 0;
        *i_high = 0;
        return;
    }
    if (fre > m_frequence[array_size-1]) {
        *i_low = array_size - 1;
        *i_high = array_size - 1;
        return;
    }

    /* Do a binary search on compensation table */
    start = 0;
    end = array_size;
    while (start < end) {
        mid = start + (end - start) / 2;
        if (fre < m_frequence[mid]) {
            end = mid;
        } else {
            start = mid + 1;
            if (fre < m_frequence[start])
                end = start;
        }
    }
    /*
     * start == end
     * ohm >= data->comp[end].ohm
     */
    *i_low = end;
    if (fre == m_frequence[end])
        *i_high = end;
    else
        *i_high = end - 1;
}

/**
 * 获取温度（频率转换为温度）
 * @param f64_Frequency
 * @return
 */
/*!
@brief	    <b> This function is to Get Temperature (Frequency to Temperature). </b>
@param[in]  float64_t f64_Frequency - MWOP function code of specific oven status read operation
@param[out]	*pst_FanSatatus - pointer in which the status of the fan should be filled
@retval 	i32_ret - EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
*/
int32_t PSB_fnGetTempFromFrequnece(float64_t f64_Frequency)
{
    int low, high;
    int temp;

    lookupCompFrequence(f64_Frequency, &low, &high);
    if (low == high) {
        /* Unable to use linear approximation */
        temp = m_temperature[low];
    } else {
        temp = m_temperature[low] +
               ((m_temperature[high] - m_temperature[low]) *
                (f64_Frequency - m_frequence[low])) /
               (m_frequence[high] - m_frequence[low]);
    }

    MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: PSB_fnGetTempFromFrequnece: temperature %d\n", temp);

    return temp;
}

/*!
@brief	    <b> This function is reading microwave oven status by sending mwo commands. </b>
@param[in]  uint8_t ui8_FunCode - MWOP function code of specific oven status read operation
@param[out]	*pst_FanSatatus - pointer in which the status of the fan should be filled
@retval 	i32_ret - EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
*/

int32_t PSB_fnReadOvenStatus(uint8_t ui8_FunCode, MWOP_HEATING_STATUS_t *pst_OvenStatus)
{
    uint8_t aui8_OvenStatusReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = EOK;
    uint8_t ui8_RetryCounts = 0;
    float64_t f64_Frequence = 0.0;

    aui8_OvenStatusReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_OvenStatusReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x01*/
    aui8_OvenStatusReadCmd[MWOP_FUNC_CODE_IDX] = ui8_FunCode; /*0x40*/
    aui8_OvenStatusReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_OVEN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    if(EOK != (PSB_fnGetChecksum(aui8_OvenStatusReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum)))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadOvenStatus: PSB_fnGetChecksum failed!\n");
        return HW_LIB_CS_FAILURE;
    }

    aui8_OvenStatusReadCmd[MWOP_DATALEN_IDX + 1] = ui8_CheckSum;

    do
    {
        i32_ret = PSB_fnSendCommand(aui8_OvenStatusReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN);
        if (EOK != i32_ret)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadOvenStatus: PSB_fnSendCommand failed, \
                            i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        usleep(200);  /* Sleep for 200 microseconds*/

        i32_ret = PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN);
        if (EOK != i32_ret)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadOvenStatus: PSB_fnGetCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        i32_ret = PSB_fnValidateOvenStatusData(MWOP_CMD_READ_RES, aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN);
        if (EOK != i32_ret)
        {
            for (int32_t i32_i = 0; i32_i < MWOP_PAE_REPORT_STATUS_TOTAL_LEN; i32_i++)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadOvenStatus: MWO debug uart recv buff[%d]"
                                " = %02x\n", i32_i, aui8_RecvBuff[i32_i]);
            }
            tcflush(sgi32_UartFd, TCIOFLUSH);
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadOvenStatus: PSB_fnValidateOvenStatusData failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            continue;
        }

        /*fillup the structure pointer if the data validated above*/
        pst_OvenStatus->i32_HeatingState = aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_HEATST_IDX];
        pst_OvenStatus->i8_DoorState = aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_DOORST_IDX];
        pst_OvenStatus->f32_TotalVoltage = (float32_t)(((aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_TTVOL_IDX] << 8) | aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_TTVOL_IDX+1]) / 100.0);
        pst_OvenStatus->f32_FreqVoltage = (float32_t)(((aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_FREVOL_IDX] << 8) | aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_FREVOL_IDX+1]) / 100.0);
        pst_OvenStatus->f32_TotalCurrent = (float32_t)(((aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_TTCUR_IDX] << 8) | aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_TTCUR_IDX+1]) / 100.0);
        pst_OvenStatus->f32_FreCurrent = (float32_t)(((aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_FRECUR_IDX] << 8) | aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_FRECUR_IDX+1]) / 100.0);
        pst_OvenStatus->i32_TotalPower = (int32_t)(pst_OvenStatus->f32_TotalVoltage * pst_OvenStatus->f32_TotalCurrent);
        pst_OvenStatus->i32_FrePower = (int32_t)(pst_OvenStatus->f32_FreqVoltage * pst_OvenStatus->f32_FreCurrent);
        f64_Frequence = 28800.0/((aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_FRETEMP_IDX] << 8) | aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_FRETEMP_IDX+1]);
        MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: PSB_fnReadOvenStatus: f64_Frequence %d\n", f64_Frequence);
        pst_OvenStatus->i32_FreTemp = PSB_fnGetTempFromFrequnece(f64_Frequence);
        pst_OvenStatus->i32_Exception = aui8_RecvBuff[MWOP_DATA_IDX+MWOP_PAE_EXCEPTION_IDX];

        int8_t i8_PAEstatusData[512] = {0};
        int32_t i32_DataLen = sizeof(i8_PAEstatusData) - 1;
        snprintf(i8_PAEstatusData, i32_DataLen, sai8_MwopOvenStatuData,
                (int32_t)pst_OvenStatus->i32_HeatingState, (int32_t)pst_OvenStatus->i8_DoorState,
                pst_OvenStatus->f32_TotalVoltage, pst_OvenStatus->f32_FreqVoltage,
                pst_OvenStatus->f32_TotalCurrent, pst_OvenStatus->f32_FreCurrent,
                pst_OvenStatus->i32_TotalPower, pst_OvenStatus->i32_FrePower, pst_OvenStatus->i32_FreTemp);

        MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: PSB_fnReadOvenStatus: %s\n", i8_PAEstatusData);
        break;
    } while (ui8_RetryCounts++ < MAX_RW_RETRYS);

    return i32_ret;
}

/*!
@brief	    <b> This function is thread function for rading pro activ escalation data from power supply
             board via MWOP. </b>
@param[in]  void pointer arguments
@param[out]	none
@retval 	void pointer
*/
void *PSB_fnReadPAEdata(void *arg)
{
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = HW_LIB_FAILURE;

    while(1)
    {
        /*Perform protocol reception processing*/
        MLOG_fnOutput(LOG_DEBUG,"ENTER=========================================================\n");
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: Enter receive thread loop.\n");

        memset(aui8_RecvBuff, 0, sizeof(aui8_RecvBuff));
        i32_ret = PSB_fnReadData(aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN, 200);

        if(MWOP_PAE_REPORT_STATUS_TOTAL_LEN == i32_ret)
        {
            usleep(100000);
            i32_ret = PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN);
            if(EOK != i32_ret)
            {
                MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadPAEdata: PSB_fnValidateOvenStatusData failed i32_ret %d,"
                                " should be %d\n", i32_ret, EOK);
                tcflush(sgi32_UartFd, TCIOFLUSH);
                usleep(1000000);
                continue;
            }

            i32_ret = PSB_fnHandlePAEdata(&aui8_RecvBuff[MWOP_DATA_IDX]);
            if (EOK != i32_ret)
            {
                MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnReadPAEdata: PSB_fnHandlePAEdata failed i32_ret %d,"
                             " should be %d\n", i32_ret, EOK);
                usleep(1000000);
                continue;
            }

            {
                int32_t i32_i = 0;
                for (i32_i=0; i32_i < MWOP_PAE_REPORT_STATUS_TOTAL_LEN; i32_i++)
                {
                  MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadPAEdata: aui8_RecvBuff[%d] = %02X\n", i32_i, aui8_RecvBuff[i32_i]);
                }
            }
        }
        else
        {
            tcflush(sgi32_UartFd, TCIOFLUSH);
        }
        usleep(1000000);
        MLOG_fnOutput(LOG_DEBUG,"LOOP END=========================================================\n");
    }
    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnReadPAEdata Exit OK");
}

/*!
@brief	    <b> This function is for sending the acknowledgement from host to power supply
             board via MWOP once after receiving PAE data. </b>
@param[in]  none
@param[out]	none
@retval 	EOK upon send acknowledge success
            HW_LIB_CS_FAILURE upon check sum failure
            HW_LIB_FAILURE if send acknowledge failed
*/
int32_t PSB_fnSendHostAck(void)
{
    uint8_t ui8_HostAckCmd[12] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t ui8_RetryCounts = 0;
    int32_t i32_ret = HW_LIB_FAILURE;

    ui8_HostAckCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; //0xAA
    ui8_HostAckCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_PAE_REPORT_RES; //0x83
    ui8_HostAckCmd[MWOP_FUNC_CODE_IDX] = MWOP_FUNC_READ_STATUS; //0x40
    ui8_HostAckCmd[MWOP_DATALEN_IDX] = MWOP_PAE_REPORT_ACK_DATALEN; //0x1
    ui8_HostAckCmd[MWOP_DATA_IDX] = DATA_CONFIRM; /*0x0: DATA_CONFIRM 0x1: DATA_UNKNOWN*/

    if (EOK != PSB_fnGetChecksum(ui8_HostAckCmd, MWOP_PAE_HOST_ACK_CS_DATAFRAME_LEN, &ui8_CheckSum))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSendHostAck: PSB_fnGetChecksum failed !\n");
        return HW_LIB_CS_FAILURE;
    }

    ui8_HostAckCmd[MWOP_DATA_IDX + MWOP_PAE_REPORT_ACK_DATALEN] = ui8_CheckSum;

    do
    {
        if ((i32_ret = PSB_fnSendCommand(ui8_HostAckCmd, MWOP_PAE_HOST_ACK_CS_DATAFRAME_LEN+1)) != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSendHostAck: PSB_fnSendCommand failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }
        break;
    } while(ui8_RetryCounts++ < MAX_RW_RETRYS);

    if((MWOP_PAE_HOST_ACK_CS_DATAFRAME_LEN+1) != i32_ret)
    {
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnSendHostAck: PSB_fnGetChecksum success !\n");
        return EOK;
    }
    else
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnSendHostAck: PSB_fnSendCommand failed !\n");
        return HW_LIB_FAILURE;
    }
}

/*!
@brief	    <b> This function is for Processing slave status reporting response using MWOP. </b>
@param[in]  none
@param[out]	none
@retval 	returns PSB_fnSendHostAck()'s return value. it could be
            EOK upon send acknowledge success
            HW_LIB_CS_FAILURE upon check sum failurem
            HW_LIB_FAILURE if send acknowledge failed
*/
int32_t PSB_fnHandlePAEdata(uint8_t *pui8_data)
{
    float64_t f64_Frequence = 0.0;
    MWOP_HEATING_STATUS_t st_status;

    memset(&st_status, 0, sizeof(MWOP_HEATING_STATUS_t));

    st_status.i32_HeatingState = pui8_data[MWOP_PAE_HEATST_IDX];
    st_status.i8_DoorState = pui8_data[MWOP_PAE_DOORST_IDX];
    st_status.f32_TotalVoltage = (float32_t)(((pui8_data[MWOP_PAE_TTVOL_IDX] << 8) | pui8_data[MWOP_PAE_TTVOL_IDX+1]) / 100.0);
    st_status.f32_FreqVoltage = (float32_t)(((pui8_data[MWOP_PAE_FREVOL_IDX] << 8) | pui8_data[MWOP_PAE_FREVOL_IDX+1]) / 100.0);
    st_status.f32_TotalCurrent = (float32_t)(((pui8_data[MWOP_PAE_TTCUR_IDX] << 8) | pui8_data[MWOP_PAE_TTCUR_IDX+1]) / 100.0);
    st_status.f32_FreCurrent = (float32_t)(((pui8_data[MWOP_PAE_FRECUR_IDX] << 8) | pui8_data[MWOP_PAE_FRECUR_IDX+1]) / 100.0);
    st_status.i32_TotalPower = (int32_t)(st_status.f32_TotalVoltage * st_status.f32_TotalCurrent);
    st_status.i32_FrePower = (int32_t)(st_status.f32_FreqVoltage * st_status.f32_FreCurrent);
    f64_Frequence = 28800.0/((pui8_data[MWOP_DATA_IDX+MWOP_PAE_FRETEMP_IDX] << 8) | pui8_data[MWOP_DATA_IDX+MWOP_PAE_FRETEMP_IDX+1]);
    MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: PSB_fnReadOvenStatus: f64_Frequence %d\n", f64_Frequence);
    st_status.i32_FreTemp = PSB_fnGetTempFromFrequnece(f64_Frequence);
    st_status.i32_Exception = pui8_data[MWOP_PAE_EXCEPTION_IDX];

    int8_t i8_PAEstatusData[512] = {0};
    int32_t i32_DataLen = sizeof(i8_PAEstatusData) - 1;
    snprintf(i8_PAEstatusData, i32_DataLen, sai8_MwopPaeReportData,
            (int32_t)st_status.i32_HeatingState,
            (int32_t)st_status.i8_DoorState,
             st_status.f32_TotalVoltage,
             st_status.f32_FreqVoltage,
             st_status.f32_TotalCurrent,
             st_status.f32_FreCurrent,
             st_status.i32_TotalPower,
             st_status.i32_FrePower,
             st_status.i32_FreTemp,
             st_status.i32_Exception);

    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnHandlePAEdata: %s\n", i8_PAEstatusData);

    if ((eMWOP_FRE_EXCEPTION_NONE != st_status.i32_Exception ) && (NULL != fptr_fnFreqBoardExceptionCallback))
    {
        int8_t i8_buffer[4] = {0};
        snprintf(i8_buffer, 4, "%d", st_status.i32_Exception);
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnHandlePAEdata: i8_buffer %d\n", i8_buffer);
        /*Frequency conversion board abnormal callback event callback*/
        fptr_fnFreqBoardExceptionCallback(i8_buffer);
    }
    
    if(NULL != fptr_fnDoorStateCallback)
    {
        int8_t i8_buffer[4] = {0};
        snprintf(i8_buffer, 4, "%d", st_status.i8_DoorState);
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnHandlePAEdata: i8_buffer%s\n", i8_buffer);
        fptr_fnDoorStateCallback(i8_buffer);
    }
    
    /*Send PAE report ack command*/
    return PSB_fnSendHostAck();
}

/*!
@brief	    <b> This function is for registering the call back function for door status
            report whenever the pro active escalation data arrived from power supply board. </b>
@param[in]  none
@param[out]	none
@retval 	returns
            EOK upon successful register
            HW_LIB_FAILURE upon fail of register, if pointer is NULL
*/
int32_t PSB_fnRegisterDoorStateCallback(PSB_fnDoorStateCallback_t fptr_fnCbFun)
{
    if (fptr_fnCbFun == NULL)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnRegisterDoorStateCallback: fptr_fnCbFun is NULL!\n");
        return HW_LIB_FAILURE;
    }

    fptr_fnDoorStateCallback = fptr_fnCbFun;
    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnRegisterDoorStateCallback:"
                    " callback function registered\n");
    return EOK;
}

/*!
@brief	    <b> This function is for un registering the call back function for door status
             report whenever the pro active escalation data arrived from power supply board. </b>
@param[in]  none
@param[out]	none
@retval 	returns EOK upon successful unregister
*/
int32_t PSB_fnUnregisterDoorStateCallback(void)
{
    fptr_fnDoorStateCallback = NULL;
    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnUnregisterDoorStateCallback:"
                    " callback function unregistered\n");
    return EOK;
}

/*!
@brief	    <b> This function is for registering the frequency board i32_Exception call back
            whenever the pro active escalation data arrived from power supply board. </b>
@param[in]  none
@param[out]	none
@retval 	returns
            EOK upon successful register
            HW_LIB_FAILURE upon fail of register, if pointer is NULL
*/
int32_t PSB_fnRegisterFrequenceBoardExceptionCallback(PSB_fnFreqBoardExceptionCallback_t fptr_fnCbFun)
{
    if (fptr_fnCbFun == NULL)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: PSB_fnRegisterFrequenceBoardExceptionCallback:"
                        " fptr_fnCbFun is NULL!\n");
        return HW_LIB_FAILURE;
    }
    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnRegisterFrequenceBoardExceptionCallback:"
                    " callback function registered\n");
    fptr_fnFreqBoardExceptionCallback = fptr_fnCbFun;
    return EOK;
}

/*!
@brief	    <b> This function is for unregistering the frequency board i32_Exception call back </b>
@param[in]  none
@param[out]	none
@retval 	returns
            EOK upon successful unregister
*/
int32_t PSB_fnUregisterFrequenceBoardExceptionCallback(void)
{
    fptr_fnFreqBoardExceptionCallback = NULL;
    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: PSB_fnUregisterFrequenceBoardExceptionCallback:"
                        " callback function unregistered\n");
    return EOK;
}

void PSB_fnLookupCompPower(int32_t i32_Power, int32_t *i32_Low, int32_t *i32_High)
{
    int start, end, mid;
    int array_size = sizeof(m_ipower)/sizeof(m_ipower[0]);

    if (i32_Power >= m_ipower[0]) {
        *i32_Low = 0;
        *i32_High = 0;
        return;
    }

    if (i32_Power <= m_ipower[array_size-1])
    {
        *i32_Low = array_size - 1;
        *i32_High = array_size - 1;
        return;
    }

    /* Do a binary search on compensation table */
    start = 0;
    end = array_size;
    while (start < end) {
        mid = start + (end - start) / 2;

        if (i32_Power >= m_ipower[mid]) {
            end = mid;
        } else {
            start = mid + 1;
            if (i32_Power >= m_ipower[start])
                end = start;
        }
    }
    /*
     * start == end
     * ohm >= data->comp[end].ohm
     */
    *i32_Low = end;
    if (i32_Power == m_ipower[end])
    {
        *i32_High = end;
    }
    else
    {
        *i32_High = end - 1;
    }
}

/*!
@brief	    <b> Obtaining the input frequency of the inverter board (conversion of input power
*           to input frequency) </b>
@param[in]  ui16_InputPower - the input power received from command
@param[out]	None
@retval 	i32_ret - converted frequency
            errno upon failure
*/
int32_t PSB_fnGetFreFromInputPower(uint16_t ui16_InputPower)
{
    int32_t i32_Low = 0, i32_High = 0;
    int32_t i32_Frequence;

    PSB_fnLookupCompPower(ui16_InputPower, &i32_Low, &i32_High);

    if (i32_Low == i32_High)
    {
        /* Unable to use linear approximation */
        i32_Frequence = m_ifre[i32_Low];
    }
    else
    {
        i32_Frequence = m_ifre[i32_Low] + ((m_ifre[i32_High] - m_ifre[i32_Low]) * (ui16_InputPower - m_ipower[i32_Low])) /
               (m_ipower[i32_High] - m_ipower[i32_Low]);
    }

    MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: %s: frequence : %d", __func__, i32_Frequence);

    return i32_Frequence;
}

/*!
@brief	    <b> This function is to send set heat command with fans. </b>
@param[in]  eMWOP_HEATING_STATE e_state - the state of heating start/stop
            int32_t i32_power - power of magnetron 0-1000W)
@param[out]	None
@retval 	i32_ret - EOK upon successfull reading
            errno upon faileure
*/
int32_t PSB_fnSetHeatingWithFans(eMWOP_HEATING_STATE e_state, int32_t i32_power)
{
    uint8_t ui8_HeatSetCmd[16] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = EOK;
    uint8_t ui8_RetryCounts = 0;

    if (((MWOP_HEATING_MIN_POWER > i32_power ) || (MWOP_HEATING_MAX_POWER < i32_power)) && \
        ((eMWOP_HEATING_STOP != e_state) && (eMWOP_HEATING_STOP != e_state)))
    {
        MLOG_fnOutput(LOG_ERR, "LOG_ERR: %s: Invalid parameters\n", __func__);
        return EINVAL;
    }

    MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: %s: i32_power = %d", __func__, i32_power);

    uint8_t ui8_HeatState = e_state;

    uint16_t ui16_InputPower = (uint16_t)(1.5448*i32_power+39.574);

    uint16_t i32_Frequence = PSB_fnGetFreFromInputPower(ui16_InputPower);

    uint8_t ui8_Frequence_h = (uint8_t)((i32_Frequence >> 8) & 0xff);
    uint8_t ui8_Frequence_l = (uint8_t)(i32_Frequence & 0xff);
    uint8_t ui8_period_h = 0;
    uint8_t ui8_period_l = 0;
    uint8_t ui8_cs = 0;

    ui8_HeatSetCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    ui8_HeatSetCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_SET_REQ; /*0x02*/
    ui8_HeatSetCmd[MWOP_FUNC_CODE_IDX] = MWOP_FUNC_SET_HEATING; /*0x01*/
    ui8_HeatSetCmd[MWOP_DATALEN_IDX] = MWOP_HEATING_PARAMS_LEN + 0x06; /*0x0B*/
    ui8_HeatSetCmd[MWOP_DATA_IDX] = ui8_HeatState; /*heat state*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 1] = ui8_Frequence_h ; /*power value lsb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 2] = ui8_Frequence_l ; /*power value msb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 3] = ui8_period_h ; /*perio value lsb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 4] = ui8_period_l ; /*perio value msb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 5] = 0x00 ; /*magnetron fan lsb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 6] = 0x64 ; /*magnetron fan msb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 7] = 0x00 ; /*invertor fan lsb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 8] = 0x64 ; /*invertor fan msb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 9] = 0x00 ; /*exhaust fan lsb byte*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 10] = 0x64 ; /*exhaust fan msb byte*/

    /*calculate get check sum byte*/
    if(EOK != PSB_fnGetChecksum(ui8_HeatSetCmd, MWOP_SET_HEAT_CS_DATAFRAME_LEN + 0x06, &ui8_CheckSum))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnGetChecksum failed !\n", __func__);
        return HW_LIB_CS_FAILURE;
    }

    ui8_HeatSetCmd[MWOP_DATA_IDX + 5 + 6] = ui8_CheckSum;

    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s: start to send heating command", __func__);

    do
    {
        i32_ret = PSB_fnSendCommand(ui8_HeatSetCmd, MWOP_SET_HEAT_CS_DATAFRAME_LEN+06+1);
        if (i32_ret != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnSendCommand failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        usleep(200);  /*Sleep for 200 microseconds*/
        /*response from psb*/
        i32_ret = PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);
        if (i32_ret != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnGetCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        i32_ret = PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_HEATING_ACK, aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);
        if (i32_ret != EOK)
        {
            for (int32_t i32_i = 0; i32_i < MWOP_SET_ACK_TOTAL_LEN; i32_i++)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s: MWO debug uart "
                                "recv buff[%d] = %02X\n", __func__, i32_i, aui8_RecvBuff[i32_i]);
            }
            tcflush(sgi32_UartFd, TCIOFLUSH);
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnValidateSetCmdResponse"
                            "failed, i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            continue;
        }
        break;
} while(ui8_RetryCounts++ < MAX_RW_RETRYS);

    return i32_ret;
}

/*!
@brief	    <b> This function is to send set heat command. </b>
@param[in]  eMWOP_HEATING_STATE e_state - the state of heating start/stop
            int32_t i32_power - power of magnetron 0-900W)
@param[out]	None
@retval 	i32_ret - EOK upon successfull reading
            errno upon faileure
*/

int32_t PSB_fnSetHeating(eMWOP_HEATING_STATE e_state, int32_t i32_power)
{
    uint8_t ui8_HeatSetCmd[16] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = EOK;
    uint8_t ui8_RetryCounts = 0;
    printf("etner %s\n", __func__);

    if ((MWOP_HEATING_MIN_POWER > i32_power ) || (MWOP_HEATING_MAX_POWER < i32_power))
    {
        MLOG_fnOutput(LOG_ERR, "LOG_ERR: %s: Invalid parameters\n", __func__);
        return EINVAL;
    }
    printf("etner %s %d\n", __func__,__LINE__);

    uint16_t i32_Frequence = i32_power / 9;//功率百分比，0~100%对应 0 ~ 900W
    MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: %s: i32_power = %d", __func__, i32_power);

    uint8_t ui8_HeatState = e_state;
    uint8_t ui8_power_h = (uint8_t)((i32_Frequence >> 8) & 0xff);
    uint8_t ui8_period_h = 0;
    uint8_t ui8_power_l = (uint8_t)(i32_Frequence & 0xff);
    uint8_t ui8_period_l = 0;
    uint8_t ui8_cs = 0;
    printf("etner %s %d\n", __func__,__LINE__);

    ui8_HeatSetCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    ui8_HeatSetCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_SET_REQ; /*0x02*/
    ui8_HeatSetCmd[MWOP_FUNC_CODE_IDX] = MWOP_FUNC_SET_HEATING; /*0x01*/
    ui8_HeatSetCmd[MWOP_DATALEN_IDX] = MWOP_HEATING_PARAMS_LEN; /*0x05*/
    ui8_HeatSetCmd[MWOP_DATA_IDX] = ui8_HeatState; /*heat state*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 1] = ui8_power_h ; /*power value higher nibble*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 2] = ui8_power_l ; /*power value lower nibble*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 3] = ui8_period_h ; /*perio value lower nibble*/
    ui8_HeatSetCmd[MWOP_DATA_IDX + 4] = ui8_period_l ; /*perio value lower nibble*/

    /*calculate get check sum byte*/
    if(EOK != PSB_fnGetChecksum(ui8_HeatSetCmd, MWOP_SET_HEAT_CS_DATAFRAME_LEN, &ui8_CheckSum))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnGetChecksum failed !\n", __func__);
        return HW_LIB_CS_FAILURE;
    }
    printf("etner %s %d\n", __func__,__LINE__);

    ui8_HeatSetCmd[MWOP_DATA_IDX + 5] = ui8_CheckSum;

    MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s: start to send heating command", __func__);

    do
    {
        i32_ret = PSB_fnSendCommand(ui8_HeatSetCmd, MWOP_SET_HEAT_CS_DATAFRAME_LEN+1);
        if (i32_ret != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnSendCommand failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        //usleep(200);  /*Sleep for 200 microseconds*/
        /*Receive a reply*/
        i32_ret = PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);
        if (i32_ret != EOK)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnGetCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        i32_ret = PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_HEATING_ACK, aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);
        if (i32_ret != EOK)
        {
            for (int32_t i32_i = 0; i32_i < MWOP_SET_ACK_TOTAL_LEN; i32_i++)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s: MWO debug uart "
                                "recv buff[%d] = %02X\n", __func__, i32_i, aui8_RecvBuff[i32_i]);
            }
            tcflush(sgi32_UartFd, TCIOFLUSH);
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnValidateSetCmdResponse"
                            "failed, i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            continue;
        }
        break;
            printf("retry %d\n", ui8_RetryCounts);

    } while(ui8_RetryCounts++ < MAX_RW_RETRYS);

    printf("etner %s %d i32_ret %d\n", __func__,__LINE__, i32_ret);

    return i32_ret;
}

int32_t PSB_fnStartHeating(int32_t i32_power)
{
    printf("etner %s\n", __func__);
    return PSB_fnSetHeating(eMWOP_HEATING_START, i32_power);
}

int32_t PSB_fnStopHeating(void)
{
    printf("etner %s\n", __func__);
    return PSB_fnSetHeating(eMWOP_HEATING_STOP, 0);
}

/*!
@brief	    <b> This function is for reading the psb board software version. </b>
@param[in]  none
@param[out]	int8_t *i8_SwVersion - address of char array for storing version
@retval 	i32_ret - EOK upon successfull reading
            HW_LIB_CS_FAILURE if checksum failed
*/

int32_t PSB_fnReadSwVersion(int8_t *i8_SwVersion)
{
    uint8_t aui8_ReadSwVersionCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = EOK;
    uint8_t ui8_RetryCounts = 0;

    aui8_ReadSwVersionCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_ReadSwVersionCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x01*/
    aui8_ReadSwVersionCmd[MWOP_FUNC_CODE_IDX] = MWOP_FUNC_READ_SOFTVER; /*0x41 software version read command*/
    aui8_ReadSwVersionCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    if(EOK != (PSB_fnGetChecksum(aui8_ReadSwVersionCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum)))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnGetChecksum failed!\n", __func__);
        return HW_LIB_CS_FAILURE;
    }

    aui8_ReadSwVersionCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    do
    {
        i32_ret = PSB_fnSendCommand(aui8_ReadSwVersionCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN);
        if (EOK != i32_ret)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnSendCommand failed, \
                            i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        usleep(200);  /* Sleep for 200 microseconds*/

        i32_ret = PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_RD_SV_TOTAL_LEN);
        if (EOK != i32_ret)
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnGetCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", \
                        __func__, i32_ret, ui8_RetryCounts);

            tcflush(sgi32_UartFd, TCIOFLUSH);
            continue;
        }

        i32_ret = PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_SV_ACK, aui8_RecvBuff, MWOP_RD_SV_TOTAL_LEN);
        if (EOK != i32_ret)
        {
            for (int32_t i32_i = 0; i32_i < MWOP_RD_SV_TOTAL_LEN; i32_i++)
            {
                MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s: MWO debug uart recv buff[%d]"
                                " = %02x\n", __func__, i32_i, aui8_RecvBuff[i32_i]);
            }

            tcflush(sgi32_UartFd, TCIOFLUSH);
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: %s: PSB_fnValidateReadCmdResponse failed,"
                            " i32_ret = %d, ui8_RetryCounts = %d\n", __func__, i32_ret, ui8_RetryCounts);
            continue;
        }

        memset(i8_SwVersion, 0, 5);
        sprintf(i8_SwVersion, "%d.%d", aui8_RecvBuff[MWOP_DATA_IDX], aui8_RecvBuff[MWOP_DATA_IDX+1]);

        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s: i8_SwVersion %s\n", __func__, i8_SwVersion);
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: %s:aui8_RecvBuff[%d] %d,"
                        " aui8_RecvBuff[%d] %d \n", __func__, MWOP_DATA_IDX+1, aui8_RecvBuff[MWOP_DATA_IDX+1],
                        MWOP_DATA_IDX+2, aui8_RecvBuff[MWOP_DATA_IDX+2]);
        break;
    } while (ui8_RetryCounts++ < MAX_RW_RETRYS);

    return i32_ret;
}
/************ (C) COPYRIGHT (c) 2024  Eaden Technology Pte Ltd *********END OF FILE****/
