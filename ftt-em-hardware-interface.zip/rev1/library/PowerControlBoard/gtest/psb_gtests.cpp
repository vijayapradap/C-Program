#include <gtest/gtest.h>

extern "C" 
{
 //   #include "psb_gtest.c"
    #include "../power_supply_board.h"
    #include "../../inc/hw_interface_liberrors.h"
}

#define ARRAY_SIZE_FOR_CS   4

static PSBConfig_t st_PSBConfig;

static int32_t PSB_fbCallBack(int8_t *data)
{
    return 0;
}
/*TEST(test case name, testname)*/
TEST(PSBReadConfig, CheckReadconfig)
{
    memset(&st_PSBConfig, 0 ,sizeof(PSBConfig_t));
    EXPECT_EQ(0, PSB_fnReadConfig(&st_PSBConfig));
    EXPECT_LE(0, st_PSBConfig.i32_baudrate);//zero should be less than baudrate ex:9600
    EXPECT_STREQ("/dev/ttyTHS1", (const char*)st_PSBConfig.i8_uartPort);
    EXPECT_TRUE((st_PSBConfig.b_consolDebug == true) || (st_PSBConfig.b_consolDebug == false));
}

TEST(PSBfnUartInitTest, CheckInitSucess)
{
    EXPECT_EQ(0, PSB_fnUartInit());
}

TEST(PSBfnUartSetOptTest, CheckUartSetOpt)
{
    PSBUartConfig_t st_PSBUartConfig;

    memset(&st_PSBUartConfig, 0, sizeof(PSBUartConfig_t));

    st_PSBUartConfig.i32_baudrate = st_PSBConfig.i32_baudrate;
    st_PSBUartConfig.i32_databits = 8;
    st_PSBUartConfig.i32_stopbits = 1;
    st_PSBUartConfig.i8_parity = 'n';
    st_PSBUartConfig.i8_hardflow = 0;

    EXPECT_EQ(0, PSB_fnUartSetOpt(st_PSBUartConfig));
}

/*TEST(PSBfnUartInitTest, CheckPermissionError)
{
    ASSERT_EQ(13, PSB_fnUartInit());
}*/

TEST(PSBfnGetChecksum, CheckCheckSumFunctionPtest)
{
    uint8_t aui8_InputForCs[10] = {0xAA, 0x02, 0x80, 0x00};
    uint8_t ui8_CheckSum = 0;
    uint8_t ui8_LocalCS = 0;
    int32_t i32_i = 0;
    
    /*calcualte local CS and keep for testig against PSB_fnGetChecksum() output checksum */
    for ( i32_i = 0; i32_i < ARRAY_SIZE_FOR_CS; i32_i++)
    {
        ui8_LocalCS ^= aui8_InputForCs[i32_i];
    }

    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_InputForCs, ARRAY_SIZE_FOR_CS , &ui8_CheckSum));
    EXPECT_EQ(ui8_LocalCS, ui8_CheckSum);
}

TEST(PSBfnSendCommand, CheckUartWriteOperationPtest)
{
    uint8_t aui8_FanReadCmdGtest[10] = {0};
    uint8_t ui8_CheckSum = 0;
   
    aui8_FanReadCmdGtest[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmdGtest[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x02*/
    aui8_FanReadCmdGtest[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82*/
    aui8_FanReadCmdGtest[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*get checksum*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmdGtest, sizeof(aui8_FanReadCmdGtest), &ui8_CheckSum));
    
    aui8_FanReadCmdGtest[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmdGtest, MWOP_READ_CMD_CS_DATAFRAME_LEN));
}

TEST(PSBfnReadData, CheckUartReadOperationPtest)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x01*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82 - Fan function codes*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum));

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN));

    usleep(1000);  /* Sleep for 1000 microseconds*/    

    /*Read data once after sending command to read from PSB_fnSendCommand */
    i32_ret = PSB_fnReadData(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN, 200);

    /*validate read data once after getting read response from above command*/
    EXPECT_EQ(MWOP_READ_CMD_FAN_ACK_TOTAL_LEN, i32_ret);
}

TEST(PSBfnGetCmdResponse, CheckGetCmdResponsePtest)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x02*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82 - Fan function codes*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum));

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN));

    usleep(200);  /* Sleep for 200 microseconds*/    

    /*validate GetCmdResponse once after sending command from from above PSB_fnSendCommand()*/
    EXPECT_EQ(0, PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));
}

TEST(PSBfnValidateReadCmdResponse, CheckReadCmdResponsePtest)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x02*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82 - Fan function codes*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum));

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN));

    usleep(200);  /* Sleep for 200 microseconds*/    

    /*validate GetCmdResponse once after sending command from from above PSB_fnSendCommand()*/
    EXPECT_EQ(0, PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));
    EXPECT_EQ(0, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));
}

TEST(PSBfnValidateSetCmdResponse, CheckSetCmdResponsePtest)
{
    uint8_t ui8_FanSetCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;
    uint8_t ui8_RetryCounts = 0;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;

    ui8_FanSetCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    ui8_FanSetCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_SET_REQ; /*0x02*/
    ui8_FanSetCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82*/
    ui8_FanSetCmd[MWOP_DATALEN_IDX] = MWOP_FAN_DATALEN; /*0x03*/
    ui8_FanSetCmd[MWOP_DATA_IDX] = (ui8_state & 0xFF); /*0x03*/
    ui8_FanSetCmd[MWOP_DATA_IDX + 1] = ((ui16_speed >> 8) & 0xFF) ; /*fan speed byte 1*/
    ui8_FanSetCmd[MWOP_DATA_IDX + 2] = (ui16_speed & 0xFF) ; /*fan speed byte 0*/

    /*calculate checksum of set command to store in data frame*/
    EXPECT_EQ(0, PSB_fnGetChecksum(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN-1, &ui8_CheckSum));

    ui8_FanSetCmd[MWOP_DATA_IDX + 3] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN));
    i32_ret = PSB_fnSendCommand(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN);

    usleep(200);  // Sleep for 200 microseconds

    /*validate GetCmdResponse once after sending command from from above PSB_fnSendCommand()*/
    EXPECT_EQ(0, PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN));

    EXPECT_EQ(0, PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_FAN_ACK, aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN));
}

TEST(PSBfnReadFanStatus, ReadMagnetronFanStatusPtest)
{
    uint8_t ui8_FanFunCode = 0x80;
    FanSatatus_t st_FanSatatus;

    memset(&st_FanSatatus, 0, sizeof(FanSatatus_t));
    EXPECT_EQ(0, PSB_fnReadFanStatus(ui8_FanFunCode, &st_FanSatatus));
    EXPECT_TRUE((st_FanSatatus.state == 0) || (st_FanSatatus.state == 1));
    EXPECT_TRUE((st_FanSatatus.speed >= 0) && (st_FanSatatus.speed <= 100));
}

TEST(PSBfnReadFanStatus, ReadInvertorFanStatusPtest)
{
    uint8_t ui8_FanFunCode = 0x81;
    FanSatatus_t st_FanSatatus;

    memset(&st_FanSatatus, 0, sizeof(FanSatatus_t));
    EXPECT_EQ(0, PSB_fnReadFanStatus(ui8_FanFunCode, &st_FanSatatus));
    EXPECT_TRUE((st_FanSatatus.state == 0) || (st_FanSatatus.state == 1));
    EXPECT_TRUE((st_FanSatatus.speed >= 0) && (st_FanSatatus.speed <= 100));
}

TEST(PSBfnReadFanStatus, ReadExhaustFanStatusPtest)
{
    uint8_t ui8_FanFunCode = 0x82;
    FanSatatus_t st_FanSatatus;

    memset(&st_FanSatatus, 0, sizeof(FanSatatus_t));
    EXPECT_EQ(0, PSB_fnReadFanStatus(ui8_FanFunCode, &st_FanSatatus));
    EXPECT_TRUE((st_FanSatatus.state == 0) || (st_FanSatatus.state == 1));
    EXPECT_TRUE((st_FanSatatus.speed >= 0) && (st_FanSatatus.speed <= 100));
}

TEST(PSBfnSetFan, StartMagnetronFanPtest)
{
    uint8_t ui8_FanFunCode = 0x80;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    EXPECT_EQ(0, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StartInvertorFanPtest)
{
    uint8_t ui8_FanFunCode = 0x81;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    EXPECT_EQ(0, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StartExhaustFanPtest)
{
    uint8_t ui8_FanFunCode = 0x82;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    EXPECT_EQ(0, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StopMagnetronFanPtest)
{
    uint8_t ui8_FanFunCode = 0x80;
    uint8_t ui8_state = 0;
    uint16_t ui16_speed = 100;/**speed is not valid for stop command*/
    sleep(10);
    EXPECT_EQ(0, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StopInvertorFanPtest)
{
    uint8_t ui8_FanFunCode = 0x81;
    uint8_t ui8_state = 0;
    uint16_t ui16_speed = 100;/**speed is not valid for stop command*/
    EXPECT_EQ(0, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StopExhaustFanPtest)
{
    uint8_t ui8_FanFunCode = 0x82;
    uint8_t ui8_state = 0;
    uint16_t ui16_speed = 100;/**speed is not valid for stop command*/
    sleep(5);
    EXPECT_EQ(0, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

/**PAE data positive tests*/
TEST(PSBfnRegisterDoorStateCallback, RegDoorStateCbPtest)
{
    EXPECT_EQ(0, PSB_fnRegisterDoorStateCallback(PSB_fbCallBack));
}

TEST(PSBfnUnregisterDoorStateCallback, UnregDoorStateCbPtest)
{
    EXPECT_EQ(0, PSB_fnUnregisterDoorStateCallback());
}

TEST(PSBfnRegisterFrequenceBoardExceptionCallback, RegFreqBoardExpCbPtest)
{
    EXPECT_EQ(0, PSB_fnRegisterFrequenceBoardExceptionCallback(PSB_fbCallBack));
}

TEST(PSBfnUnRegisterFrequenceBoardExceptionCallback, UnregFreqBoardExpCbPtest)
{
    EXPECT_EQ(0, PSB_fnUregisterFrequenceBoardExceptionCallback());
}
/*
TEST(PSBfnValidatePAEdata, ValidatePAEdataPtest)
{
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = HW_LIB_FAILURE;

    while(1)
    {
        memset(aui8_RecvBuff, 0, sizeof(aui8_RecvBuff));
        i32_ret = PSB_fnReadData(aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN, 200);
        if(MWOP_PAE_REPORT_STATUS_TOTAL_LEN != i32_ret)
        {
            usleep(1000000);
            continue;
        }
    }
    usleep(100000);
    EXPECT_EQ(HW_LIB_SUCCESS, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));
}*/

TEST(PSBfnSendHostAck, SendPAEHostAckPtest)
{
    EXPECT_EQ(0, PSB_fnSendHostAck());
}

/*TEST(PSBfnHandlePAEdata, HandlePaeDataPtest)
{
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = HW_LIB_FAILURE;

    while(1)
    {
        usleep(10000);
        memset(aui8_RecvBuff, 0, sizeof(aui8_RecvBuff));
        i32_ret = PSB_fnReadData(aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN, 200);
        if(MWOP_PAE_REPORT_STATUS_TOTAL_LEN != i32_ret)
            continue;
    }

    EXPECT_EQ(HW_LIB_SUCCESS, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));
    EXPECT_EQ(HW_LIB_SUCCESS, PSB_fnHandlePAEdata(&aui8_RecvBuff[MWOP_DATA_IDX]));
}*/


/** END PAE data positive tests*/

/*************************** START Negative test cases**********************************/

TEST(PSBfnGetChecksum, CheckSumFunctionNtest)
{
    uint8_t aui8_InputForCs[10] = {0xAA, 0x02, 0x80, 0x00};
    uint8_t ui8_CheckSum = 0;
    uint8_t ui8_LocalCS = 0;
    int32_t i32_i = 0;
    
    /*calcualte local CS and keep for testig against PSB_fnGetChecksum() output checksum */
    for ( i32_i = 0; i32_i < ARRAY_SIZE_FOR_CS; i32_i++)
    {
        ui8_LocalCS ^= aui8_InputForCs[i32_i];
    }

    EXPECT_EQ(HW_LIB_IVALID_PARAMS, PSB_fnGetChecksum(aui8_InputForCs, 0, &ui8_CheckSum));
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_InputForCs, ARRAY_SIZE_FOR_CS-2 , &ui8_CheckSum));
    EXPECT_NE(ui8_LocalCS, ui8_CheckSum);
}

TEST(PSBfnSendCommand, CheckSendCommadNtest)
{
    uint8_t aui8_FanReadCmdGtest[10] = {0};
    uint8_t ui8_CheckSum = 0;
   
    aui8_FanReadCmdGtest[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmdGtest[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x02*/
    aui8_FanReadCmdGtest[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82*/
    aui8_FanReadCmdGtest[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*get checksum*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmdGtest, sizeof(aui8_FanReadCmdGtest), &ui8_CheckSum));
    
    aui8_FanReadCmdGtest[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(HW_LIB_IVALID_PARAMS, PSB_fnSendCommand(aui8_FanReadCmdGtest, 0));/*send 0 as size instead  of MWOP_READ_CMD_CS_DATAFRAME_LEN*/
    EXPECT_EQ(HW_LIB_IVALID_PARAMS, PSB_fnSendCommand(NULL, 0));/*send buf as NULL instead of actual aui8_FanReadCmdGtest*/
    EXPECT_NE(MWOP_READ_CMD_CS_DATAFRAME_LEN, PSB_fnSendCommand(aui8_FanReadCmdGtest, MWOP_READ_CMD_CS_DATAFRAME_LEN-2));/*send buf as NULL instead of actual aui8_FanReadCmdGtest*/
}

TEST(PSBfnReadData, CheckReadDataNtest)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x01*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82 - Fan function codes*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum));

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN));

    usleep(200);  /* Sleep for 200 microseconds*/    

    /*Read data once after sending command to read from PSB_fnSendCommand */
    EXPECT_EQ(HW_LIB_IVALID_PARAMS, PSB_fnReadData(NULL, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN, 200));/*send buffer as NULL instead of actual aui8_RecvBuff*/
    EXPECT_EQ(HW_LIB_IVALID_PARAMS, PSB_fnReadData(aui8_RecvBuff, 0, 200));/*send szie as 0 instaed of MWOP_READ_CMD_FAN_ACK_TOTAL_LEN*/
    EXPECT_EQ(HW_LIB_FAILURE, PSB_fnReadData(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN, 0));/*send msec as 0 and see the result*/
}

TEST(PSBfnGetCmdResponse, CheckGetCmdResponseNtest)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x02*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = 0x83; /*0x80 or 0x81 or 0x82 - Fan function codes*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum));

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN));

    usleep(200);  /* Sleep for 200 microseconds*/    

    /*validate GetCmdResponse once after sending command from from above PSB_fnSendCommand()*/
    EXPECT_EQ(-1, PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN-1));/**send invslid size*/
    EXPECT_EQ(HW_LIB_IVALID_PARAMS, PSB_fnGetCmdResponse(aui8_RecvBuff, 0));/**send size as 0 for recieve buffer*/
}

TEST(PSBfnValidateReadCmdResponse, CheckReadCmdResponseNtest)
{
    uint8_t aui8_FanReadCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    uint8_t aui8_TempRecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;

    aui8_FanReadCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    aui8_FanReadCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_READ_REQ; /*0x02*/
    aui8_FanReadCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82 - Fan function codes*/
    aui8_FanReadCmd[MWOP_DATALEN_IDX] = MWOP_READ_CMD_FAN_DATA_LEN; /*0 length for read command*/

    /*calculate get check sum byte*/
    EXPECT_EQ(0, PSB_fnGetChecksum(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN-1 , &ui8_CheckSum));

    aui8_FanReadCmd[MWOP_DATALEN_IDX+1] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(aui8_FanReadCmd, MWOP_READ_CMD_CS_DATAFRAME_LEN));

    usleep(200);  /* Sleep for 200 microseconds*/    

    /*validate GetCmdResponse once after sending command from from above PSB_fnSendCommand()*/
    EXPECT_EQ(0, PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));

    memcpy(aui8_TempRecvBuff, aui8_RecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN);

    EXPECT_EQ(MWOP_UNSUPPORT_CMD, PSB_fnValidateReadCmdResponse(eMWOPMSG_TYPE_MAX, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));/**send 0 instead of eMWOP_MSG_TYPE_READ_FAN_ACK*/

    aui8_TempRecvBuff[MWOP_START_CODE_IDX] = 0xBB; /*send 0xBA instead of MWOP_CMD_READ_RES 0xAA*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));
    
    aui8_TempRecvBuff[MWOP_START_CODE_IDX] = aui8_RecvBuff[MWOP_START_CODE_IDX]; /*0xAA*/
    aui8_TempRecvBuff[MWOP_CMD_CODE_IDX] = 0xFF;/*send 0xFF instead of MWOP_CMD_READ_RES 0x81*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));

    aui8_TempRecvBuff[MWOP_CMD_CODE_IDX] = aui8_RecvBuff[MWOP_CMD_CODE_IDX]; /*0x81*/
    aui8_TempRecvBuff[MWOP_FUNC_CODE_IDX] = 0XFF; /*send  random value 0xFF instead of 0x81 or 0x82 or 0x82*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));

    aui8_TempRecvBuff[MWOP_FUNC_CODE_IDX] = aui8_RecvBuff[MWOP_FUNC_CODE_IDX]; /*aui8_RecvBuff[MWOP_FUNC_CODE_IDX] 0x81 or 0x82 or 0x82*/
    aui8_TempRecvBuff[MWOP_DATALEN_IDX] = 0XFF; /*send  random value 0xFF instead of actual value 3 in aui8_RecvBuff[3]*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));
    
    aui8_TempRecvBuff[MWOP_DATALEN_IDX] = aui8_RecvBuff[MWOP_DATALEN_IDX]; /*send  aui8_RecvBuff[MWOP_DATALEN_IDX]*/
    aui8_TempRecvBuff[MWOP_DATA_IDX] = 0XFF; /*send  random value 0xFF instead of actual value 0 or 1 in aui8_RecvBuff[3]*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));

    aui8_TempRecvBuff[MWOP_DATA_IDX] = aui8_RecvBuff[MWOP_DATA_IDX]; /*send  value in aui8_RecvBuff[MWOP_DATA_IDX]*/
    aui8_TempRecvBuff[MWOP_DATA_IDX +1] = 0XFF; /*send  random value 0xFF instead of actual value 3 in aui8_RecvBuff[MWOP_DATA_IDX+1]*/
    aui8_TempRecvBuff[MWOP_DATA_IDX +2] = 0XFF; /*send  random value 0xFF instead of actual value 3 in aui8_RecvBuff[MWOP_DATA_IDX+2]*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_READ_FAN_ACK, aui8_TempRecvBuff, MWOP_READ_CMD_FAN_ACK_TOTAL_LEN));
}

TEST(PSBfnValidateSetCmdResponse, CheckSetCmdResponseNtest)
{
    uint8_t ui8_FanSetCmd[10] = {0};
    uint8_t ui8_CheckSum = 0;
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = 0;
    uint8_t ui8_RetryCounts = 0;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    uint8_t aui8_TempRecvBuff[RCV_BUF_SIZE];

    ui8_FanSetCmd[MWOP_START_CODE_IDX] = MWOP_START_CODE; /*0xAA*/
    ui8_FanSetCmd[MWOP_CMD_CODE_IDX] = MWOP_CMD_SET_REQ; /*0x02*/
    ui8_FanSetCmd[MWOP_FUNC_CODE_IDX] = 0x80; /*0x80 or 0x81 or 0x82*/
    ui8_FanSetCmd[MWOP_DATALEN_IDX] = MWOP_FAN_DATALEN; /*0x03*/
    ui8_FanSetCmd[MWOP_DATA_IDX] = (ui8_state & 0xFF); /*0x03*/
    ui8_FanSetCmd[MWOP_DATA_IDX + 1] = ((ui16_speed >> 8) & 0xFF) ; /*fan speed byte 1*/
    ui8_FanSetCmd[MWOP_DATA_IDX + 2] = (ui16_speed & 0xFF) ; /*fan speed byte 0*/

    /*calculate checksum of set command to store in data frame*/
    EXPECT_EQ(0, PSB_fnGetChecksum(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN-1, &ui8_CheckSum));

    ui8_FanSetCmd[MWOP_DATA_IDX + 3] = ui8_CheckSum;

    EXPECT_EQ(0, PSB_fnSendCommand(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN));
    i32_ret = PSB_fnSendCommand(ui8_FanSetCmd, MWOP_SET_FAN_CS_DATAFRAME_LEN);

    usleep(200);  // Sleep for 200 microseconds

    /*validate GetCmdResponse once after sending command from from above PSB_fnSendCommand()*/
    EXPECT_EQ(0, PSB_fnGetCmdResponse(aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN));
    memcpy(aui8_TempRecvBuff, aui8_RecvBuff, MWOP_SET_ACK_TOTAL_LEN);

    EXPECT_EQ(MWOP_UNSUPPORT_CMD, PSB_fnValidateSetCmdResponse(eMWOPMSG_TYPE_MAX, aui8_TempRecvBuff, MWOP_SET_ACK_TOTAL_LEN));/**send 0 instead of eMWOP_MSG_TYPE_SET_FAN_ACK*/

    aui8_TempRecvBuff[MWOP_START_CODE_IDX] = 0xBB; /*send 0xBB instead of 0xAA*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_FAN_ACK, aui8_TempRecvBuff, MWOP_SET_ACK_TOTAL_LEN));/*validate start code*/
    
    aui8_TempRecvBuff[MWOP_START_CODE_IDX] = aui8_RecvBuff[MWOP_START_CODE_IDX]; /*send 0xAA*/
    aui8_TempRecvBuff[MWOP_CMD_CODE_IDX] = 0xFF; /*send 0xFF instead of MWOP_CMD_SET_RES*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_FAN_ACK, aui8_TempRecvBuff, MWOP_SET_ACK_TOTAL_LEN));/*validate command code*/
    
    aui8_TempRecvBuff[MWOP_CMD_CODE_IDX] = aui8_RecvBuff[MWOP_CMD_CODE_IDX]; /*send MWOP_CMD_CODE_IDX*/
    aui8_TempRecvBuff[MWOP_DATALEN_IDX] =  0x00; /*send 0 instead of MWOP_SET_ACK_DATALEN*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_FAN_ACK, aui8_TempRecvBuff, MWOP_SET_ACK_TOTAL_LEN));/**validate data length*/


    aui8_TempRecvBuff[MWOP_DATALEN_IDX] = aui8_RecvBuff[MWOP_DATALEN_IDX]; /*send MWOP_SET_ACK_DATALEN from aui8_RecvBuff*/
    aui8_TempRecvBuff[MWOP_DATA_IDX] =  0xBB; /*send 0xFF instead of 0*/
    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_SET_FAN_ACK, aui8_TempRecvBuff, MWOP_SET_ACK_TOTAL_LEN));/**validate data*/
}

TEST(PSBfnReadFanStatus, ReadMagnetronFanStatusNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    FanSatatus_t st_FanSatatus;

    memset(&st_FanSatatus, 0, sizeof(FanSatatus_t));
    EXPECT_EQ(-1, PSB_fnReadFanStatus(ui8_FanFunCode, &st_FanSatatus));
    EXPECT_TRUE((st_FanSatatus.state == 0) || (st_FanSatatus.state == 1));
    EXPECT_TRUE((st_FanSatatus.speed >= 0) && (st_FanSatatus.speed <= 100));
}

TEST(PSBfnReadFanStatus, ReadInvertorFanStatusNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    FanSatatus_t st_FanSatatus;

    memset(&st_FanSatatus, 0, sizeof(FanSatatus_t));
    EXPECT_EQ(-1, PSB_fnReadFanStatus(ui8_FanFunCode, &st_FanSatatus));
    EXPECT_TRUE((st_FanSatatus.state == 0) || (st_FanSatatus.state == 1));
    EXPECT_TRUE((st_FanSatatus.speed >= 0) && (st_FanSatatus.speed <= 100));
}

TEST(PSBfnReadFanStatus, ReadExhaustFanStatusNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    FanSatatus_t st_FanSatatus;

    memset(&st_FanSatatus, 0, sizeof(FanSatatus_t));
    EXPECT_EQ(-1, PSB_fnReadFanStatus(ui8_FanFunCode, &st_FanSatatus));
    EXPECT_TRUE((st_FanSatatus.state == 0) || (st_FanSatatus.state == 1));
    EXPECT_TRUE((st_FanSatatus.speed >= 0) && (st_FanSatatus.speed <= 100));
}

TEST(PSBfnSetFan, StartMagnetronFanNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    EXPECT_EQ(-1, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StartInvertorFanNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    EXPECT_EQ(-1, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StartExhaustFanNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    uint8_t ui8_state = 1;
    uint16_t ui16_speed = 100;
    EXPECT_EQ(-1, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StopMagnetronFanNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    uint8_t ui8_state = 0;
    uint16_t ui16_speed = 100;/**speed is not valid for stop command*/
    sleep(10);
    EXPECT_EQ(-1, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StopInvertorFanNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    uint8_t ui8_state = 0;
    uint16_t ui16_speed = 100;/**speed is not valid for stop command*/
    EXPECT_EQ(-1, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

TEST(PSBfnSetFan, StopExhaustFanNtest)
{
    uint8_t ui8_FanFunCode = 0x83;
    uint8_t ui8_state = 0;
    uint16_t ui16_speed = 100;/**speed is not valid for stop command*/
    EXPECT_EQ(-1, PSB_fnSetFan(ui8_FanFunCode, ui8_state, ui16_speed));
}

/**PAE data negative tests*/
TEST(PSBfnRegisterDoorStateCallback, RegDoorStateCbNtest)
{
    EXPECT_EQ(0, PSB_fnRegisterDoorStateCallback(NULL));
}

TEST(PSBfnRegisterFrequenceBoardExceptionCallback, RegFreqBoardExpCbNtest)
{
    EXPECT_EQ(-1, PSB_fnRegisterFrequenceBoardExceptionCallback(NULL));
}

/*TEST(PSBfnValidatePAEdata, ValidatePAEdataNtest)
{
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    uint8_t aui8_TempBuff[RCV_BUF_SIZE];
    int32_t i32_ret = HW_LIB_FAILURE;
    uint8_t ui8_CheckSum = 0;

    while(1)
    {
        usleep(10000);
        memset(aui8_RecvBuff, 0, sizeof(aui8_RecvBuff));
        i32_ret = PSB_fnReadData(aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN, 200);
        if(MWOP_PAE_REPORT_STATUS_TOTAL_LEN != i32_ret)
            continue;
    }

    memcpy(aui8_TempBuff,aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN);

    aui8_TempBuff[MWOP_START_CODE_IDX] = 0xBB; /**send 0xBB instead of MWOP_START_CODE*/
//    EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_TempBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));

//    aui8_TempBuff[MWOP_START_CODE_IDX] = MWOP_START_CODE; /**send MWOP_START_CODE*/
 //   aui8_TempBuff[MWOP_CMD_CODE_IDX] = 0xFF; /**send 0xFF instead of MWOP_CMD_PAE_REPORT*/
 //   EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_TempBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));

//    aui8_TempBuff[MWOP_CMD_CODE_IDX] = MWOP_CMD_PAE_REPORT; /**send MWOP_CMD_PAE_REPORT*/
 //   aui8_TempBuff[MWOP_FUNC_CODE_IDX] = 0xFF; /**send 0xFF instead of MWOP_FUNC_READ_STATUS*/
 //   EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_TempBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));

 //   aui8_TempBuff[MWOP_FUNC_CODE_IDX] = MWOP_FUNC_READ_STATUS; /**send MWOP_FUNC_READ_STATUS*/
 //   aui8_TempBuff[MWOP_DATALEN_IDX] = 0xFF; /**send 0xFF instead of MWOP_READ_PAE_STATUS_DATALEN*/
 ///   EXPECT_EQ(MWOP_IVALID_DATA, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_TempBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));

 //   aui8_TempBuff[MWOP_DATALEN_IDX] = MWOP_READ_PAE_STATUS_DATALEN; /**send MWOP_READ_PAE_STATUS_DATALEN*/
 //   EXPECT_EQ(HW_LIB_SUCCESS, PSB_fnGetChecksum( aui8_TempBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN, &ui8_CheckSum));
 //   EXPECT_EQ(MWOP_IVALID_DATA, ui8_CheckSum != aui8_TempBuff[MWOP_PAE_REPORT_STATUS_TOTAL_LEN-1]);
//}

/*TEST(PSBfnHandlePAEdata, HandlePaeDataNtest)
{
    uint8_t aui8_RecvBuff[RCV_BUF_SIZE];
    int32_t i32_ret = HW_LIB_FAILURE;

    while(1)
    {
        usleep(10000);
        memset(aui8_RecvBuff, 0, sizeof(aui8_RecvBuff));
        i32_ret = PSB_fnReadData(aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN, 200);
        if(MWOP_PAE_REPORT_STATUS_TOTAL_LEN != i32_ret)
            continue;
    }

    EXPECT_EQ(HW_LIB_SUCCESS, PSB_fnValidateOvenStatusData(MWOP_CMD_PAE_REPORT, aui8_RecvBuff, MWOP_PAE_REPORT_STATUS_TOTAL_LEN));
    EXPECT_EQ(HW_LIB_FAILURE, PSB_fnHandlePAEdata(&aui8_RecvBuff[MWOP_DATA_IDX]));
}*/

/** END PAE data negative tests*/
/****************** END of Negative test cases *******************/

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
