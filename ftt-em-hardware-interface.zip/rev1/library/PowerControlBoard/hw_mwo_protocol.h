#ifndef MWOP_H_
#define MWOP_H_
/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 ******************************************************************************
 *
 * @file      MwoProtocol.h
 * @brief     This is the header file for power supply board communication with
 *            main board over uart using mwo protocol
  ******************************************************************************
 */


/*==============================================================================
                              System Includes
==============================================================================*/

/*==============================================================================
                              Project Includes
==============================================================================*/
/*==============================================================================
                              Defines
==============================================================================*/


/*==============================================================================
                             Type Defines
==============================================================================*/
typedef float float32_t;
typedef double float64_t;
/*==============================================================================
                              Macros
==============================================================================*/

/*MWO protocol  data frame*/
#define MWOP_START_CODE                 0xAA
#define MWOP_HEATING_PARAMS_LEN         5
#define MWOP_DEFAULT_LEN                5
#define MWOP_FAN_DATALEN                3
#define MWOP_LIGHT_DATALEN              3
#define MWOP_MOTOR_DATALEN              3
#define MWOP_LINKAGE_DATALEN            1
#define MWOP_PAE_REPORT_ACK_DATALEN     1
#define MWOP_READ_CMD_LEN               3

/* MWO protocol commands*/
#define MWOP_CMD_READ_REQ               0x01
#define MWOP_CMD_READ_RES               0x81
#define MWOP_CMD_SET_REQ                0x02
#define MWOP_CMD_SET_RES                0x82
#define MWOP_CMD_PAE_REPORT             0x03
#define MWOP_CMD_PAE_REPORT_RES         0x83

/* MWO protocol function codes */
#define MWOP_FUNC_SET_HEATING           0x01
#define MWOP_FUNC_SET_MAG_FAN           0x80
#define MWOP_FUNC_SET_INV_FAN           0x81
#define MWOP_FUNC_SET_EXHAUST_FAN       0x82
#define MWOP_FUNC_SET_MOTOR             0x03
#define MWOP_FUNC_SET_LIGHT             0x04
#define MWOP_FUNC_SET_OTA               0x05
#define MWOP_FUNC_READ_STATUS           0x40
#define MWOP_FUNC_READ_SOFTVER          0x41
#define MWOP_FUNC_SET_LINKAGE           0x80

/* MWO protocol data len */
#define MWOP_SET_DATALEN                    5
#define MWOP_SET_ACK_DATALEN                1
#define MWOP_READ_SV_DATALEN                2
#define MWOP_READ_PAE_STATUS_DATALEN        0x0D
#define MWOP_SET_ACK_TOTAL_LEN              6     /* AA 82 01 01 00 CS or AA 82	01 01 00 CS*/
#define MWOP_RD_STATUS_TOTAL_LEN            16
#define MWOP_RD_SV_TOTAL_LEN                7
#define MWOP_PAE_REPORT_STATUS_TOTAL_LEN    18
#define MWOP_READ_CMD_FAN_DATA_LEN          0
#define MWOP_READ_CMD_OVEN_DATA_LEN         0
#define MWOP_READ_CMD_FAN_ACK_TOTAL_LEN     8
#define MWOP_READ_RES_ACK_DATALEN           3

#define MWOP_SET_FAN_CS_DATAFRAME_LEN       8
#define MWOP_SET_HEAT_CS_DATAFRAME_LEN      9
#define MWOP_READ_CMD_CS_DATAFRAME_LEN      5
#define MWOP_PAE_HOST_ACK_CS_DATAFRAME_LEN  5


#define MWOP_PAE_HEATST_IDX         0
#define MWOP_PAE_DOORST_IDX         1
#define MWOP_PAE_TTVOL_IDX          2
#define MWOP_PAE_FREVOL_IDX         4
#define MWOP_PAE_TTCUR_IDX          6
#define MWOP_PAE_FRECUR_IDX         8
#define MWOP_PAE_FRETEMP_IDX        10
#define MWOP_PAE_EXCEPTION_IDX      12

#define MWOP_HEATING_MIN_POWER      0
#define MWOP_HEATING_MAX_POWER      1000
/*==============================================================================
                              Enums
==============================================================================*/
typedef enum {
    MWOP_START_CODE_IDX = 0,
    MWOP_CMD_CODE_IDX = 1,
    MWOP_FUNC_CODE_IDX = 2,
    MWOP_DATALEN_IDX = 3,
    MWOP_DATA_IDX = 4,
}EN_MWOP_INDEX;

typedef enum {
    eMWOP_MSG_TYPE_READ_STATUS_ACK = 0,
    eMWOP_MSG_TYPE_SET_HEATING_ACK = 1,
    eMWOP_MSG_TYPE_SET_FAN_ACK = 2,
    eMWOP_MSG_TYPE_REPORT_ACK = 3,
    eMWOP_MSG_TYPE_SET_MOTOR_ACK = 4,
    eMWOP_MSG_TYPE_SET_LIGHT_ACK = 5,
    eMWOP_MSG_TYPE_READ_SV_ACK = 6,   /*Read software version*/
    eMWOP_MSG_TYPE_SET_LINKAGE_ACK = 7,
    eMWOP_MSG_TYPE_READ_FAN_ACK = 8,
    eMWOPMSG_TYPE_MAX,
}eMWOP_MSG_TYPE_t;

typedef enum
{
    eMWOP_FRE_EXCEPTION_NONE = 0, /*No abnormality*/
    eMWOP_FRE_EXCEPTION_INPUT_UNDER_VOLTAGE = 1, /*Input undervoltage*/
    eMWOP_FRE_EXCEPTION_INPUT_OVER_VOLTAGE  = 2, /*Input overvoltage*/
    eMWOP_FRE_EXCEPTION_OVER_CURRENT_PROTECTION = 3, /*Overcurrent protection*/
    eMWOP_FRE_EXCEPTION_OVER_TEMP_PROTECTION = 4, /*Over temperature protection*/
    eMWOP_FRE_EXCEPTION_MAGNETRON_FAIL = 5, /*Magnetron failure*/
    eMWOP_FRE_EXCEPTION_FAST_OVER_CURRENT_PROTECTION = 6, /*Fast overcurrent protection*/
    eMWOP_FRE_EXCEPTION_HIGH_VOLTAGE_VIBRATION_PROTECTION = 7, /*High voltage co-vibration protection*/
    eMWOP_FRE_EXCEPTION_SURGE_PROTECTION = 8, /*surge protection*/
    eMWOP_FRE_EXCEPTION_IPDU_INPUT_VOLTAGE_FAUL = 9, /*Frequency conversion board input voltage failure*/
    eMWOP_FRE_EXCEPTION_AUXILIARY_POWER_SUPPLY_PROTECTION = 10, /*Auxiliary power supply guarantee*/
    eMWOP_FRE_EXCEPTION_VALLEY_DETECTION = 11, /*Bottom detection*/
    eMWOP_FRE_EXCEPTION_HIGH_VOLTAGE_OUTPUT_FAIL = 12, /*High voltage output failure*/
}eMWOP_FREQUENCEBOARD_EXCEPTIONS;

typedef enum
{
    eMWOP_HEATING_STOP = 0,
    eMWOP_HEATING_START = 1,
}eMWOP_HEATING_STATE;
/*==============================================================================
                              Structures
==============================================================================*/
typedef struct {
    int8_t i32_HeatingState;     /*0: Stop, 1: Heating, 2: Abnormal*/
    int8_t i8_DoorState;        /*0: off, 1: on*/
    float32_t f32_TotalVoltage;    /*Total input voltage */
    float32_t f32_FreqVoltage;      /* Frequency conversion board voltage */
    float32_t f32_TotalCurrent;    /* Total input current  */
    float32_t f32_FreCurrent;      /* Frequency conversion board current*/
    int32_t i32_TotalPower;        /* total input power */
    int32_t i32_FrePower;          /* Frequency conversion board power */
    int32_t i32_FreTemp;          /* Inverter board temperature */
    int32_t i32_Exception;          /* Fault information */
}MWOP_HEATING_STATUS_t;

/*==============================================================================
                              functions prototypes
==============================================================================*/

/*==============================================================================
                              Footer
==============================================================================*/

#endif /* MWOP_H_ */
