#ifndef POWER_SUPPLY_BOARD_H_
#define POWER_SUPPLY_BOARD_H_
/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 ******************************************************************************
 *
 * @file      power_supply_board.h
 * @brief     This is the header file for power supply board communication with
 *            main board over uart using mwo protocol
  ******************************************************************************
 */


/*==============================================================================
                              System Includes
==============================================================================*/
#include <syslog.h>
#include <stdint.h>
#include <stdbool.h>

/*==============================================================================
                              Project Includes
==============================================================================*/
#include "hw_mwo_protocol.h"
/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                             Type Defines
==============================================================================*/
typedef int32_t (*PSB_fnDoorStateCallback_t)(int8_t *data);/*callbac function for data*/
typedef int32_t (*PSB_fnFreqBoardExceptionCallback_t)(int8_t *data);/*callbac function for data*/

typedef float float32_t;
typedef double float64_t;
/*====================  ==========================================================
                              Macros
==============================================================================*/
#define PSB_CONFIGFILE "/etc/EADEN/hw_lib/config/HwInterfaceConfig.json"

#define RCV_BUF_SIZE          50

#define MAX_RW_RETRYS         2

#define PSB_DATABITS5         5

/*==============================================================================
                              Enums
==============================================================================*/
typedef enum {
    eDATABITS_5 = 5,
    eDATABITS_6,
    eDATABITS_7,
    eDATABITS_8
}eDATABITS_t;

typedef enum {
    eSTOPBITS_1 = 1,
    eSTOPBITS_2
}eSTOPBITS_t;

typedef enum
{
    DATA_CONFIRM = 0,
    DATA_UNKNOWN = 1,
}eHOST_ACK_DATA_TYPE_t;
/*==============================================================================
                              Structures
==============================================================================*/
typedef struct {
    uint8_t state;
    uint16_t speed;
}FanSatatus_t;

typedef struct
{
    int32_t i32_baudrate;
    int32_t i32_databits;
    int32_t i32_stopbits;
    int8_t i8_parity;
    int8_t i8_hardflow;
}PSBUartConfig_t;


typedef struct {
    int8_t i8_uartPort[15];
    int32_t i32_baudrate;
    bool b_consolDebug;
}PSBConfig_t;
/*==============================================================================
                              functions prototypes
==============================================================================*/

int32_t PSB_fnUartInit(int8_t i8_uartPort[], int32_t i32_baudrate, bool b_consolDebug);
int32_t PSB_fnUartSetOpt(PSBUartConfig_t  st_PSBUartConfig);
int32_t PSB_fnReadConfig(PSBConfig_t *pst_PSBConfig);

int32_t PSB_fnSendCommand(uint8_t *pui8_Buff, uint8_t ui8_size);
int32_t PSB_fnGetCmdResponse(uint8_t *pui8_Recv_buff, uint8_t ui8_size);
int32_t PSB_fnReadData(uint8_t *pui8_Buff, int32_t i32_size , int32_t i32_msec);
int32_t PSB_fnGetChecksum(uint8_t aui8_InputForCS[], uint8_t ui8_len, uint8_t *pui8_CheckSum);
int32_t PSB_fnReadFanStatus(uint8_t ui8_FanFunCode, FanSatatus_t *pst_FanSatatus);
int32_t PSB_fnValidateReadCmdResponse(eMWOP_MSG_TYPE_t e_msgtype, uint8_t *pui8_buf, uint8_t ui8_size);
int32_t PSB_fnValidateSetCmdResponse(eMWOP_MSG_TYPE_t e_msgtype, uint8_t *pui8_buf, uint8_t ui8_size);
int32_t PSB_fnSetFan(uint8_t ui8_FanFunCode, uint8_t ui8_state, uint16_t ui16_speed);

int32_t PSB_fnRegisterDoorStateCallback(PSB_fnDoorStateCallback_t Cbfun);
int32_t PSB_fnUnregisterDoorStateCallback(void);
int32_t PSB_fnRegisterFrequenceBoardExceptionCallback(PSB_fnFreqBoardExceptionCallback_t Cbfun);
int32_t PSB_fnUregisterFrequenceBoardExceptionCallback(void);

int32_t PSB_fnValidateOvenStatusData(uint8_t ui8_CmdOrRead, uint8_t *pui8_buf, uint8_t ui8_size);
int32_t PSB_fnSendHostAck(void);
int32_t PSB_fnHandlePAEdata(uint8_t *pui8_data);
void *PSB_fnReadPAEdata(void *arg);
int32_t PSB_fnReadOvenStatus(uint8_t ui8_FunCode, MWOP_HEATING_STATUS_t *pst_OvenStatus);
int32_t PSB_fnSetHeating(eMWOP_HEATING_STATE e_state, int32_t i32_power);
int32_t PSB_fnStartHeating(int32_t i32_power);
int32_t PSB_fnStopHeating(void);
int32_t PSB_fnSetHeatingWithFans(eMWOP_HEATING_STATE e_state, int32_t i32_power);
int32_t PSB_fnGetFreFromInputPower(uint16_t ui16_InputPower);
void PSB_fnLookupCompPower(int32_t i32_Power, int32_t *i32_Low, int32_t *i32_High);
int32_t PSB_fnReadSwVersion(int8_t *i8_SwVersion);
void lookupCompFrequence(double fre, int *i_low, int *i_high);
int32_t PSB_fnGetTempFromFrequnece(float64_t f64_Frequency);

/*==============================================================================
                              Footer
==============================================================================*/


#endif /* POWER_SUPPLY_BOARD_H_ */

/************ (C) COPYRIGHT (c) 2024  Eaden Technology Pte Ltd *********END OF FILE****/
