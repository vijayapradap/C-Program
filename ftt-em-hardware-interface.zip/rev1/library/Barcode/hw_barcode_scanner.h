/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      barcode_scanner.h
 * @brief     This is the header file for barcode scanner communication with
 *            main board over uart
  *
 ******************************************************************************
 */ 

#ifndef BARCODE_SCANNER_H_
#define BARCODE_SCANNER_H_ 

/*==============================================================================
                            System includes
==============================================================================*/

#include <stdint.h>
#include <syslog.h>
#include <stdbool.h>

/*==============================================================================
                              Private includes
==============================================================================*/

/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                              Macros
==============================================================================*/
#define START_FRAME 0x7E
#define RESERVED_BYTE 0x00
#define BYTES_LENGTH 0x09

/*==============================================================================
                              Enums
==============================================================================*/

/*==============================================================================
                              Structures
==============================================================================*/

/*==============================================================================
                              functions prototypes
==============================================================================*/

/*!
@brief	    <b> This function is for barcode intialization, including uart communication
and setting default commands.</b>
@param[in]	i32_Baudrate - baudarate for uart.
@param[in]	i8_UartPort - path for uart port 
@param[out]	None.
@retval EOK: if intialization Successful.
@retval errno: if intialization failed.  
*/
int32_t HW_BARCODE_fnInit(int32_t i32_Baudrate , int8_t *i8_pUartPort);
/*!
@brief	    <b> This function is for uart setup like baudrate , databits , etc..
            for communication with barcode scanner.</b>
@param[in]	i32_Baudrate - baudarate for uart.
@param[in]	i8_pUartPort - path for uart port 
@param[out]	None
@retval EOK:	if intialization setup Successful.
@retval errno: if intialization failed.
*/
int32_t HW_BARCODE_fnUartInit(int32_t i32_baudrate , int8_t *i8_pUartPort);

/*!
@brief	    <b> Set default configurations for the barcode scanner.</b>
@param[in]	None
@param[out]	None
@retval EOK: Default configurations set successfully.
@retval errno: Failed to set default configurations.
*/
int32_t HW_BARCODE_fnSetDefaultConfigs(void);
/*!
@brief	    <b> Send a command over the UART to the barcode scanner.</b>
@param[in]	ui8_buffer - Pointer to the buffer containing the command to be sent.
@param[in]	i32_size   Size of the buffer (number of bytes) to be sent.
@param[out]	None
@retval EOK: Command sent successfully.
@retval errno: Failed to send the command (invalid parameters or UART write failure).
*/
int32_t HW_BARCODE_fnSendCommand(uint8_t *ui8_pbuffer, int32_t i32_size);
/*!
@brief	    <b> Set the state of the light on the barcode scanner.</b>
@param[in]	state - State to set for the light:
                  - LIGHT_ON: Turn on the light.
                  - LIGHT_OFF: Turn off the light.

@param[out] None
@retval EOK:	Light state changed successfully.
@retval errno: Failed to change the light state (communication or operation failure).
*/
int32_t HW_BARCODE_fnSetLight( int32_t state);
/*!
@brief	    <b> Set the state of the light on the barcode scanner.</b>
@param[in]	i8_OnOffLight - Light state to set:
                             - 1: Turn on the light.
                             - 0 : Turn off the light.
@param[out] None
@retval EOK: 	Light state changed successfully.
@retval errno: Failed to change the light state (communication or operation failure).
*/
int32_t HW_BARCODE_fnLightOnOffState(int8_t i8_OnOffLight);
/*!
@brief	    <b> Create a header for barcode communication.</b>
@param[in]	ui8_length - Length information to be included in the header.
@param[out]	ui8_header - Pointer to the array where the header will be stored.
@retval EOK:	Header created successfully.
@retval errno: Failed to create the header (e.g., null command).
*/
int32_t HW_BARCODE_fnCreateHeader(uint8_t *ui8_pheader, uint8_t ui8_length);
/*!
@brief	    <b> Send a payload command to the barcode scanner.</b>
@param[in]	ui8_commands - Command information to be included in the payload.
@param[in]	i32_size - size of payload data.
@param[out]	None
@retval EOK: Payload command sent successfully.
@retval errno: Failed to send the payload command.
*/
int32_t HW_BARCODE_fnSendPayload(uint8_t *ui8_pcommands , int32_t i32_size);
/*!
@brief	    <b> Read data from the barcode scanner over UART with a timeout.</b>
@param[in]	i32_size - Number of bytes to read.
@param[in]	i32_msec - Timeout value in milliseconds.
@param[out] RecveiveBuffer - Pointer to the buffer where the received data will be stored.
@retval Positive integer: Number of bytes successfully read.
@retval errno: Failed to read data (invalid parameters, timeout, or read error).
*/
int32_t HW_BARCODE_fnReadData(char *pRecveiveBuffer, int32_t i32_size, int32_t i32_msec);
/*!
@brief	    <b> close uart port for barcode scanner</b>
@param[in]	None
@param[out] None
@retval None
@retval None
*/
void HW_BARCODE_fnClose(void);




/*==============================================================================
                              Footer
==============================================================================*/

#endif /* BARCODE_SCANNER_H_ */

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/