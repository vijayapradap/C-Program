/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      barcode_scanner.c
 * @brief     This is the source file for barcode scanner communication with
 *            main board over uart
  *
 ******************************************************************************
 */


/*==============================================================================
                               System includes
==============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <fcntl.h> 
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>
#include <stdint.h>

/*==============================================================================
                              Project includes
==============================================================================*/

/*==============================================================================
                              Private includes
==============================================================================*/
#include "hw_barcode_scanner.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
#include "../inc/hw_interface_liberrors.h"
/*==============================================================================
                              External/Public Variables
==============================================================================*/

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/
static int32_t sgi32_SerialPort = 0;

/*==============================================================================
                              Static array
==============================================================================*/
static int32_t sai32_BaudRate[7] = {B38400, B19200, B9600, B4800, B2400, B1200, B300};
static int32_t sai32_BaudRateValues[7] = {38400, 19200, 9600, 4800, 2400, 1200, 300};

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/


/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnInit(int32_t i32_Baudrate , int8_t *i8_pUartPort)
{
   
    int32_t i32_ReturnValue = HW_BARCODE_fnUartInit(i32_Baudrate,i8_pUartPort);
    i32_ReturnValue = HW_BARCODE_fnSetDefaultConfigs();
    if(EOK != i32_ReturnValue)
    {
        MLOG_fnOutput(LOG_DEBUG,"LOG_DEBUG: BARCODE_fnInit: barcode Initalizations failed,"
        "error = %d",i32_ReturnValue);
        return i32_ReturnValue;
    }
    
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnUartInit(int32_t i32_baudrate , int8_t *i8_pUartPort)
{
    struct termios newtio;
    struct termios oldtio;
    int32_t i32_loop;
    
    /** O_NOCTTY The port never becomes the controlling terminal of the process.*/
    sgi32_SerialPort = open(i8_pUartPort, O_RDWR | O_NOCTTY | O_NONBLOCK);

    if (-1 == sgi32_SerialPort)
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: BARCODE_fnInit Open %s failed,"
        "errno = %d\n",i8_pUartPort, sgi32_SerialPort);
        return sgi32_SerialPort;
    }

    memset(&newtio, 0, sizeof(newtio));
    memset(&oldtio, 0, sizeof(oldtio));

    if (0 != tcgetattr(sgi32_SerialPort, &oldtio))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: BARCODE_fnUartSetOpt: tcgetattr failed errno = %d " , EINVAL);
        close(sgi32_SerialPort);
        return EFAILURE;
    }

    newtio.c_cflag |= CLOCAL | CREAD;
    newtio.c_cflag &= ~CSIZE;

    /** set baudrate  */
    for (i32_loop = 0; i32_loop < sizeof(sai32_BaudRate) / sizeof(int); i32_loop++)
    {
        if (i32_baudrate == sai32_BaudRateValues[i32_loop])
        {
            cfsetispeed(&newtio, sai32_BaudRate[i32_loop]);
            cfsetospeed(&newtio, sai32_BaudRate[i32_loop]);
            break;
        }
    }

    /** set data bits */
    newtio.c_cflag |= CS8;
    /** Clear parity enable */
    newtio.c_cflag &= ~PARENB;    
    /** Disable input parity check */
    newtio.c_iflag &= ~INPCK;
    /** stop bits */
    newtio.c_cflag &= ~CSTOPB;
    /** hardware flow*/
    newtio.c_cflag &= ~CRTSCTS;
    newtio.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    newtio.c_iflag &= ~ (INLCR | ICRNL | IGNCR);
    newtio.c_oflag &= ~(ONLCR | OCRNL);
    /** Time-out value (tenths of a second) [!ICANON]. */
    newtio.c_cc[VTIME] = 1;
    /** Minimum number of bytes read at once [!ICANON]. */
    newtio.c_cc[VMIN] = 0;
    tcflush(sgi32_SerialPort, TCIOFLUSH);

    if(0 != tcsetattr(sgi32_SerialPort, TCSANOW, &newtio))
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: BARCODE_fnUartSetOpt: tcsetattr failed errno = %d " , EINVAL);
        close(sgi32_SerialPort);
        return EFAILURE;
    }
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnSendCommand(uint8_t *ui8_pbuffer, int32_t i32_size) 
{
   if ((ui8_pbuffer == NULL) || (i32_size == 0)) 
    {
        MLOG_fnOutput(LOG_ERR , "LOG_ERR:HW_BARCODE_fnSendCommand: Invalid parameters\n");
        return EINVAL;
    }

    /** Introduce a delay to ensure the command interval is greater than 50ms */
    usleep(50000);
    /** Flush the input and output buffers before sending */
    tcflush(sgi32_SerialPort, TCIOFLUSH);
    /** Write data to the UART */
    int32_t i32_ReturnSize = write(sgi32_SerialPort, ui8_pbuffer, i32_size);

    if (i32_ReturnSize != i32_size) 
    {
        MLOG_fnOutput(LOG_ERR ,"LOG_ERR: HW_BARCODE_fnSendCommand: Uart write failed,"
        "errno = %d\n",i32_ReturnSize);
        return i32_ReturnSize;
    }

    return EOK;
} 

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnSetDefaultConfigs(void) 
{
    uint8_t continuousTriggerMode[6] = {0x03, 0x00, 0x00, 0x02, 0x13, 0xE2};
    uint8_t enableBarcodeTypeIdOutput[6] = {0x04, 0x00, 0x60, 0x04, 0x29, 0x23};
    uint8_t saveUserSettings[6] = {0xFF, 0x00, 0xD9, 0x56, 0x76, 0x53};

    /** Send continuous trigger mode configuration over UART */
    int32_t i32_ReturnStatus = HW_BARCODE_fnSendPayload(continuousTriggerMode , sizeof(continuousTriggerMode)); 
    
    /** Send enable barcode type ID output configuration over UART */
    i32_ReturnStatus = HW_BARCODE_fnSendPayload(enableBarcodeTypeIdOutput , sizeof(enableBarcodeTypeIdOutput));
    
    /**  Send save user settings command over UART */
    i32_ReturnStatus = HW_BARCODE_fnSendPayload(saveUserSettings , sizeof(saveUserSettings));

    if(EOK != i32_ReturnStatus)
    {
        return EFAILURE;
    }

    return EOK;   
} 

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnCreateHeader(uint8_t *ui8_pheader, uint8_t ui8_length)
{
    if ((0 == ui8_length) || (NULL == ui8_pheader))
    {
        MLOG_fnOutput(LOG_ERR, "LOG_ERR: HW_BARCODE_fnCreateHeader: Invalid parameters\n");
        return EINVAL;
    }

    ui8_pheader[0] = START_FRAME;
    ui8_pheader[1] = RESERVED_BYTE;
    ui8_pheader[2] = BYTES_LENGTH;
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnSendPayload(uint8_t *ui8_pcommands , int32_t i32_size)
{
   
   if ((0 == i32_size) || (NULL == ui8_pcommands))
    {
        MLOG_fnOutput(LOG_ERR, "LOG_ERR: HW_BARCODE_fnSendPayload: Invalid parameters\n");
        return EINVAL;
    }

    uint8_t ui8_header[3];
    int32_t i32_ReturnValue = HW_BARCODE_fnCreateHeader(ui8_header , sizeof(ui8_header));
    if(EOK != i32_ReturnValue)
    {
        return i32_ReturnValue;
    }
    uint8_t ui8_packet[i32_size + 3];
    memcpy(ui8_packet , ui8_header , 3);
    memcpy(ui8_packet + 3 , ui8_pcommands , i32_size);
   
    int32_t i32_ReturnStatus = HW_BARCODE_fnSendCommand(ui8_packet , sizeof(ui8_packet));
    if(EOK != i32_ReturnStatus)
    {
        return i32_ReturnStatus;
    }
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnSetLight(int32_t state) 
{
    
    int32_t i32_ReturnStatus = -1;
    uint8_t recv_buf[32] = {0};

    uint8_t LightOnCmd[6] = {0x0C, 0x00, 0x00, 0x0C, 0x26, 0xC2};
    uint8_t LightOffCmd[6] = {0x0C, 0x00, 0x00, 0x00, 0xE7, 0x4E};

    if (1 == state) 
    {
        i32_ReturnStatus = HW_BARCODE_fnSendPayload(LightOnCmd ,sizeof(LightOnCmd));
    } 
    else 
    {
        i32_ReturnStatus = HW_BARCODE_fnSendPayload(LightOffCmd ,sizeof(LightOffCmd));
    }

    if (EOK != i32_ReturnStatus ) 
    {
        MLOG_fnOutput(LOG_ERR, "LOG_ERR: HW_BARCODE_fnSetLight: sendCommand failed,"
        "errno = %d" , i32_ReturnStatus);
        tcflush(sgi32_SerialPort, TCIOFLUSH); 
    }
    
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnLightOnOffState(int8_t i8_OnOffLight)
{
    return HW_BARCODE_fnSetLight(i8_OnOffLight);
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_BARCODE_fnReadData(char *pRecveiveBuffer, int32_t i32_size, int32_t i32_msec) 
 {
    int32_t i32_Returnvalue = 0;
    struct timeval tv;

    int32_t i32_TotalByte = 0;
    int32_t i32_ReadByte = 0;
    char *bufer = pRecveiveBuffer;

    fd_set rfds;

    if((NULL == pRecveiveBuffer) || (0 >= i32_size))
    {
        return EINVAL;
    }

    while (i32_TotalByte < i32_size)
    {
        FD_ZERO(&rfds);
        FD_SET(sgi32_SerialPort, &rfds);
        /** Set the timeout values for the select function */
        tv.tv_sec = i32_msec / 1000; 
        /** 100*1000us = 0.1s */
        tv.tv_usec = (i32_msec % 1000) * 1000; 
         /** Use the select function to wait for data to be available for reading */
        i32_Returnvalue = select(sgi32_SerialPort + 1, &rfds, NULL, NULL, &tv);

        if ((0 > i32_Returnvalue) && (errno != EINTR))
        {
            MLOG_fnOutput(LOG_ERR,"LOG_ERR: HW_BARCODE_fnReadData Select failed with," 
            "error %d\n", i32_Returnvalue);
            return i32_Returnvalue;
        }
        /** Check if the select function timed out */
        if (i32_Returnvalue == 0)
        {
            if (i32_TotalByte > 0)
            {
                break;
            }
            return EFAILURE;
        }

        if (i32_Returnvalue)
        {
            if (FD_ISSET(sgi32_SerialPort, &rfds))
            {
                if ((i32_ReadByte = read(sgi32_SerialPort, bufer, i32_size - i32_TotalByte)) > 0)
                {
                    i32_TotalByte += i32_ReadByte;
                    bufer += i32_ReadByte;
                }

                if (i32_ReadByte < 0)
                {
                    if (errno != EWOULDBLOCK)
                    {
                        return ETIMEDOUT;
                    }
                }
            }
        }
    }

    if (0 >= i32_TotalByte)
    {
        return EFAILURE;
    }
    else
    {
        return i32_TotalByte;
    }
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
void HW_BARCODE_fnClose(void)
{
    if(-1 != sgi32_SerialPort)
    {
        close(sgi32_SerialPort);
        sgi32_SerialPort = -1;
    }
}

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/