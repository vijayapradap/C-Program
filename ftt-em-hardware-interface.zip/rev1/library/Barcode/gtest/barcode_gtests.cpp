#include <gtest/gtest.h>
#include <fcntl.h>

extern "C" 
{
    #include "../barcode_scanner.h"
}

static st_BARCODEConfig_t st_BARCODEConfig;
static st_UART_Config_t st_uartConfig;

/*----------------------- Positive test cases -----------------------------*/

/* check for configuaration file */
TEST(BARCODEReadConfig, CheckReadconfig)
{
    memset(&st_BARCODEConfig, 0 ,sizeof(st_BARCODEConfig_t));
    EXPECT_EQ(0, BARCODE_fnReadConfig(&st_BARCODEConfig));
    EXPECT_LE(0, st_BARCODEConfig.i32_baudrate);//zero should be less than baudrate ex:9600
    EXPECT_STREQ("/dev/ttyTHS1", (const char*)st_BARCODEConfig.i8_uartPort);
    EXPECT_TRUE((st_BARCODEConfig.b_consolDebug == true) || (st_BARCODEConfig.b_consolDebug == false));
}

/* barcode initialization status check */
TEST(BARCODE_fnInit , BarcodeInitStatus_1)
{
    ASSERT_EQ(BARCODE_fnInit() , 0);
    ASSERT_NE(BARCODE_fnInit(), -1);
}

TEST(BARCODE_fnInit , BarcodeInitStatus_2)
{
    int32_t RetUartVal = -1;
    int32_t RetSetCmd = -1;
    RetUartVal = BARCODE_fnUartInit();
    RetSetCmd = BARCODE_fnSetDefaultConfigs();
    ASSERT_EQ(RetUartVal , 0);
    ASSERT_EQ(RetSetCmd , 0);

}

/* check status for uart init function */
TEST(BARCODE_fnUartInit , UartInitStatus_1)
{
    ASSERT_EQ(BARCODE_fnUartInit() , 0);
}

TEST(BARCODE_fnUartInit , UartInitStatus_2)
{
    int32_t sgi32_SerialPort = open("/dev/ttyTHS1", O_RDWR | O_NOCTTY);
    ASSERT_GT(sgi32_SerialPort , 0);

}

/* check status for uart setup function */
TEST(BARCODE_fnUartSetOpt, CheckUartSetOptSuccess)
{
    memset(&st_uartConfig, 0, sizeof(st_UART_Config_t));
    st_uartConfig.databits = 8;
    st_uartConfig.stopbits = 1;
    st_uartConfig.parity = 'n';
    st_uartConfig.hardflow = 0;
    EXPECT_EQ(0, BARCODE_fnUartSetOpt(st_uartConfig));
}

/* check status for header creation function */
TEST(BARCODE_fnCreateHeaderTest, Success) 
{
    const uint8_t ui8_command = 0x7E; 
    const uint8_t ui8_length = 0x09; 
    uint8_t ui8_header[4];
    int32_t result = BARCODE_fnCreateHeader(ui8_header, ui8_length, ui8_command);
    EXPECT_EQ(0, result);
    EXPECT_EQ(START_FRAME, ui8_header[0]); /* 0x7E */
    EXPECT_EQ(RESERVED_BYTE, ui8_header[1]); /* 0x00 */
    EXPECT_EQ(ui8_length, ui8_header[2]);
    EXPECT_EQ(ui8_command, ui8_header[3]);
}

/* check for payload command sned function*/
TEST(BARCODE_fnsendPayloadTest, CheckSuccess) 
{
    const uint8_t ui8_command = 0x01; 
    const uint8_t ui8_payload[] = {0x02, 0x03}; 
    const uint8_t ui8_payloadLength = sizeof(ui8_payload) / sizeof(ui8_payload[0]);
    int32_t result = BARCODE_fnsendPayload(ui8_command, ui8_payload, ui8_payloadLength);
    EXPECT_EQ(0, result);
    
}

/* check status of ContinuousTriggerMode commands  */
TEST(BARCODE_fnSetContinuousTriggerMode , ContinuousTriggerMode)
{
    int32_t retVal = -1;
    uint8_t payload[PAYLOAD_SIZE] = {0x00, 0x00, 0x02, 0x13, 0xE2};/*payload*/
    retVal = BARCODE_fnsendPayload(0x03, payload, sizeof(payload));
    ASSERT_EQ(retVal,0);
}

/* check status of BarcodeTypeIdOutput commands  */
TEST(BARCODE_fnEnableBarcodeTypeIdOutput, BarcodeTypeIdOutput)
{
    int32_t retVal = -1;
    uint8_t payload[PAYLOAD_SIZE] = {0x00, 0x60, 0x04, 0x29, 0x23}; /*payload*/
    retVal = BARCODE_fnsendPayload(0x04, payload, sizeof(payload));
    ASSERT_EQ(retVal,0);
}

/* check status of SaveUserSettings commands  */
TEST(BARCODE_fnSaveUserSettings, SaveUserSettings)
{
    int32_t retVal = -1;
    uint8_t payload[PAYLOAD_SIZE] = {0x00, 0xD9, 0x56, 0x76, 0x53};/*payload*/
    retVal = BARCODE_fnsendPayload(0xFF, payload, sizeof(payload));
    ASSERT_EQ(retVal,0);
}

/* check for default command sent to barcode */
TEST(BARCODE_fnSetDefaultConfigs , SetDefaultConfigs_1)
{
    ASSERT_EQ(BARCODE_fnSetDefaultConfigs(),0);
}

/** check for set default condition */
TEST(BARCODE_fnSetDefaultConfigs , SetDefaultConfigs_2)
{
    ASSERT_EQ(BARCODE_fnSetContinuousTriggerMode() , 0);
    ASSERT_EQ(BARCODE_fnEnableBarcodeTypeIdOutput() , 0);
    ASSERT_EQ(BARCODE_fnSaveUserSettings() , 0);

}

/* check status of commands sent to barcode */
TEST(BARCODE_fnSendCommand , SendCommandStatus_1)
{
    uint8_t payload[PAYLOAD_SIZE] = {0x00, 0xD9, 0x56, 0x76, 0x53};
    ASSERT_EQ(BARCODE_fnSendCommand(payload, PAYLOAD_SIZE) , 0); 
}

TEST(BARCODE_fnSendCommand , SendCommandStatus_3)
{
    uint8_t payload[PAYLOAD_SIZE] = {0x00, 0xD9, 0x56, 0x76, 0x53};
    int32_t sgi32_SerialPort = 1;
    int32_t i32_ret = write(sgi32_SerialPort, payload, PAYLOAD_SIZE);
    EXPECT_EQ(i32_ret , PAYLOAD_SIZE);
}

/* check status of light On command sent to barcode */
TEST(BARCODE_fnSetLightOnCommand , LightONStatus)
{
    /* payload */
    uint8_t turnOnLightPayload[LIGHT_PAYLOAD_SIZE] = {0x0C, 0x00, 0x00, 0x0C, 0x26, 0xC2};
    ASSERT_EQ(0, BARCODE_fnsendPayload(0x0C, turnOnLightPayload, sizeof(turnOnLightPayload)));
}

/* check status of light OFF command sent to barcode */
TEST(BARCODE_fnSetLightOffCommand , LightOFFStatus)
{
    uint8_t turnOffLightPayload[LIGHT_PAYLOAD_SIZE] = {0x0C, 0x00, 0x00, 0x00, 0xE7, 0x4E};
    ASSERT_EQ(0, BARCODE_fnsendPayload(0x0C, turnOffLightPayload, sizeof(turnOffLightPayload)));
}

TEST(BARCODE_fnSetLight , SetLightstatus)
{
    /** check for light on */
    int32_t retVal_LightOn = BARCODE_fnSetLight(LIGHT_ON); 
    /** check for light off */
    int32_t retVal_LightOff = BARCODE_fnSetLight(LIGHT_OFF); 
    ASSERT_EQ(0,retVal_LightOn);
    ASSERT_EQ(0, retVal_LightOff);
     
}

/* check status of light on and off state for  barcode */
TEST(BARCODE_fnLightOnOffState , LightOnOff)
{
    ASSERT_EQ(0,BARCODE_fnLightOnOffState(LIGHT_ON));
    ASSERT_EQ(0,BARCODE_fnLightOnOffState(LIGHT_OFF));
}

/*----------------------- Negative test cases -----------------------------*/

TEST(BARCODE_fnUartInit , UartInitStatusFail)
{
    /** check failure by opning wrong serial port */
    int32_t sgi32_SerialPort = open("/dev/ttyTH", O_RDWR | O_NOCTTY);
    ASSERT_EQ(sgi32_SerialPort , -1);
}

TEST(BARCODE_fnUartSetOpt, CheckUartSetOptFailure)
{
    memset(&st_uartConfig, 0, sizeof(st_UART_Config_t));
    st_uartConfig.databits = 9; /*worng databits*/
    st_uartConfig.stopbits = 3; /*worng stopbits*/
    st_uartConfig.parity = 'v'; /*worng parity*/
    st_uartConfig.hardflow = 3; /*worng  hardflow*/

    EXPECT_EQ(-1, BARCODE_fnUartSetOpt(st_uartConfig));
}

TEST(BARCODE_fnCreateHeaderTest, Failure_NullCommand) 
{
    const uint8_t ui8_command = 0x00; /* null command*/  
    uint8_t ui8_header[4];
    /** check for failure by passing zero command length and null command*/
    int32_t result = BARCODE_fnCreateHeader(ui8_header, 0, ui8_command);
    EXPECT_EQ(-1, result);
}

TEST(BARCODE_fnsendPayloadTest, Failure_HeaderCreation) 
{
    int32_t ReturnValue = 0;
    int32_t result;
    uint8_t ui8_header[4];
    const uint8_t ui8_command = 0x00; 
    const uint8_t ui8_payload[] = {0x02, 0x03};
    /** check for failure by passing zero command length and null command*/
    ReturnValue = BARCODE_fnCreateHeader(ui8_header, 0, ui8_command);
    if(ReturnValue < 0)
    {
       result = ReturnValue;
    }
    else
    {
        result = ReturnValue;
    }
    
    ASSERT_EQ(result , -1);   
}

TEST(BARCODE_fnReadDataTest, ReadDataInvalidParameters) 
{
    int32_t bufferSize = 10;
    uint8_t* receivedData = NULL;
    /** check for failure by passing null buffer*/
    int32_t result = BARCODE_fnReadData(receivedData, bufferSize, 1000);
    EXPECT_EQ(-1, result); 
}
    
TEST(BARCODE_fnInvokeCallbackTest, InvokeCallbackFailure_InvalidData) 
{
    uint8_t* invalidData = nullptr;
    /** Null callback function*/
    int32_t result = BARCODE_fnInvokeCallback(invalidData);
    EXPECT_EQ(-1, result);
}

TEST(BARCODE_fnInvokeCallback , CheckFailure)
{
    BarcodeCallback g_callback = NULL;
    ASSERT_EQ(-1 ,BARCODE_fnInvokeCallback(NULL));
}

/**check failure for barcode data handler by passing null  */
TEST(BARCODE_fnDataHandler, BarcodeDatahandlerFailure) 
{
    int32_t result = BARCODE_fnInvokeCallback(nullptr);
    EXPECT_EQ(result, -1);
}


int main(int argc, char **argv) 
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}