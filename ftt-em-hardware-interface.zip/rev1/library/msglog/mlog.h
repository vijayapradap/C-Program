#ifndef MLOG_H_
#define MLOG_H_
/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 ******************************************************************************
 *
 * @file      mlog.h
 * @brief     This is the header file for logging framework fo hw interface
 *            library
 * @version   1.0
 * @date      Mar 01, 2024
 *
 ******************************************************************************
/*!
 * @defgroup mlog APIs debug log
 * @brief mlog APIs for debug log
 * @{
 */

/*============================================================================*/
/*!
@file mlog.h

    message log API

    provides APIs for debug logs
*/
/*============================================================================*/
#include <stdbool.h>
/*============================================================================*/
/*                              Functions                                     */
/*============================================================================*/
void MLOG( const char * fmt, ... );
void MLOG_fnOutput( int priority, const char* format, ... );
void MLOG_fnSetConsole( bool on );
void MLOG_fnSetSyslog( bool on );
void MLOG_fnSetSlogf( bool on );
int MLOG_fnSetSyslogLvl( int logLvl );

#endif /* MLOG_H_ */

/*! *@}
 * end of mlog group */
