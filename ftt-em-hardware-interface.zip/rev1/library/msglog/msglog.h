#ifndef MSGLOG_H_
#define MSGLOG_H_
/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 ******************************************************************************
 *
 * @file      msglog.h
 * @brief     This is the header file for logging framework fo hw interface
 *            library
 * @version   1.0
 * @date      Mar 01, 2024
 *
 ******************************************************************************

/*!
 * @defgroup syslog
 *
 * @brief
 * Macro definitions to log different message type into file.
 *
 * @{
 *
 */

/*============================================================================*/
/*!

@file  msglog.h

@brief
    Base macro definitions to log message into file

@details

    This header file contains macro definitions to write program trace and
    debug messages into system log file. Implementation is based on Linux
    system "syslog" facility.  Most log messages include Process name,
    Thread ID, File Name and Line Number.

    The default "syslog" message file is "\var\log\syslog".  Though, Linux
    allows the change of system log file name and location.

    Use the linux command "tail -f \var\log\syslog | grep [process name]" to
    continuously monitor the message logs for the same process.

    The debug messages are disabled if "NODEBUG" is defined for the Release
    build.
/*============================================================================*/

#ifndef MSGLOG_H
#define MSGLOG_H


/*==============================================================================
                              Includes
==============================================================================*/
#include <string.h>
#include <unistd.h>
#include <process.h>
#include <syslog.h>


/*==============================================================================
                               Defines
==============================================================================*/
/*! Success, Failure return codes */
#define SUCCESS             0
#define FAILURE             -1


/*==============================================================================
                               Macros
==============================================================================*/
/*! Maximum snprintf() buffer size */
#define MLOG_MAX_STR_SIZE    100

/*! File name without path */
#define MLOG_FILE                                                              \
    (strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)

/*! Message log with file name, and line number */
#define MLOG( priority, ... )                                                  \
    do {                                                                       \
        char __cbuf[MLOG_MAX_STR_SIZE];                                        \
        snprintf( __cbuf, MLOG_MAX_STR_SIZE, __VA_ARGS__ );                    \
        syslog(priority, "[%u] %s [%s:%d] %s",                                 \
        (unsigned int) gettid(),                                               \
        (#priority + 4), MLOG_FILE, __LINE__, __cbuf);                         \
    }while(0)

/*! Enable print to stderr output */
#define MLOG_VERBOSE( v )                                                      \
    do {                                                                       \
        if( v )                                                                \
        {                                                                      \
            openlog( NULL, LOG_PERROR, LOG_USER );                             \
        }                                                                      \
        syslog( LOG_INFO, "========== Process Start ==========" );             \
    }while(0)

/*! Indicate process start */
#define MLOG_PROCESS_START()                                                   \
    do {                                                                       \
        openlog( NULL, 0, LOG_USER );                                          \
        syslog( LOG_INFO, "========== Process Start ==========" );             \
    }while(0)

/*! Indicate process end */
#define MLOG_PROCESS_END()                                                     \
    do {                                                                       \
        syslog( LOG_INFO, "========== Process End ==========" );               \
        closelog();                                                            \
    }while(0)

/*! Error log */
#define MLOG_ERR( ... )     MLOG( LOG_ERR, __VA_ARGS__ )
/*! Warning log */
#define MLOG_WARN( ... )    MLOG( LOG_WARNING, __VA_ARGS__ )
/*! Information log */
#define MLOG_INFO( ... )    MLOG( LOG_INFO, __VA_ARGS__ )

/*! Assert log, if error, log and return error code */
/* Use __result so that error condition will not execute twice */
#define MLOG_ASSERT( error, ... )                                              \
    do {                                                                       \
        int __result = error;                                                  \
        if (__result)                                                          \
        {                                                                      \
            MLOG( LOG_ERR, __VA_ARGS__ );                                      \
            return __result;                                                   \
        }                                                                      \
    }while(0)

/*! If error condition is true, log error and return NULL */
#define MLOG_NULL( error, ... )                                                \
    do {                                                                       \
        if ( error )                                                           \
        {                                                                      \
            MLOG( LOG_ERR, __VA_ARGS__ );                                      \
            return NULL;                                                       \
        }                                                                      \
    }while(0)


/*! Debug log - Turn off debug log by defining NODEBUG */
#if ((!defined(NDEBUG)) && defined(DEBUG_MODULE))
    /*! General debug message */
    #define MLOG_DEBUG( ... )    MLOG( LOG_DEBUG, __VA_ARGS__ )
    /*! Dump data in buffer */
    #define MLOG_DATA_PER_LINE        20
    #define MLOG_DATA_BUFFER_SIZE    MLOG_DATA_PER_LINE * 5
    #define MLOG_BUFFER( ibuf, size )                                          \
        do  {                                                                 \
                unsigned short  __i;                                          \
                char   __dbuf[MLOG_DATA_BUFFER_SIZE] = {0};                   \
                char   *__dbuf_p;                                             \
                                                                              \
                __dbuf_p = &__dbuf[0];                                        \
                for (__i=0; __i<size; __i++)                                  \
                {                                                             \
                    __dbuf_p += sprintf( __dbuf_p, "%.2X ", ibuf[__i] );      \
                    if (!((__i + 1) % MLOG_DATA_PER_LINE))                    \
                    {                                                         \
                        MLOG_DEBUG( "%s\n", __dbuf);                          \
                        memset( __dbuf, 0, sizeof( __dbuf));                  \
                        __dbuf_p = __dbuf;                                    \
                    }                                                         \
                }                                                             \
                if (__i%20)                                                   \
                {                                                             \
                    MLOG_DEBUG( "%s\n", __dbuf);                              \
                }                                                             \
        }while(0)
    /*! Function start */
    #define MLOG_FSTART()    MLOG_DEBUG( "%s() Start", __FUNCTION__ )
    /*! Function end */
    #define MLOG_FEND()        MLOG_DEBUG( "%s() End", __FUNCTION__ )
#else
    /*! Disable debug log */
    #define MLOG_DEBUG( ... )
    #define MLOG_BUFFER( buf, size )
    #define MLOG_FSTART()
    #define MLOG_FEND()
#endif        /* !defined(NODEBUG) */

/*! @}
 * end of syslog group */

#endif        /* MSGLOG_H_ */

