/*****************************************************************************
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 /******************************************************************************
 * @file      msg_log.c
 * @brief     This is the source file for logging framework fo hw interface
 *            library
 * @version   1.0
 * @date      March 01, 2024
 *
 ******************************************************************************/

/*============================================================================*/
/*                                includes                                    */
/*============================================================================*/
#include <unistd.h>
#include <syslog.h>
#include <stdbool.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
//#include <sys/slog.h>
//#include <sys/slogcodes.h>
#include <stdarg.h>
#include <syslog.h>


#ifndef EOK
#define EOK 0
#endif

#define _SLOGC_TEST 0
#define _SLOG_INFO  1

/*============================================================================*/
/*                                Local variables                             */
/*============================================================================*/
/*! console debug */
static bool console_debug = false;

/*! slogf debug */
static bool slogf_debug = false;

/*! slogf debug */
static bool syslog_debug = false;

/*! syslog level threshold, default is LOG_WARNING. When using MLOG_fnOutput,
 *  if syslog_debug is false, then this variable is acted like a threshold to
 *  filter out the logs larger than syslog_level. For example, if syslog_level
 *  is LOG_WARNING and the msg to be logged is in LOG_DEBUG level, then this
 *  msg will not be sysloged. */
static int syslog_level = LOG_WARNING;

/*============================================================================*/
/* MLOG_fnSetConsole                                                        */
/*!
    turn console log on / off

    This function turns console log on or off

param[in]
    on
        console log on/off
/*============================================================================*/
void MLOG_fnSetConsole( bool on )
{
    console_debug = on;
}

/*============================================================================*/
/* MLOG_fnSetSlogf                                                          */
/*!
    turn slogf on / off

    This function turns slogf on or off

param[in]
    on
        slogf on/off
/*============================================================================*/
void MLOG_fnSetSlogf( bool on )
{
    slogf_debug = on;
}

/*============================================================================*/
/* MLOG_fnSetSyslog                                                          */
/*!
    turn syslog on / off

    This function turns syslog on or off

param[in]
    on
        syslog on/off
/*============================================================================*/
void MLOG_fnSetSyslog( bool on )
{
    syslog_debug = on;
}

/*============================================================================*/
/* MLOG_fnSetSyslogLvl                                                      */
/*!
    Set the syslog logging level

    This function sets the syslog logging level

param[in]
    logLvl
        The syslog logging level, should be in interval [0,7]
/*============================================================================*/
int MLOG_fnSetSyslogLvl( int logLvl )
{
    int ret = EINVAL;
    if( ( logLvl >= 0 ) && ( logLvl <= 7) )
    {
        syslog_level = logLvl;
        ret = EOK;
    }
    else
    {
        syslog( LOG_ERR, "LOG_ERR: Invalid syslog level, %d", logLvl );
    }

    return ret;
}

/*============================================================================*/
/* MLOG                                                                     */
/*!
    slogf and printf wrapper

    This is the slogf wrapper with debug flags

param[in]
    fmt
        A standard printf() string followed by printf() arguments.

param[in]
    ...
        standard printf format arguments
/*============================================================================*/
void MLOG( const char * fmt, ... )
{
    va_list arglist;

    if( fmt != NULL )
    {
       va_start( arglist, fmt );

       /* Check if we need to send output to the console */
       if( console_debug )
        {
            vprintf( fmt, arglist );
       }

      /* Check if we need to send output to the slogf */
        if( slogf_debug )
        {
            vsyslog(LOG_DEBUG|LOG_ERR|LOG_INFO|LOG_USER|LOG_DAEMON|LOG_LOCAL0, fmt, arglist );
        }

         /* Check if we need to send output to the slogf */
        if( syslog_debug )
        {
           vsyslog( LOG_DEBUG|LOG_ERR|LOG_INFO|LOG_USER|LOG_DAEMON|LOG_LOCAL0, fmt, arglist );
        }

        va_end( arglist );
    }
}

/*============================================================================*/
/* MLOG_fnOutput                                                            */
/*!

    Output the formatted strings to syslog/stdout

    This function outputs the formatted strings to syslog/stdout

@param[in]
    priority
        Log priority used for syslog

@param[in]
    format
        Formatting string used to output the formatted string

@param[in]
    ...
        Other parameters used by format parameter
/*============================================================================*/
void MLOG_fnOutput( int priority, const char* format, ... )
{
    va_list args;
    va_start( args, format );

    if( console_debug == true )
    {
        vprintf( format, args );
        printf("\n");
    }

    /* Check if we need to send output to the slogf */
    if( slogf_debug )
    {
        //vslogf( _SLOG_SETCODE(_SLOGC_TEST, 2), _SLOG_INFO, format, args );
    }

    if( syslog_debug == true )
    {
       vsyslog( priority, format, args );
    }
    else
    {
        if( priority <= syslog_level )
        {
            vsyslog( priority, format, args );
        }
    }

    va_end( args );
}

/*! *@}
 * end of mlog group */
