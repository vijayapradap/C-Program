/*
* @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
* All trademarks are owned or licensed by Eaden Technology Pte Ltd,
* its subsidiaries or affiliated companies.
*
******************************************************************************
*
* @file      hw_read_config.h
* @brief     This is the header file for reading configuration for all hardware interface
******************************************************************************
*/

#ifndef HW_CONFIG_READER_H
#define HW_CONFIG_READER_H

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdbool.h>
#include <stdint.h>

/*==============================================================================
                             macros
==============================================================================*/
#define MAX_PORT_LENGTH 50


/*==============================================================================
                             structure
==============================================================================*/
typedef struct {
    int8_t i8_uartPort[MAX_PORT_LENGTH];
    int32_t i32_baudrate;
    int8_t i8_path[MAX_PORT_LENGTH];
    bool b_consolDebug;
} st_ModuleConfig_t;


typedef struct {
    st_ModuleConfig_t odor_sensor;
    st_ModuleConfig_t power_supply_board;
    st_ModuleConfig_t barcode_scanner;
    st_ModuleConfig_t ds18b20_sensor;
    st_ModuleConfig_t motor;
    st_ModuleConfig_t hall_sensor;
    st_ModuleConfig_t mmWave_radar;
    st_ModuleConfig_t fill_light;
    bool b_consolDebug;
} st_HwModulesConfig_t;

/*==============================================================================
                             function prototype
==============================================================================*/
/** this function is for reading configuration of data for all hardware module */
int32_t HW_Interface_fnReadConfig(st_HwModulesConfig_t *HwModulesConfig);
#endif /* HW_CONFIG_READER_H */
