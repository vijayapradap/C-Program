#include <gtest/gtest.h>

extern "C" 
{
    #include "../ds18b20_sensor.h"
}

static DS18B20Config_t st_DS18B20Config;

/** Test to check the ReadConfig function */
TEST(DS18B20_fnReadConfigPass, CheckReadconfigSuccess)
{
    /** Initialize the DS18B20Config_t structure to zero */
    memset(&st_DS18B20Config, 0 ,sizeof(DS18B20Config_t));

    /** Expect the return value of ReadConfig to be 0 (Success) */
    EXPECT_EQ(0, DS18B20_fnReadConfig(&st_DS18B20Config));

    /** Expect the path in the configuration to be "/dev/ds18b20" */
    EXPECT_STREQ("/dev/ds18b20", (const char*)st_DS18B20Config.ai8_path);

    /** Expect the value of b_consolDebug to be either true or false */
    EXPECT_TRUE((st_DS18B20Config.b_consolDebug == true) || (st_DS18B20Config.b_consolDebug == false));
}

/** Test to check the success scenario when initializing the sensor */
TEST(DS18B20_fnInitSensorPass, CheckInitSuccess)
{   
    /** Expect the return value of InitSensor to be 0 (Success) */
    EXPECT_EQ(DS18B20_fnInitSensor(), 0);
}

/** Test to check the success scenario when opening the sensor */
TEST(DS18B20_fnOpenSensorPass, CheckOpenSuccess)
{
    /** Path to the sensor */
    const char* pc_path = "/dev/ds18b20";
    int8_t* pi8_path = reinterpret_cast<int8_t*>(const_cast<char*>(pc_path));

    /** Expect the return value to be 0 (Success) */
    EXPECT_EQ(DS18B20_fnOpenSensor(pi8_path), 0);
}

/** Test to check the success scenario when reading the temperature value */
TEST(DS18B20_fnReadTempValPass, CheckReadTempValSuccess)
{
    float32_t result = 0xff;

    DS18B20_fnReadTempVal(&result);

    /** Define the minimum and maximum temperature limits */
    float32_t f32_MinTemp = -55.0;
    float32_t f32_MaxTemp = 125.0;

    /** Expect the result to be greater than or equal to the minimum temperature */
    EXPECT_GE(result, f32_MinTemp);

    /** Expect the result to be less than or equal to the maximum temperature */
    EXPECT_LE(result, f32_MaxTemp);
}

/** Test to check the success scenario of data filtering process */
TEST(DS18B20_fnFilterDataPass, CheckFilterDataSuccess)
{
    /** Initialize a temporary buffer with dummy temperature values */
    float temp_buffer[MAX_BUFFER_SIZE] = {22.5, 24.0, 23.5, 23.0, 24.0, 22.5, 24.0, 23.0, 
                                        22.5, 23.0, 24.5, 22.7, 23.4, 24.3, 25.2, 24.6};

    float result = DS18B20_fnFilterData(temp_buffer);

    /* Calculate the expected result manually based on the filtering criteria */
    float expected_result = (24.0 + 24.0 + 24.0 + 23.5 + 23.4 + 23.0 + 23.0 + 23.0) / 8;

    /* Expect the result to be close to the expected result within a tolerance of 0.0005 */
    EXPECT_NEAR(result, expected_result, 0.0005);
}

/** Test to check success scenario of closing of sensor */
TEST(DS18B20_fnCloseSensorPass, CheckCloseSuccess)
{
    /** Expect the return value of CloseSensor to be 0 (Success) */
    EXPECT_EQ(DS18B20_fnCloseSensor(), 0);
}

/** Negative Test Cases*/

/** Test to check the failure scenario for ReadConfig function */
TEST(DS18B20_fnReadConfigFail, CheckReadconfigFailure)
{
    /** Initialize the DS18B20Config_t structure to zero */
    memset(&st_DS18B20Config, 0 ,sizeof(DS18B20Config_t));

    /** Expect the return value of ReadConfig to be -1 (Failure)  */
    EXPECT_EQ(DS18B20_fnReadConfig(&st_DS18B20Config), -1);

    /** Expect the path in the configuration to be "/dev/ds18b20" */
    EXPECT_STREQ("/dev/ds18b20", (const char*)st_DS18B20Config.ai8_path);

    /** Expect the value of b_consolDebug to be either true or false */
    EXPECT_TRUE((st_DS18B20Config.b_consolDebug == true) || (st_DS18B20Config.b_consolDebug == false));
}

/** Test to check the failure scenario when initializing the sensor */
TEST(DS18B20_fnInitSensorFail, CheckInitFailure)
{
    /** Expect the return value of InitSensor to be -1 (Failure) */
    EXPECT_EQ(DS18B20_fnInitSensor() , -1);
}

/** Test to check the failure scenario when opening the sensor */
TEST(DS18B20_fnOpenSensorFail, CheckOpenFailure)
{
    /** Path to a non-existing sensor, to intentionally fail the open sensor test */
    const char* pc_path = "/dev/ds1820";
    int8_t* pi8_path = reinterpret_cast<int8_t*>(const_cast<char*>(pc_path));
    
    /** Expect the return value to be -1 (Failure) */
    EXPECT_EQ(DS18B20_fnOpenSensor(pi8_path), -1);
}

/** Test to check the failure scenario when reading the temperature value */
TEST(DS18B20_fnReadTempValFail, CheckReadTempValFailure)
{
    float32_t result = 0Xff;

    DS18B20_fnReadTempVal(&result);

    /** Define the minimum and maximum temperature limits */
    float32_t f32_MinTemp = -55.0;
    float32_t f32_MaxTemp = 125.0;

    /** Expect the result to be less than the minimum temperature */
    EXPECT_LT(result, f32_MinTemp);

    /** Expect the result to be greater than the maximum temperature */
    EXPECT_GT(result, f32_MaxTemp);
}

/** Test to check the failure scenario of data filtering process */
TEST(DS18B20_fnFilterDataFail, CheckFilterDataFailure)
{
    /** Initialize a temporary buffer with dummy temperature values */
    float temp_buffer[MAX_BUFFER_SIZE] = {22.5, 24.0, 23.5, 23.0, 24.0, 22.5, 24.0, 23.0, 
                                        22.5, 23.0, 24.5, 22.7, 23.4, 24.3, 25.2, 24.6};

    float result = DS18B20_fnFilterData(temp_buffer);

    /** Set an incorrect expected result to intentionally fail the test */
    float expected_result = 22.0;

    /** Expect the result to be close to the expected result within a tolerance of 0.0005 */
    EXPECT_NEAR(result, expected_result, 0.0005);
}

/** Test to check failure scenario of closing of sensor */
TEST(DS18B20_fnCloseSensorFail, CheckCloseFailure)
{
    /** Expect the return value of CloseSensor to be not -1 (Success) */
    EXPECT_NE(DS18B20_fnCloseSensor(), 0);
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
