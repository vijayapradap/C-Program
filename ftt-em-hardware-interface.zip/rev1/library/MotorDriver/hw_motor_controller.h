#ifndef __MOTOR_H__
#define __MOTOR_H__

/********************************************************************************
 *      Copyright: 2024 Eaden FTT. All rights reserved.
 *                 All trademarks are owned or licensed by Organization Name,
 *                 its subsidiaries or affiliated companies.
 *
 *       Filename: hw_motor_controller.h
 *    Description: This is motor controller (TMC2208)
 *                 that is controlling motor's ON/OFF, Direction and Speed
 *
 *        Version: 1.0.0
 *         Author: happiest minds
 * 	    Date : April, 03, 2024
 *
 ********************************************************************************/

/*==============================================================================
                              System Includes
==============================================================================*/

/*==============================================================================
                              Project Includes
==============================================================================*/
#include "../inc/hw_interface_liberrors.h"

/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                             Type Defines
==============================================================================*/

/*==============================================================================
                              Macros
==============================================================================*/
/** Macros to control motor speed, angle, mode and direction */
#define MOTOR_IOCTL_MAGIC		'x'
#define MOTOR_GET_DATA			_IOR(MOTOR_IOCTL_MAGIC, 1, stMotorWriteData_t)
#define MOTOR_SET_WORKING    	_IOW(MOTOR_IOCTL_MAGIC, 2, stMotorWriteData_t)
#define MOTOR_SET_SPEED      	_IOW(MOTOR_IOCTL_MAGIC, 3, stMotorWriteData_t)
#define MOTOR_SET_ANGLE      	_IOW(MOTOR_IOCTL_MAGIC, 4, stMotorWriteData_t)
#define MOTOR_SET_DIR        	_IOW(MOTOR_IOCTL_MAGIC, 5, stMotorWriteData_t)
#define MOTOR_SET_MODE       	_IOW(MOTOR_IOCTL_MAGIC, 6, stMotorWriteData_t)

/*==============================================================================
                              Enums
==============================================================================*/
/** enums for motor command types */
typedef enum {
	eMotor_cmd_run = 0,
	eMotor_cmd_dir = 1,
	eMotor_cmd_mode = 2,
	eMotor_cmd_angle = 3,
	eMotor_cmd_speed = 4,
} eMotor_cmd_type_t;

/** enums for motor run modes */
typedef enum {
	eContinuous = 0,
	eDirection = 1,
} eMotor_run_mode_t;

/** enums for possible motor states */
typedef enum {
	eMotor_stop = 0,
	eMotor_run = 1,
} eMotor_run_state_t;

/** enums for possible motor rotating directions */
typedef enum {
	eClockwise,
	eAntiClockwise,
} rotateDirection_t;

/*==============================================================================
                              Structures
==============================================================================*/
/** Structure for user and kernel data transfer */
typedef struct {
        uint16_t u16Data;
        uint16_t u16ExData;
} stMotorWriteData_t;

/*==============================================================================
                              functions prototypes
==============================================================================*/
/*!
 * @brief		This function for controls the motor all possible funcions
 *
 * @param[in]		eMotor_cmd_type_t - enum parameter to control motor 
 * @param[in]		stMotorWriteData_t - structure parameter for set and get value
 *
 * @retval eReturn_ok 	Operation success	
 * @retval eReturn_err_io	unable to access ioctl
 * #retval eReturn_err_unsupport unsupported comand passed as a argument
 */
eRetStatus_t   HW_MOTOR_fnControl(eMotor_cmd_type_t eCmd, stMotorWriteData_t *pstData);

/*!
 * @brief		This function initialize the motors driver
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
//eRetStatus_t   HW_MOTOR_fnInit(void);
eRetStatus_t HW_MOTOR_fnInit(int8_t *i8p_path);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnDeInit(void);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnRun(eMotor_run_state_t eState);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnSetMode(eMotor_run_mode_t eMode);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnSetAngle(uint16_t u16Angle);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnSetSpeed(uint8_t u8Speed);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnStop(void);

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
eRetStatus_t   HW_MOTOR_fnSetDirection(void);

/*!
 * @brief		This function do set the motor in continous rotating mode
 *
 * @param[in]		Speed of the motor (0 to 100)
 * @param[in]		rotateDirection_t possible rotation direction
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnContinousMode( uint8_t u8Speed, rotateDirection_t eRotation );

/*!
 * @brief		This function do set the motor in stepper mode
 *
 * @param[in]		u16Angle angle of the motor (0 to 360)
 * @param[in]		Speed of the motor (0 to 100)
 * @param[in]		rotateDirection_t possible rotation direction
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnStepperMode(uint16_t u16Angle, uint8_t u8Speed, rotateDirection_t eRotation );

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd. *********END OF FILE****/

#endif
