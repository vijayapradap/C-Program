/**
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      hw_motor_controller.c
 * @brief     This is motor controller (TMC2208)
 *            that is controlling motor's ON/OFF, Direction and Speed
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/

/*=============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Private Includes
==============================================================================*/
#include "hw_motor_controller.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
#include "../inc/hw_interface_liberrors.h"

/*=============================================================================
                              Private Macros
==============================================================================*/
/** Macro for defining the device name */
#define DEVICE_NAME     "/dev/motor_driver"

/*==============================================================================
                              External/Public Variables
==============================================================================*/
/** Macro for defining the device name */
static int32_t gi32FilePointer = -1;

/** global direction variable */
static bool gbConfiguredDirection = eClockwise;
/*==============================================================================
                              Static Variables
==============================================================================*/
/** Structure is storing the error code and correcsponding error message */
static stErrMsg_t stErrorMsg[] = {
        { eReturn_ok,                   "OK" },
        { eReturn_err_unknown,          "Unknown Error" },
        { eReturn_err_oom,              "Out of Memory" },
        { eReturn_err_oor,              "Out of Range" },
        { eReturn_err_oob,              "Out of Buffer" },
        { eReturn_err_arg,              "Invalid Argument" },
        { eReturn_err_timeout,          "Error Timeout" },
        { eReturn_err_open_file,        "Error Opening a File" },
        { eReturn_err_create_thread,    "Error Creating a Thread" },
        { eReturn_err_deny,             "Permission Denied" },
        { eReturn_err_unsupport,        "Operation Unsupported" },
        { eReturn_err_create_msgq,      "Creating a MsgQ Failed" },
        { eReturn_err_msg_send,         "MsgQ Sending Failed" },
        { eReturn_err_io,               "IO Error" },
};
/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/
/** Macro for checking the result and print the log if failure */
#define DO_ERR_INT(result, func, line) \
        if (result != 0) { \
                MLOG_fnOutput(LOG_ERR, "LOG_ERR: %s: %s at line %ld\n", \
                                func, stErrorMsg[result].cpErrorMsg, line); \
                goto exit ;}

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/
/*!
 * @brief		This function stops the motor and make default state
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnStop(void) {
	uint8_t i8Ret = 0;
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetMode(eContinuous)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(0)), __func__, __LINE__);
	MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function Initialize the motor driver
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
//eRetStatus_t HW_MOTOR_fnInit(void) 
eRetStatus_t HW_MOTOR_fnInit(int8_t *i8p_path)
{
	uint8_t i8Ret = 0;

	gi32FilePointer = open(i8p_path, O_WRONLY);
	if(gi32FilePointer < 0) {
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}

	DO_ERR_INT((i8Ret = HW_MOTOR_fnStop()), __func__, __LINE__);
	MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function deinitialize the motors driver
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnDeInit(void) {
	int8_t i8Ret = 0;

	DO_ERR_INT((i8Ret = HW_MOTOR_fnStop()), __func__, __LINE__);
	DO_ERR_INT((i8Ret = close(gi32FilePointer)), __func__, __LINE__);
	MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);

exit:
	return i8Ret;
}

/*!
 * @brief		This function controls motor all possible functions
 *
 * @param[in]		eMotor_cmd_type_t - enum for motor control command type
 * @param[in]		stMotorWriteData_t - structure for passing values to function
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnControl(eMotor_cmd_type_t cmd, stMotorWriteData_t *pdata) {
	uint8_t i8Ret = 0;
	switch (cmd) {
		case eMotor_cmd_run:
			i8Ret = ioctl(gi32FilePointer, MOTOR_SET_WORKING, pdata);
			if (i8Ret < 0) {
				return eReturn_err_io;
			}
			break;

		case eMotor_cmd_dir:
			i8Ret = ioctl(gi32FilePointer, MOTOR_SET_DIR, pdata);
			if (i8Ret < 0) {
				return eReturn_err_io;
			}
			break;

		case eMotor_cmd_mode:
			i8Ret = ioctl(gi32FilePointer, MOTOR_SET_MODE, pdata);
			if (i8Ret < 0) {
				return eReturn_err_io;
			}
			break;

		case eMotor_cmd_angle:
			i8Ret = ioctl(gi32FilePointer, MOTOR_SET_ANGLE, pdata);
			if (i8Ret < 0) {
				return eReturn_err_io;
			}
			break;

		case eMotor_cmd_speed:
			i8Ret = ioctl(gi32FilePointer, MOTOR_SET_SPEED, pdata);
			if (i8Ret < 0){
				return eReturn_err_io;
			}
			break;
		default:
			return eReturn_err_unsupport;
			break;
	}

	return eReturn_ok;
}

/*!
 * @brief		This function controls the motor start/stop
 *
 * @param[in]		eMotor_run_state_t - state of motor
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnRun(eMotor_run_state_t eState) {
	uint8_t i8Ret = 0;
	
	stMotorWriteData_t stMotorData;
	stMotorData.u16Data = eState;

	if (gi32FilePointer >= 0) {
		i8Ret = HW_MOTOR_fnControl(eMotor_cmd_run, &stMotorData);
		DO_ERR_INT(i8Ret, __func__, __LINE__);
		if (0 == i8Ret) {
			MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
			return eReturn_ok;
		}
	}
	i8Ret = eReturn_err_deny;
	DO_ERR_INT(i8Ret, __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function for set the mode of motor
 *
 * @param[in]		eMotor_run_mode_t - enum for setting mode
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnSetMode(eMotor_run_mode_t eMode) {
	uint8_t i8Ret = 0;
	stMotorWriteData_t stMotorData;
	stMotorData.u16Data = eMode;
	
	if (gi32FilePointer >= 0) {
		i8Ret = HW_MOTOR_fnControl(eMotor_cmd_mode, &stMotorData);
		DO_ERR_INT(i8Ret, __func__, __LINE__);
		if (0 == i8Ret) {
			MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
			return eReturn_ok;
		}
	}
	i8Ret = eReturn_err_deny;
	DO_ERR_INT(i8Ret, __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function to changing the direction of motor rotation
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnSetDirection(void) {
	uint8_t i8Ret = 0;
	stMotorWriteData_t stMotorData;
	
	if (gi32FilePointer >= 0) {
		i8Ret = HW_MOTOR_fnControl(eMotor_cmd_dir, &stMotorData);
		DO_ERR_INT(i8Ret, __func__, __LINE__);
		if (0 == i8Ret) {
			MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
			return eReturn_ok;
		}
	}
	i8Ret = eReturn_err_deny;
	DO_ERR_INT(i8Ret, __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function to setting the angle steps of motor
 *
 * @param[in]		Angle motor should rotate
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnSetAngle(uint16_t u16Angle) {
	uint8_t i8Ret = 0;
	stMotorWriteData_t stMotorData;
	stMotorData.u16Data = u16Angle;
	
	if (gi32FilePointer >= 0) {
		i8Ret = HW_MOTOR_fnControl(eMotor_cmd_angle, &stMotorData);
		DO_ERR_INT(i8Ret, __func__, __LINE__);
		if (0 == i8Ret) {
			MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
			return eReturn_ok;
		}
	}
	i8Ret = eReturn_err_deny;
	DO_ERR_INT(i8Ret, __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function to set the motor speed
 *
 * @param[in]		Speed of the motor (0 to 100)
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnSetSpeed(uint8_t u8Speed) {
	uint8_t i8Ret = 0;
	stMotorWriteData_t stMotorData;
	stMotorData.u16Data = u8Speed;
	
	if (gi32FilePointer >= 0) {
		i8Ret = HW_MOTOR_fnControl(eMotor_cmd_speed, &stMotorData);
		DO_ERR_INT(i8Ret, __func__, __LINE__);
		if (0 == i8Ret) {
			MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
			return eReturn_ok;
		}
	}
	i8Ret = eReturn_err_deny;
	DO_ERR_INT(i8Ret, __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function do set the motor in continous rotating mode
 *
 * @param[in]		Speed of the motor (0 to 100)
 * @param[in]		rotateDirection_t possible rotation direction
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnContinousMode( uint8_t u8Speed, rotateDirection_t eRotation ) {

	int8_t i8Ret = 0;

	if ( 0 > u8Speed || 100 < u8Speed ) {
		DO_ERR_INT((i8Ret = eReturn_err_arg), __func__, __LINE__);
	}
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetMode(eContinuous)), __func__, __LINE__);
	if (gbConfiguredDirection != eRotation) {
		DO_ERR_INT((i8Ret = HW_MOTOR_fnSetDirection()), __func__, __LINE__);
	}
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(u8Speed)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_run)), __func__, __LINE__);

exit:
	return i8Ret;
}

/*!
 * @brief			This function do set the motor in stepper mode
 *
 * @param[in]		u16Angle angle of the motor (0 to 360)
 * @param[in]		Speed of the motor (0 to 100)
 * @param[in]		rotateDirection_t possible rotation direction
 * @param[out]		NA
 *
 * @retval eReturn_ok 	Success
 * @retval !eReturn_ok	Failure
 */
eRetStatus_t HW_MOTOR_fnStepperMode(uint16_t u16Angle, uint8_t u8Speed, rotateDirection_t eRotation ) {

	int8_t i8Ret = 0;

	if ( 0 > u8Speed || 100 < u8Speed ) {
		DO_ERR_INT((i8Ret = eReturn_err_arg), __func__, __LINE__);
	}
	if ( 0 > u16Angle || 360 < u16Angle ) {
		DO_ERR_INT((i8Ret = eReturn_err_arg), __func__, __LINE__);
	}

	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetMode(eDirection)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetAngle(u16Angle)), __func__, __LINE__);
	if (gbConfiguredDirection != eRotation) {
		DO_ERR_INT((i8Ret = HW_MOTOR_fnSetDirection()), __func__, __LINE__);
	}
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(u8Speed)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_run)), __func__, __LINE__);

exit:
	return i8Ret;
}

#if 0
int main(void) {
	uint8_t i8Ret = 0;
	DO_ERR_INT((i8Ret = HW_MOTOR_fnInit()), __func__, __LINE__);

	printf("Full speed\n");
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetDirection()), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(100)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_run)), __func__, __LINE__);
	sleep(60);

#if 0	
	printf("Half speed\n");
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(50)), __func__, __LINE__);
	sleep(5);

	printf("Direction change and 25%% speed\n");
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);
	sleep(1);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetDirection()), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_run)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(25)), __func__, __LINE__);
	sleep(5);

	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(0)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);
	printf("direction and angle set\n");	
	
	sleep(5);

	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetMode(eDirection)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetDirection()), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetAngle(90)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(25)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_run)), __func__, __LINE__);
	sleep(5);
#endif
	printf("motor driver exited\n");	
	DO_ERR_INT((i8Ret = HW_MOTOR_fnSetSpeed(0)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MOTOR_fnRun(eMotor_stop)), __func__, __LINE__);

	return 0;
exit:
	return i8Ret;
}
#endif

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd. *********END OF FILE****/
