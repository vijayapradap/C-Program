#include <gtest/gtest.h>
#include <fcntl.h>

extern "C" 
{
    #include "../odor.h"
   
}

static ODORConfig_t st_ODORConfig; 


/*-------------------------Positive test cases----------------------*/

/* reading configuration file */
TEST(ODOR_ReadCofig, ReadConfigStatus)
{
    memset(&st_ODORConfig, 0 ,sizeof(ODORConfig_t));
    EXPECT_EQ(0, ODOR_fnReadConfig(&st_ODORConfig));
    EXPECT_STREQ("/dev/ttyTHS1", (const char*)st_ODORConfig.i8_uartPort);
    EXPECT_TRUE((st_ODORConfig.b_consolDebug == true) || (st_ODORConfig.b_consolDebug == false));
}

/* check for odor sensor initialization */
TEST(ODORfnInit , ODORInitStatus_1)
{
    ASSERT_EQ(ODOR_fnInit(), 0);
    ASSERT_NE(ODOR_fnInit(), -1);
}

TEST(ODORfnInit , ODORInitStatus_2)
{
    int32_t retUart = -1;
    int32_t retCommands = -1;
    retUart = ODOR_fnUartInit();
    retCommands = ODOR_fnSendCommands();
    EXPECT_EQ(retUart , 0); 
    EXPECT_EQ(retCommands , 0); 
}

/* check for uart communication */
TEST(ODORUartInit , ODORUartStatus_1)
{
    ASSERT_EQ(ODOR_fnUartInit(),0);
}
 
TEST(ODORUartInit , ODORUartStatus_2)
{
    /* check for uart port */
    int32_t sgi32_SerialPort = open("/dev/ttyTHS1", O_RDWR | O_NOCTTY);
    ASSERT_GT(sgi32_SerialPort , 0);

}

/* check baudrate for odor sensor */
TEST(ODORUartInit , ODORUartCheckBaudrate)
{
    int32_t baudrate = 2400; /* baudarate*/
    ASSERT_EQ(st_ODORConfig.i32_baudrate , baudrate);
}

/* check wheather commands sent or not */
TEST(ODORSendCommand , SendCommandSuccess)
{
    uint8_t ui8_buffer[4] = {0xAA,0x00,0xFE,0xBB}; /* active upload mode command */
    int32_t retSend = ODOR_fnSend(ui8_buffer , sizeof(ui8_buffer));
    ASSERT_EQ(retSend , 0);
} 

TEST(ODOR_fnSend , SendStatus)
{ 
    int32_t sgi32_SerialPort = 1;
    uint8_t ui8_buffer[4] = {0xAA,0x00,0xFE,0xBB}; /* active upload mode command */
    /*check for how much byte it is writen */
    int32_t i32_ReturnValue = write(sgi32_SerialPort, ui8_buffer, sizeof(ui8_buffer));
    ASSERT_EQ(i32_ReturnValue ,sizeof(ui8_buffer));
}

TEST(ODOR_fnSendPayloadTest, SendPayloadSuccess) 
{
     uint8_t command[] = {0xAA,0x00,0xFE,0xBB}; 
     int32_t commandSize = sizeof(command) / sizeof(command[0]);
    EXPECT_EQ(0, ODOR_fnSendPayload(command, commandSize));
}

/*  Active upload command status check */
TEST(ODOR_fnActiveUploadMode , ActiveUploadStatus_1)
{
    int32_t retVal = ODOR_fnActiveUploadMode();
    ASSERT_EQ(retVal , 0);
}

TEST(ODOR_fnActiveUploadMode , ActiveUploadStatus_2)
{
   /* active upload commands */
    uint8_t ActiveUploadMode[2] = {0xFE, 0xBB}; 
    ASSERT_EQ(0, ODOR_fnSendPayload(ActiveUploadMode, sizeof(ActiveUploadMode)));
}

/* CheckSum calculation status */
TEST(ODOR_fnCheckSumTest, PositiveCheckSum) 
{
    /*asuming this is recieved data*/
    int8_t data[] = {0x01, 0x02, 0x03, 0x04, 0x05}; 
    int8_t dataSize = sizeof(data) / sizeof(data[0]);
    int8_t checksum = ODOR_fnCheckSum(data, dataSize);
    int8_t expectedChecksum = 0x0F;  /*axpected check sum*/
    EXPECT_EQ(expectedChecksum, checksum);
}

TEST(ODOR_fnSendCommands , CheckStatus_1)
{
    ASSERT_EQ(ODOR_fnSendCommands(),0);
}


/* Register call back function */
TEST(ODOR_RegisterDataCallbackTest, Failure_NullCallback) 
{    
    static DataCallback dataCallback = NULL;
    static int32_t callbackRegistered = 0;
    int32_t result = ODOR_RegisterDataCallback(dataCallback);
    EXPECT_EQ(-1, result);
    EXPECT_EQ(NULL, dataCallback);
    EXPECT_EQ(0, callbackRegistered);
}

/*-------------------------Negative test cases----------------------*/

TEST(ODORUartInit , ODORUartFailure)
{
    int32_t sgi32_SerialPort = open("/dev/ttyTH", O_RDWR | O_NOCTTY);
    ASSERT_EQ(sgi32_SerialPort , -1);
}

TEST(ODORSendCommand , SendCommandFailure)
{
    uint8_t ui8_buffer[4] = {0xAA,0x00,0xFE,0xBB};
    int32_t retSend = ODOR_fnSend(ui8_buffer , 0);
    ASSERT_EQ(retSend , -1);
}

TEST(ODOR_fnSend , SendStatusFailure)
{ 
    int32_t sgi32_SerialPort = 1;
    uint8_t ui8_buffer[4] = {0xAA,0x00,0xFE,0xBB};
    int32_t i32_ReturnValue = write(sgi32_SerialPort, ui8_buffer, sizeof(ui8_buffer));
    ASSERT_NE(i32_ReturnValue , 0);
}

TEST(ODOR_fnSendPayloadTest, SendPayloadFailure) 
{
    uint8_t command[] = {};  
    int32_t commandSize = sizeof(command) / sizeof(command[0]);
    int32_t retSend = ODOR_fnSend(command , 0);
    EXPECT_EQ(-1, retSend);
}

TEST(ODOR_fnCheckSumTest, NegativeCheckSum) 
{
    /*asuming this is recieved data*/
    int8_t data[] = {0x01, 0x02, 0x03, 0x04, 0x05}; 
    int8_t dataSize = sizeof(data) / sizeof(data[0]);
    int8_t checksum = ODOR_fnCheckSum(data, dataSize);
    int8_t expectedChecksum = 0xFF;  /*axpected check sum*/
    EXPECT_NE(expectedChecksum, checksum);
}


int main(int argc, char **argv) 
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

