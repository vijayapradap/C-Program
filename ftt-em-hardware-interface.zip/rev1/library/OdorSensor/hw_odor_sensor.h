/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      odor.h
 * @brief     This is the header file for odor sensor communication with
 *            main board over uart
 ******************************************************************************
 */
 
#ifndef __ODOR_H__ 
#define __ODOR_H__

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdint.h>
#include <syslog.h>
/*==============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Defines
==============================================================================*/

/*==============================================================================
                             Type Defines
==============================================================================*/

/*==============================================================================
                              Macros
==============================================================================*/
#define DATA_BITS CS8         
#define HEADER_FRAME 0xAA
#define ODOR_DATA_SIZE 26

/*==============================================================================
                              Structures
==============================================================================*/
typedef struct 
{
    uint8_t ui8_header;           
    int32_t ui32_temperature;    
    int32_t ui32_Voltage1;       
    int32_t ui32_Voltage2;       
    int32_t ui32_ThresholdValue1;
    int32_t ui32_ThresholdValue2;
    uint8_t ui8_GasType;          
    uint8_t ui8_PreHeatingSignal; 
    uint8_t ui8_FaultSignal;      
    uint8_t ui8_StatusSignal;     
    uint8_t checksum;            
} st_BurntSmellSensor_t; 

/*==============================================================================
                              functions prototypes
==============================================================================*/

/*!
@brief		<b>Initialize the odor sensor. </b>
@param[in]	i32_baudrate - baudrate for uart port 
@param[in]	i8_pUartPort - uart port or serial port path 
@param[out]	None
@retval EOK: Odor sensor initialization successful.
@retval errno: Odor sensor initialization failed.
*/
int32_t HW_ODOR_fnInit(int32_t i32_baudrate , int8_t *i8_pUartPort);
/*!
@brief		<b> Calculate the checksum of the given data array.</b>
@param[in]	 i8_pdata Pointer to the array of data.
@param[in]	 i8_len Length of the data array.
@param[out]	 None
@retval The calculated checksum value.
*/
int8_t ODOR_fnCheckSum(int8_t *i8_pdata, int8_t i8_len);
/*!
@brief		<b> Read data from the ODOR sensor and process the received information.</b>
@param[in]	 st_BurntSmellSensor_t - pointer to the structure 
@param[out]	 None
@retval EOK: Data reading and processing successful.
@retval errno: Failed to read data or checksum verification failed.
*/
int32_t HW_ODOR_fnReadData(st_BurntSmellSensor_t *st_ODOR_sensor);
/*!
@brief		<b> Reverse the byte order of a 32-bit value stored in a buffer.</b>
@param[in]	ui8_pbuffer: Pointer to the buffer containing the 32-bit value stored in little-endian format.
@param[out]	None
@retval		Reversed 32-bit value divided by 1000.
*/
uint32_t HW_ODOR_ReverseByteOrder(uint8_t* ui8_pbuffer);
/*!
@brief		<b> close uart port for odor sensor.</b>
@param[in]	 None
@param[out]	 None
@retval None
@retval None
*/
void HW_ODOR_fnClose();

#endif //__ODOR_H__


/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/




