/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      odor.c
 * @brief     This is the source file for odor sensor communication with
 *            main board over uart

 ******************************************************************************
 */

/*===================================================================================================
*         System includes
======================================================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>
#include <stdint.h> 

/*==============================================================================
*         Project includes
================================================================================*/
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
#include "../inc/hw_interface_liberrors.h"

/*==============================================================================
                              Private Includes
==============================================================================*/
#include "hw_odor_sensor.h"

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/
 static int32_t sgi32_SerialPort;

/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/


/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_ODOR_fnInit(int32_t i32_baudrate , int8_t *i8_pUartPort)
{
    static int32_t sai32_BaudRateSpeed[7] = {B38400, B19200, B9600, B4800, B2400, B1200, B300};
    static int32_t sai32_BaudRateName[7] = {38400, 19200, 9600, 4800, 2400, 1200, 300};
    int32_t i32_loop;
    sgi32_SerialPort = 0;
    int32_t BAUD_RATE = 0; 
    struct termios uart_config; 
 
    sgi32_SerialPort = open(i8_pUartPort, O_RDWR | O_NOCTTY);
    if (-1 == sgi32_SerialPort) 
    {
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: ODOR_fnUartInit: Unable to open the file %s, "
        "errno = %d\n", i8_pUartPort, sgi32_SerialPort);
        return sgi32_SerialPort;
    }

    for(i32_loop = 0; i32_loop < 7; i32_loop++)
    {
            if(sai32_BaudRateName[i32_loop] == i32_baudrate)
            {
                BAUD_RATE = sai32_BaudRateSpeed[i32_loop];
                break;
            }
    }

    if (0 > tcgetattr(sgi32_SerialPort, &uart_config)) 
    { 
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: ODOR_fnUartInit ODOR_FAILED to get UART configuration,"
        "errno = %d\n",EINVAL);
        close(sgi32_SerialPort);
        return EINVAL; 
    }

    uart_config.c_cflag = BAUD_RATE | DATA_BITS | CREAD | CLOCAL;
    uart_config.c_iflag = IGNPAR;
    uart_config.c_oflag = 0;
    uart_config.c_lflag = 0;
    uart_config.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    uart_config.c_iflag &= ~ (INLCR | ICRNL | IGNCR);
    uart_config.c_oflag &= ~(ONLCR | OCRNL);
    /** Time-out value (tenths of a second)  */
    uart_config.c_cc[VTIME] = 0;    
    /** Minimum number of bytes read at once  */
    uart_config.c_cc[VMIN] = ODOR_DATA_SIZE;    
    tcflush(sgi32_SerialPort, TCIFLUSH);

    if (0 > tcsetattr(sgi32_SerialPort, TCSANOW, &uart_config)) 
    {  
        MLOG_fnOutput(LOG_ERR,"LOG_ERR: ODOR_fnUartInit ODOR_FAILED to set UART configuration,"
        "errno = %d\n",EINVAL);
        close(sgi32_SerialPort);
        return EINVAL;
    }
    return EOK;
}
 
/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int8_t ODOR_fnCheckSum(int8_t *i8_pdata, int8_t i8_len) 
{
    int8_t i8_sum = 0;
    for (int32_t i = 0; i < i8_len; i++) 
    {   
        i8_sum += i8_pdata[i];
    }
    return i8_sum & 0xFF;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
uint32_t HW_ODOR_ReverseByteOrder(uint8_t* ui8_pbuffer)
{
    uint32_t ui32_value = 0;
    ui32_value = (ui8_pbuffer[3] << 24) | (ui8_pbuffer[2] << 16) | (ui8_pbuffer[1] << 8) | ui8_pbuffer[0];
    return ui32_value / 1000;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_ODOR_fnReadData(st_BurntSmellSensor_t *st_ODOR_sensor)
{ 
    uint8_t  ui8_buffer[ODOR_DATA_SIZE];
   
        memset(ui8_buffer, 0, sizeof(ui8_buffer));
        int32_t i32_BytesRead = read(sgi32_SerialPort, ui8_buffer, ODOR_DATA_SIZE);

        if ((ODOR_DATA_SIZE == i32_BytesRead) && (HEADER_FRAME == ui8_buffer[0]))
        {
            uint8_t ui8_ReceivedChecksum = ui8_buffer[ODOR_DATA_SIZE - 1];
            uint8_t ui8_CalculatedChecksum = ODOR_fnCheckSum(ui8_buffer, ODOR_DATA_SIZE - 1);

            if (ui8_ReceivedChecksum == ui8_CalculatedChecksum) 
            {
                MLOG_fnOutput(LOG_DEBUG, "LOG_DEBUG: HW_ODOR_fnReadData Checksum verification: Passed\n");

                /* Parse and reverse byte order for each member */
                st_ODOR_sensor->ui32_temperature = HW_ODOR_ReverseByteOrder(ui8_buffer + 1);
                st_ODOR_sensor->ui32_Voltage1 = HW_ODOR_ReverseByteOrder(ui8_buffer + 5);
                st_ODOR_sensor->ui32_Voltage2 = HW_ODOR_ReverseByteOrder(ui8_buffer + 9);
                st_ODOR_sensor->ui32_ThresholdValue1 = HW_ODOR_ReverseByteOrder(ui8_buffer + 13);
                st_ODOR_sensor->ui32_ThresholdValue2 = HW_ODOR_ReverseByteOrder(ui8_buffer + 17);
                st_ODOR_sensor->ui8_GasType = ui8_buffer[21];
                st_ODOR_sensor->ui8_PreHeatingSignal = ui8_buffer[22];
                st_ODOR_sensor->ui8_FaultSignal = ui8_buffer[23];
                st_ODOR_sensor->ui8_StatusSignal = ui8_buffer[24];
                
            } 
            else 
            {
                MLOG_fnOutput(LOG_ERR, "LOG_ERR: HW_ODOR_fnReadData Checksum verification: failed\n");
                tcflush(sgi32_SerialPort, TCIOFLUSH);
                /** Protocol error received checksum protocol doesn't match  */
                return EPROTO;  
            }
        }
        else
        {
            MLOG_fnOutput(LOG_ERR, "LOG_ERR: HW_ODOR_fnReadData failed to read or incorrect header\n");
            tcflush(sgi32_SerialPort, TCIOFLUSH);
            return EIO;
        }
    
    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
void HW_ODOR_fnClose(void)
{
    if (-1 != sgi32_SerialPort)
    {
        close(sgi32_SerialPort);
        sgi32_SerialPort = -1;
    }
}

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/