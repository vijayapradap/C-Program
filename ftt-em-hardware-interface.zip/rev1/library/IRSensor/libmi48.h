#ifndef __LIBMI48_H
#define __LIBMI48_H

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
//#include <iostream>

//初始化，创建线程
void Mi48Init(void);
//反初始化，停止所有线程并销毁所有资源
void Mi48DeInit(void);
//获取温度矩阵, pixels得到的温度数据
//return: true->得到数据   false->获取数据失败(没更新)
bool Mi48GetData(int *pixels);

//获取库版本号,如：101 = V1.0.1
uint16_t Mi48GetVersion(void);
//获取库日期，如：20240101 = 2024-01-01
uint32_t Mi48GetVerDate(void);

/****************************************************
 * 以下为温度转RBG，需要自己定义RGB数组
*****************************************************/
//RGB数组定义如下：
//int Scale=0;
//int height = (Scale * (62 - 1) + 62); //进行插值后的行宽 Scale: 放大倍数，取 0~10
//int width = (Scale * (80 - 1) + 80); //进行插值后的列宽 Scale: 放大倍数，取 0~10
//int outRGB[width*height*3]; //定义RGB数组

//input：温度矩阵
//outRGB：得到的RGB颜色
//Scale: 放大倍数，取 0~10
//return: true->转换成功  false->转换失败
bool Mi48GetRGB(int *input,uint8_t *outRGB,int Scale);

//自动获取温度并转换为RGB
//outRGB：得到的RGB颜色
//Scale: 放大倍数，取 0~10
//return: true->转换成功  false->转换失败
//bool Mi48GetRGB(uint8_t *outRGB,int Scale);



#endif

