#!/bin/sh
g++ -o test mi48_demo.c -lmi48 -lm -L./ -Wl,-rpath=./
