cmd_drivers/input/touchscreen/gt9xx_dw220/modules.order := {  :; } | awk '!x[$$0]++' - > drivers/input/touchscreen/gt9xx_dw220/modules.order
