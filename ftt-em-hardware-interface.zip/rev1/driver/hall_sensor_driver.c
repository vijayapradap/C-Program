#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/gpio.h>
#include <stdbool.h>

/* Meta Information */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Happiest Minds 4 GNU/Linux");
MODULE_DESCRIPTION("A simple Hall sensor driver");

#define HALL_SENSOR_CHIP "GPIO3_PCC.01"
#define HALL_SENSOR_PIN 329

/* Variables for device and device class */
static dev_t stHallDeviceNr;
static struct class *stHallClass;
static struct cdev stHallDevice;

#define DRIVER_NAME "hall_sensor_driver"
#define DRIVER_CLASS "MyHallSensorClass"

// Define constants for timing
#define CHECK_MSEC 5      // Read hardware every 5 msec
#define PRESS_MSEC 10     // Stable time before registering pressed
#define RELEASE_MSEC 100  // Stable time before registering released

// This holds the debounced state of the key.
bool bDebouncedKeyPress = false;

// Service routine called every CHECK_MSEC to debounce both edges
void DebounceSwitch(bool *bKeyChanged, bool *bKeyPressed) {
	static uint8_t u8Count = RELEASE_MSEC / CHECK_MSEC;
	bool bRawState;

	*bKeyChanged = false;
	*bKeyPressed = bDebouncedKeyPress;

	bRawState = gpio_get_value(HALL_SENSOR_PIN);

	if (bRawState == bDebouncedKeyPress) {
		// Set the timer which allows a change from the current state.
		if (bDebouncedKeyPress)
			u8Count = RELEASE_MSEC / CHECK_MSEC;
		else
			u8Count = PRESS_MSEC / CHECK_MSEC;
	} else {
		// Key has changed - wait for the new state to become stable.
		if (--u8Count == 0) {
			// Timer expired - accept the change.
			bDebouncedKeyPress = bRawState;
			*bKeyChanged = true;
			*bKeyPressed = bDebouncedKeyPress;

			// Reset the timer.
			if (bDebouncedKeyPress)
				u8Count = RELEASE_MSEC / CHECK_MSEC;
			else
				u8Count = PRESS_MSEC / CHECK_MSEC;
		}
	}
}

/**
 * @brief Read data out of the buffer
 */
static ssize_t driver_read(struct file *File, char *user_buffer, size_t count, loff_t *offs) {
	int to_copy, not_copied, delta;
	char tmp[3] = " \n";
	bool keyChanged, keyPressed;

	/* Get amount of data to copy */
	to_copy = min(count, sizeof(tmp));

	DebounceSwitch(&keyChanged, &keyPressed);
	tmp[0] = (keyChanged) ? (keyPressed) ? 1 + '0' : 0 + '0' : 0 + '0'; 
#if 0
	/* Read value of button */
	printk("Value of button: %d\n", gpio_get_value(HALL_SENSOR_PIN));
	tmp[0] = gpio_get_value(HALL_SENSOR_PIN) + '0';
#endif

	/* Copy data to user */
	not_copied = copy_to_user(user_buffer, &tmp, to_copy);

	/* Calculate data */
	delta = to_copy - not_copied;

	return delta;
}

/**
 * @brief This function is called, when the device file is opened
 */
static int driver_open(struct inode *device_file, struct file *instance) {
	printk("dev_nr - open was called!\n");
	return 0;
}

/**
 * @brief This function is called, when the device file is opened
 */
static int driver_close(struct inode *device_file, struct file *instance) {
	printk("dev_nr - close was called!\n");
	return 0;
}

static struct file_operations fops = {
	.owner = THIS_MODULE,
	.open = driver_open,
	.release = driver_close,
	.read = driver_read,
};

/**
 * @brief This function is called, when the module is loaded into the kernel
 */
static int __init ModuleInit(void) {

	/* Allocate a device nr */
	if( alloc_chrdev_region(&stHallDeviceNr, 0, 1, DRIVER_NAME) < 0) {
		printk("Device Nr. could not be allocated!\n");
		return -1;
	}
	printk("read_write - Device Nr. Major: %d, Minor: %d was registered!\n", stHallDeviceNr >> 20, stHallDeviceNr && 0xfffff);

	/* Create device class */
	if((stHallClass = class_create(THIS_MODULE, DRIVER_CLASS)) == NULL) {
		printk("Device class can not be created!\n");
		goto ClassError;
	}

	/* create device file */
	if(device_create(stHallClass, NULL, stHallDeviceNr, NULL, DRIVER_NAME) == NULL) {
		printk("Can not create device file!\n");
		goto FileError;
	}

	/* Initialize device file */
	cdev_init(&stHallDevice, &fops);

	/* Regisering device to kernel */
	if(cdev_add(&stHallDevice, stHallDeviceNr, 1) == -1) {
		printk("Registering of device to kernel failed!\n");
		goto AddError;
	}

	/* GPIO HALL_SENSOR_PIN init */
	if(gpio_request(HALL_SENSOR_PIN, HALL_SENSOR_CHIP)) {
		printk("Can not allocate GPIO 4\n");
		goto AddError;
	}

	/* Set GPIO HALL_SENSOR_PIN direction */
	if(gpio_direction_input(HALL_SENSOR_PIN)) {
		printk("Can not set GPIO 17 to input!\n");
		goto GpioError;
	}

	return 0;
GpioError:
	gpio_free(HALL_SENSOR_PIN);
AddError:
	device_destroy(stHallClass, stHallDeviceNr);
FileError:
	class_destroy(stHallClass);
ClassError:
	unregister_chrdev_region(stHallDeviceNr, 1);
	return -1;
}

/**
 * @brief This function is called, when the module is removed from the kernel
 */
static void __exit ModuleExit(void) {
	gpio_free(HALL_SENSOR_PIN);
	cdev_del(&stHallDevice);
	device_destroy(stHallClass, stHallDeviceNr);
	class_destroy(stHallClass);
	unregister_chrdev_region(stHallDeviceNr, 1);
}

module_init(ModuleInit);
module_exit(ModuleExit);


