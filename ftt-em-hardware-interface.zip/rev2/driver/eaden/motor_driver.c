/********************************************************************************
 *      Copyright: 2024 Eaden FTT. All rights reserved.
 *                 All trademarks are owned or licensed by Organization Name,
 *                 its subsidiaries or affiliated companies.
 *
 *       Filename: motor_driver.c
 *    Description: This is gpio driver source file for motor controller (TMC2208)
 *                 that is controlling motor's ON/OFF, Direction and Speed
 *
 *        Version: 1.0.0
 *         Author: happiest minds
 * 	    Date : April, 03, 2024
 *
 ********************************************************************************/

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/gpio.h>

#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/mutex.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/rtc.h>
#include <asm/io.h>
#include <linux/ioctl.h>

/** Macro to driver name created in /dev/ */
#define DRIVER_NAME "motor_driver"
/** Macro to driver class for driver creation */
#define DRIVER_CLASS "MyModuleClass"

/** Macro to Enable pin gpiochip name for initialization */
#define ENABLE_CHIP "GPIO3_PP.00"
/** Macro to Direction pin gpiochip name for initialization */
#define DIRECT_CHIP "GPIO3_PQ.06"
/** Macro to Step-In pin gpiochip name for initialization */
#define PWM_CHIP "GPIO3_PN.01"

/** Macro to Enable pin number for initialization (348 + 92 + 0) */
#define ENABLE_PIN 440
/** Macro to Direction pin number for initialization (348 + 100 + 6) */
#define DIRECT_PIN 454
/** Macro to Step-In pin number for initialization (348 + 84 + 1) */
#define PWM_PIN 433
/** Macro to Enable to enable pin */
#define ENABLE 0
/** Macro to Disable to enable pin */
#define DISABLE 1

/** Macro to default timeout for timer */
#define TIMEOUT_DEFAULT ( 100000000L )
/** Macro to default clock period for timer */
#define DEFAULT_CLOCK_PERIODS ( 1000000000UL )
/** Macro to maximum speed can achieve by motor */
#define TIMEOUT_MAX_SPEED ( 100000L ) // 100 micro-second in nano seconds
/** Macro to minimum speed can achieve by motor */
#define TIMEOUT_MIN_SPEED ( 10000000L )	// 10 milli-second in nano seconds
/** Macro to Default FREQ in Hz */
#define DEFAULT_FREQUENCE 1000
/** Macro to defines minute fraction */
#define DEFAULT_MICROS 16
/** Macro to defines traverse angle (1.8 * 10) */
#define DEFAULT_STEP_ANGLE 18

/** Macros to control motor speed, angle, mode and direction */
#define MOTOR_IOCTL_MAGIC       'x'
#define MOTOR_GET_DATA          _IOR(MOTOR_IOCTL_MAGIC, 1, stMotorWriteData_t)
#define MOTOR_SET_WORKING       _IOW(MOTOR_IOCTL_MAGIC, 2, stMotorWriteData_t)
#define MOTOR_SET_SPEED         _IOW(MOTOR_IOCTL_MAGIC, 3, stMotorWriteData_t)
#define MOTOR_SET_ANGLE         _IOW(MOTOR_IOCTL_MAGIC, 4, stMotorWriteData_t)
#define MOTOR_SET_DIR           _IOW(MOTOR_IOCTL_MAGIC, 5, stMotorWriteData_t)
#define MOTOR_SET_MODE          _IOW(MOTOR_IOCTL_MAGIC, 6, stMotorWriteData_t)

/** Meta Information */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Happiest Minds 4 GNU/Linux");
MODULE_DESCRIPTION("A simple motor driver");

/** Variables for device and device class */
static dev_t stDeviceNumber;
static struct class *stDeviceClass;
static struct cdev stClassDev;
static struct hrtimer etx_hr_timer;

/** Structure for local variable declation for functional use */
typedef struct {
	uint8_t u8MotorStepIn;
	uint8_t u8MotorDirection;
	uint8_t u8MotorMode;
	uint32_t u32PwmPulses;
	uint32_t u32PwmFreq;
	uint32_t u32PwmDutyCycle;
} stMotorData_t;

/** Structure for user and kernel data transfer */
typedef struct {
        uint16_t u16Data;
        uint16_t u16ExData;
} stMotorWriteData_t;

stMotorData_t stMotorData = { .u32PwmDutyCycle = TIMEOUT_DEFAULT };

/** enums for motor run modes */
typedef enum {
        eContinuous = 0,
        eDirection = 1,
} eMotor_run_mode_t;

typedef unsigned int u32_t;
typedef unsigned long u64_t;

/*!
 * @brief		This function generates the pwm pulses
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
static void HW_MOTOR_fnPwmGenerator(void) {

	gpio_set_value(PWM_PIN, stMotorData.u8MotorStepIn);
	stMotorData.u8MotorStepIn = !stMotorData.u8MotorStepIn;
}

/** hrtimer Callback function. This will be called when timer expires */
enum hrtimer_restart timer_callback(struct hrtimer *stTimer) {

	hrtimer_forward_now(stTimer, ktime_set(0, stMotorData.u32PwmDutyCycle));

	if (eContinuous == stMotorData.u8MotorMode) {
		HW_MOTOR_fnPwmGenerator();
	} else {
		if (stMotorData.u32PwmPulses > 0) {
			stMotorData.u32PwmPulses--;
			HW_MOTOR_fnPwmGenerator();
			if (0 == stMotorData.u32PwmPulses) {
				gpio_set_value(ENABLE_PIN, DISABLE);
			}
		}
	}

	return HRTIMER_RESTART;
}

/*!
 * @brief		This function calculate steps to rotate to achieve given angle
 *
 * @param[in]		stMotorWriteData - structure to pass the angle
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
static void HW_MOTOR_fnSetMotorAngle(stMotorWriteData_t stTempData) {

	stMotorData.u32PwmPulses = stTempData.u16Data * 10 * DEFAULT_MICROS / DEFAULT_STEP_ANGLE * 2;
	gpio_set_value(ENABLE_PIN, DISABLE);
}

/*!
 * @brief		This function calculate duty cycle time to achive give speed
 *
 * @param[in]		stMotorWriteData - structure to pass the angle
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
static void HW_MOTOR_fnMotorSetSpeed(stMotorWriteData_t stTempData) {

	stMotorData.u32PwmFreq = stTempData.u16Data * 360 / 60 * DEFAULT_MICROS * 10 / DEFAULT_STEP_ANGLE;
	stMotorData.u32PwmDutyCycle = DEFAULT_CLOCK_PERIODS / (stMotorData.u32PwmFreq * 2);
}

/*!
 * @brief		This function to set the mode of motor
 *
 * @param[in]		stMotorWriteData - structure to pass the angle
 * @param[out]		Mode information will be loaded in stMotorData structure
 *
 * @retval 0		Success
 * @retval -1		Failure
 */
static int8_t HW_MOTOR_fnMotorSetMode(stMotorWriteData_t stTempData) {
	int8_t i8Ret = -1;

	switch (stTempData.u16Data) {
		case eContinuous:
		case eDirection:
			stMotorData.u8MotorMode = stTempData.u16Data;
			i8Ret = 0;
			break;
		default:
			break;
	}
	return i8Ret;
}

/** This function is called, when the device file is opened */
static int32_t HW_MOTOR_fnDriverOpen(struct inode *stDeviceFile, struct file *stInstance) {
	printk("dev_nr - open was called!\n");
	return 0;
}

/** This function is called, when the device file is opened */
static int32_t HW_MOTOR_fnDriverClose(struct inode *stDeviceFile, struct file *stInstance) {
	printk("dev_nr - close was called!\n");
	return 0;
}

/*!
 * @brief		This function get info from userspace and call corresponding funtions
 *
 * @param[in]		file descriptor - input from userspace
 * @param[in]		u32Cmd - command to control motor functions
 * @param[in]		u32Arg - size of the data from userspaec
 * @param[out]		Data will be loaded in stMotorData structure
 *
 * @retval 0 		Success
 * @retval EFAULT	Failure
 */
static long HW_MOTOR_fnMotorIoctl(struct file *stFile, u32_t u32Cmd, u64_t u64Arg) {
	stMotorWriteData_t stTempData;

	switch(u32Cmd) {
		case MOTOR_SET_WORKING:
			if(copy_from_user(&stTempData, (void __user *)u64Arg, sizeof(stMotorWriteData_t)))
			{
				printk("[%s:%d] MOTOR_SET_WORKING copy_from_user error\n", __func__, __LINE__);
				return -EFAULT;
			}
			gpio_set_value(ENABLE_PIN, !stTempData.u16Data);
			break;

		case MOTOR_SET_DIR:
			if(copy_from_user(&stTempData, (void __user *)u64Arg, sizeof(stMotorWriteData_t)))
			{
				printk("[%s:%d] MOTOR_SET_DIR copy_from_user error\n", __func__, __LINE__);
				return -EFAULT;
			}
			stMotorData.u8MotorDirection = !stMotorData.u8MotorDirection;
			gpio_set_value(DIRECT_PIN, stMotorData.u8MotorDirection);
			break;

		case MOTOR_SET_ANGLE:
			if(copy_from_user(&stTempData, (void __user *)u64Arg, sizeof(stMotorWriteData_t)))
			{
				printk("[%s:%d] MOTOR_SET_ANGLE copy_from_user error\n", __func__, __LINE__);
				return -EFAULT;
			}
			HW_MOTOR_fnSetMotorAngle(stTempData);
			break;

		case MOTOR_SET_SPEED:
			if(copy_from_user(&stTempData, (void __user *)u64Arg, sizeof(stMotorWriteData_t)))
			{
				printk("[%s:%d] MOTOR_SET_SPEED copy_from_user error\n", __func__, __LINE__);
				return -EFAULT;
			}
			HW_MOTOR_fnMotorSetSpeed(stTempData);
			break;

		case MOTOR_SET_MODE:
			if(copy_from_user(&stTempData, (void __user *)u64Arg, sizeof(stMotorWriteData_t)))
			{
				printk("[%s:%d] MOTOR_SET_MODE copy_from_user error\n", __func__, __LINE__);
				return -EFAULT;
			}
			HW_MOTOR_fnMotorSetMode(stTempData);
			break;

		default:
			printk("MOTOR_ioctl cmd:0x%x error\n",u32Cmd);
			break;
	}
	return 0;
}

/**
 * @brief	This file operations register in kernel 
 */
static struct file_operations stFops = {
	.owner = THIS_MODULE,
	.open = HW_MOTOR_fnDriverOpen,
	.release = HW_MOTOR_fnDriverClose,
	.unlocked_ioctl = HW_MOTOR_fnMotorIoctl
};

/**
 * @brief 	This function is called, when the module is loaded into the kernel
 */
static int __init HW_MOTOR_fnInit(void) {
	ktime_t ktime;

	/* Allocate a device nr */
	if( alloc_chrdev_region(&stDeviceNumber, 0, 1, DRIVER_NAME) < 0) {
		printk("Device Nr. could not be allocated!\n");
		return -1;
	}

	/* Create device class */
	if((stDeviceClass = class_create(THIS_MODULE, DRIVER_CLASS)) == NULL) {
		printk("Device class can not be created!\n");
		goto ClassError;
	}

	/* create device file */
	if(device_create(stDeviceClass, NULL, stDeviceNumber, NULL, DRIVER_NAME) == NULL) {
		printk("Can not create device file!\n");
		goto FileError;
	}

	/* Initialize device file */
	cdev_init(&stClassDev, &stFops);

	/* Regisering device to kernel */
	if(cdev_add(&stClassDev, stDeviceNumber, 1) == -1) {
		printk("Registering of device to kernel failed!\n");
		goto AddError;
	}

	/* GPIO enable pin init */
	if(gpio_request(ENABLE_PIN, ENABLE_CHIP)) {
		printk("Can not allocate GPIO Enable\n");
		goto AddError;
	}

	/* Set enable pin direction */
	if(gpio_direction_output(ENABLE_PIN, DISABLE)) {
		printk("Can not set GPIO Enable to output!\n");
		goto GpioENABLEerror;
	}

	/* GPIO direction pin init */
	if(gpio_request(DIRECT_PIN, DIRECT_CHIP)) {
		printk("Can not allocate Direction GPIO\n");
		goto GpioENABLEerror;
	}

	/* Set GPIO direction pin direction */
	if(gpio_direction_output(DIRECT_PIN, 1)) {
		printk("Can not set GPIO Direction to output!\n");
		goto GpioDIRECTerror;
	}

	/* GPIO pwm pin init */
	if(gpio_request(PWM_PIN, PWM_CHIP)) {
		printk("Can not allocate PWM GPIO\n");
		goto GpioDIRECTerror;
	}

	/* Set GPIO pwm pin direction */
	if(gpio_direction_output(PWM_PIN, 1)) {
		printk("Can not set GPIO PWM to output!\n");
		goto GpioPWMerror;
	}

	ktime = ktime_set(0, stMotorData.u32PwmDutyCycle);
	hrtimer_init(&etx_hr_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	etx_hr_timer.function = &timer_callback;
	hrtimer_start( &etx_hr_timer, ktime, HRTIMER_MODE_REL);

	return 0;
GpioPWMerror:
	gpio_free(PWM_PIN);
GpioDIRECTerror:
	gpio_free(DIRECT_PIN);
GpioENABLEerror:
	gpio_free(ENABLE_PIN);
AddError:
	device_destroy(stDeviceClass, stDeviceNumber);
FileError:
	class_destroy(stDeviceClass);
ClassError:
	unregister_chrdev_region(stDeviceNumber, 1);
	return -1;
}

/**
 * @brief 	This function is called, when the module is removed from the kernel
 */
static void __exit HW_MOTOR_fnExit(void) {
	hrtimer_cancel(&etx_hr_timer);
	gpio_set_value(ENABLE_PIN, DISABLE);
	gpio_free(ENABLE_PIN);
	gpio_free(DIRECT_PIN);
	gpio_free(PWM_PIN);
	cdev_del(&stClassDev);
	device_destroy(stDeviceClass, stDeviceNumber);
	class_destroy(stDeviceClass);
	unregister_chrdev_region(stDeviceNumber, 1);
}

module_init(HW_MOTOR_fnInit);
module_exit(HW_MOTOR_fnExit);

