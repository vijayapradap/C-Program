#include <linux/interrupt.h>
#include <linux/poll.h>
#include <linux/configfs.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/clk.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/miscdevice.h>
#include <linux/delay.h>
#include <linux/mm.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/irq.h>
#include <linux/types.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/ioctl.h>
#include <linux/cdev.h>
#include <linux/string.h>
#include <linux/list.h>
#include <linux/pci.h>
#include <asm/atomic.h>
#include <asm/unistd.h>
#include <linux/miscdevice.h>
#include <linux/gpio.h>

/********************************************************************************
 *      Copyright: 2024 Eaden Technology Pte Ltd. All rights reserved.
 *                 All trademarks are owned or licensed by Organization Name,
 *                 its subsidiaries or affiliated companies.
 *
 *       Filename:  ds18b20.c
 *    Description:  This is gpio driver source file for ds18b20 temp sensor
 *                  that is communicating with board via gpio.
 ********************************************************************************/

#define DRV_AUTHOR                          "Eaden"
#define DRV_DESC                            "ds18b20 driver"
#define DEVICE_NAME                         "ds18b20"

#define DS18B20_DATA_PIN   453   
typedef unsigned char BYTE;

static BYTE data[2];

BYTE ds18b20_reset(void)
{
    unsigned char retry=0;

    /*Configure GPIO 0 output mode*/
    gpio_direction_output(DS18B20_DATA_PIN, 0);

    /*Send a falling edge to ds18b20 and keep it for 480us (~960us)*/
    udelay(480);

    /*Send a rising edge to ds18b20, at which time the ds18b20 bus can be released*/
    gpio_direction_output(DS18B20_DATA_PIN, 1);

    /* Wait for 15~60us */
    udelay(60);

    /*The above action is to give ds18b20 a reset pulse. By configuring
    the GPIO pin to input mode, you can detect whether the ds18b20 is
    reset successfully */
    gpio_direction_input(DS18B20_DATA_PIN);

    /*If the bus is high after release, the reset fails*/
    while(!gpio_get_value(DS18B20_DATA_PIN) && (retry<240))
    {
        retry++;
        udelay(1);
    }
    if(retry>=240)
    {
        printk("ds18b20 reset failed !\n");
        gpio_direction_output(DS18B20_DATA_PIN, 1);
        return 1;
    }
    udelay(240);
    gpio_direction_output(DS18B20_DATA_PIN, 1);
    return 0;
}

BYTE ds18b20_read_byte(void)
{
    BYTE i = 0;
    BYTE byte = 0;

    /*Read "1" slot:
    If the bus status remains low between 1 microsecond and 15 microseconds
    Then jump to the high level state and maintain it between 15 microseconds and 60 microseconds
    It is considered that a "1" signal is read from DS18B20
    Ideal situation: low level for 1 microsecond and then jump and maintain high level for 60 microseconds

    Read "0" time slot:
    If the bus status remains low between 15 microseconds and 30 microseconds
    Then jump to the high level state and maintain it between 15 microseconds and 60 microseconds
    It is considered that a "0" signal is read from DS18B20
    Ideal situation: low level for 15 microseconds and then jump and maintain high level for 46 microseconds */
    local_irq_disable();
    for(i = 0; i < 8; i++)
    {
        gpio_direction_output(DS18B20_DATA_PIN, 1);
        udelay(2);
        gpio_set_value(DS18B20_DATA_PIN, 0);
        udelay(2);
        gpio_set_value(DS18B20_DATA_PIN, 1);
        udelay(8);
        byte >>= 1;
        gpio_direction_input(DS18B20_DATA_PIN);
        if (gpio_get_value(DS18B20_DATA_PIN))
            byte |= 0x80;
        udelay(50);
    }
    local_irq_enable();
    gpio_direction_output(DS18B20_DATA_PIN, 1);
    return byte;
}

BYTE ds18b20_write_byte(BYTE byte)
{
    BYTE i;

    /* Write "1" slot:
    Keep the bus low between 1 microsecond and 15 microseconds
    Then keep the bus high for 15 microseconds to 60 microseconds
    Ideal state: low level for 1 microsecond, then jumps and maintains high level for 60 microseconds

    Write "0" timeslot:
    Keep the bus low between 15 microseconds and 60 microseconds
    Then keep the bus high for 1 microsecond to 15 microseconds
    Ideal state: low level for 60 microseconds, then jumps and maintains high level for 1 microsecond */
    gpio_direction_output(DS18B20_DATA_PIN, 1);
    local_irq_disable();
    for(i = 0; i < 8; i++)
    {
        gpio_set_value(DS18B20_DATA_PIN, 1);
        udelay(2);
        gpio_set_value(DS18B20_DATA_PIN, 0);
        udelay(1);
        gpio_set_value(DS18B20_DATA_PIN, byte & 0x01);
        udelay(60);
        byte >>= 1;
    }
    local_irq_enable();
    gpio_direction_output(DS18B20_DATA_PIN, 1);
    return 0;
}

void ds18b20_read_temp(void)
{
    if (ds18b20_reset() != 0)
    {
        data[0] = 0x00;
        data[1] = 0x00;
        return;
    }
    /*Write the CCH command and skip the process of reading the serial number*/
    ds18b20_write_byte(0xcc);

    /*Write the 44H command to start temperature conversion with a delay of 5 us*/
    ds18b20_write_byte(0x44);
    udelay(5);

    if (ds18b20_reset() != 0)
    {
        data[0] = 0x00;
        data[1] = 0x00;
        return;
    }
    udelay(200);
    ds18b20_write_byte(0xcc);

    /*Write BEH command and read register*/
    ds18b20_write_byte(0xbe);

    /*Read the integer part of the temperature;*/
    data[0] = ds18b20_read_byte();
    data[1] = ds18b20_read_byte();

}

static ssize_t ds18b20_read(struct file *filp, char *buff, size_t len, loff_t *off)
{
    unsigned long err;
    ds18b20_read_temp();
    printk("data[0] = %#x, data[1] = %#x\n", data[0], data[1]);
    err = copy_to_user(buff, &data, sizeof(data));

    return err;
}

static struct file_operations ds18b20_fops =
{
    .owner = THIS_MODULE,
    .read = ds18b20_read,
};

static struct miscdevice misc =
{
    .minor = MISC_DYNAMIC_MINOR,
    .name = DEVICE_NAME,
    .fops = &ds18b20_fops,
};

static int __attribute__((unused))ds18b20_gpio_init(void)
{
    if (gpio_request(DS18B20_DATA_PIN, "ds18b20-data"))
    {
        printk("ds18b20-data: %d request failed!\n", DS18B20_DATA_PIN);
        gpio_free(DS18B20_DATA_PIN);
        return -1;
    }

    return 0;
}

static int __init ds18b20_init(void)
{
    int result;

    result = misc_register(&misc);
    printk(DEVICE_NAME "initialized.\n");
    if (result == 0)
    {
        ds18b20_read_temp();
    }
    return result;
}

static void __exit ds18b20_exit(void)
{
    misc_deregister(&misc);
}

module_init(ds18b20_init);
module_exit(ds18b20_exit);
MODULE_AUTHOR(DRV_AUTHOR);
MODULE_DESCRIPTION(DRV_DESC);
MODULE_LICENSE("GPL");
