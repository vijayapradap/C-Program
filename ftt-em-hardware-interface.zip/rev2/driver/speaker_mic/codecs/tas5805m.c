// SPDX-License-Identifier: GPL-2.0
//
// tas5805m.c - Driver for the TAS5805M Audio Amplifier
//
// Author: Andy Liu <andy-liu@ti.com>
// Author: Daniel Beer <daniel.beer@igorinstitute.com>
// Author: Thomas Moore <tcm0116@gmail.com>
//
// This is based on a driver originally written by Andy Liu at TI and
// posted here:
//
//    https://e2e.ti.com/support/audio-group/audio/f/audio-forum/722027/linux-tas5825m-linux-drivers
//
// It has been simplified a little and reworked for the 5.x ALSA SoC API.

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/of.h>
#include <linux/init.h>
#include <linux/i2c.h>
#include <linux/regmap.h>
#include <linux/version.h>
#include <linux/workqueue.h>

#include <sound/soc.h>
#include <sound/pcm.h>
#include <sound/initval.h>
#include <sound/tlv.h>

#include "tas5805m.h"
#include "tas5805m_config.h"

//kcontrol helper defines that are not provided by ALSA SOC
#define SOC_SINGLE_STS(xname, reg, shift, max, invert) \
{									\
	.iface = SNDRV_CTL_ELEM_IFACE_MIXER, .name = (xname),		\
	.info = snd_soc_info_volsw, .get = snd_soc_get_volsw,		\
	.access = SNDRV_CTL_ELEM_ACCESS_READ | SNDRV_CTL_ELEM_ACCESS_VOLATILE,	\
	.private_value = SOC_SINGLE_VALUE(reg, shift, max, invert, 0) \
}


// Per the Data Manual for the TAS3103, these values are represented via a
// Q5.23 format and are computed as:
//    8388608 * 10^(Gain_dB/20)
static const uint32_t tas5805m_dsp_volume[] = {
	0x0000001A, /*    0, -110.0dB */	0x0000001C, /*    1, -109.5dB */
	0x0000001D, /*    2, -109.0dB */	0x0000001F, /*    3, -108.5dB */
	0x00000021, /*    4, -108.0dB */	0x00000023, /*    5, -107.5dB */
	0x00000025, /*    6, -107.0dB */	0x00000027, /*    7, -106.5dB */
	0x0000002A, /*    8, -106.0dB */	0x0000002C, /*    9, -105.5dB */
	0x0000002F, /*   10, -105.0dB */	0x00000031, /*   11, -104.5dB */
	0x00000034, /*   12, -104.0dB */	0x00000038, /*   13, -103.5dB */
	0x0000003B, /*   14, -103.0dB */	0x0000003E, /*   15, -102.5dB */
	0x00000042, /*   16, -102.0dB */	0x00000046, /*   17, -101.5dB */
	0x0000004A, /*   18, -101.0dB */	0x0000004F, /*   19, -100.5dB */
	0x00000053, /*   20, -100.0dB */	0x00000058, /*   21,  -99.5dB */
	0x0000005E, /*   22,  -99.0dB */	0x00000063, /*   23,  -98.5dB */
	0x00000069, /*   24,  -98.0dB */	0x0000006F, /*   25,  -97.5dB */
	0x00000076, /*   26,  -97.0dB */	0x0000007D, /*   27,  -96.5dB */
	0x00000084, /*   28,  -96.0dB */	0x0000008C, /*   29,  -95.5dB */
	0x00000095, /*   30,  -95.0dB */	0x0000009E, /*   31,  -94.5dB */
	0x000000A7, /*   32,  -94.0dB */	0x000000B1, /*   33,  -93.5dB */
	0x000000BB, /*   34,  -93.0dB */	0x000000C6, /*   35,  -92.5dB */
	0x000000D2, /*   36,  -92.0dB */	0x000000DF, /*   37,  -91.5dB */
	0x000000EC, /*   38,  -91.0dB */	0x000000FA, /*   39,  -90.5dB */
	0x00000109, /*   40,  -90.0dB */	0x00000118, /*   41,  -89.5dB */
	0x00000129, /*   42,  -89.0dB */	0x0000013B, /*   43,  -88.5dB */
	0x0000014D, /*   44,  -88.0dB */	0x00000161, /*   45,  -87.5dB */
	0x00000176, /*   46,  -87.0dB */	0x0000018C, /*   47,  -86.5dB */
	0x000001A4, /*   48,  -86.0dB */	0x000001BD, /*   49,  -85.5dB */
	0x000001D7, /*   50,  -85.0dB */	0x000001F3, /*   51,  -84.5dB */
	0x00000211, /*   52,  -84.0dB */	0x00000230, /*   53,  -83.5dB */
	0x00000251, /*   54,  -83.0dB */	0x00000275, /*   55,  -82.5dB */
	0x0000029A, /*   56,  -82.0dB */	0x000002C1, /*   57,  -81.5dB */
	0x000002EB, /*   58,  -81.0dB */	0x00000317, /*   59,  -80.5dB */
	0x00000346, /*   60,  -80.0dB */	0x00000378, /*   61,  -79.5dB */
	0x000003AD, /*   62,  -79.0dB */	0x000003E4, /*   63,  -78.5dB */
	0x00000420, /*   64,  -78.0dB */	0x0000045E, /*   65,  -77.5dB */
	0x000004A0, /*   66,  -77.0dB */	0x000004E7, /*   67,  -76.5dB */
	0x00000531, /*   68,  -76.0dB */	0x00000580, /*   69,  -75.5dB */
	0x000005D3, /*   70,  -75.0dB */	0x0000062C, /*   71,  -74.5dB */
	0x00000689, /*   72,  -74.0dB */	0x000006EC, /*   73,  -73.5dB */
	0x00000755, /*   74,  -73.0dB */	0x000007C5, /*   75,  -72.5dB */
	0x0000083B, /*   76,  -72.0dB */	0x000008B7, /*   77,  -71.5dB */
	0x0000093C, /*   78,  -71.0dB */	0x000009C8, /*   79,  -70.5dB */
	0x00000A5C, /*   80,  -70.0dB */	0x00000AF9, /*   81,  -69.5dB */
	0x00000BA0, /*   82,  -69.0dB */	0x00000C50, /*   83,  -68.5dB */
	0x00000D0B, /*   84,  -68.0dB */	0x00000DD1, /*   85,  -67.5dB */
	0x00000EA3, /*   86,  -67.0dB */	0x00000F81, /*   87,  -66.5dB */
	0x0000106C, /*   88,  -66.0dB */	0x00001165, /*   89,  -65.5dB */
	0x0000126D, /*   90,  -65.0dB */	0x00001384, /*   91,  -64.5dB */
	0x000014AC, /*   92,  -64.0dB */	0x000015E6, /*   93,  -63.5dB */
	0x00001732, /*   94,  -63.0dB */	0x00001892, /*   95,  -62.5dB */
	0x00001A07, /*   96,  -62.0dB */	0x00001B92, /*   97,  -61.5dB */
	0x00001D34, /*   98,  -61.0dB */	0x00001EEF, /*   99,  -60.5dB */
	0x000020C4, /*  100,  -60.0dB */	0x000022B5, /*  101,  -59.5dB */
	0x000024C4, /*  102,  -59.0dB */	0x000026F1, /*  103,  -58.5dB */
	0x00002940, /*  104,  -58.0dB */	0x00002BB2, /*  105,  -57.5dB */
	0x00002E49, /*  106,  -57.0dB */	0x00003107, /*  107,  -56.5dB */
	0x000033EF, /*  108,  -56.0dB */	0x00003702, /*  109,  -55.5dB */
	0x00003A45, /*  110,  -55.0dB */	0x00003DB9, /*  111,  -54.5dB */
	0x00004161, /*  112,  -54.0dB */	0x00004541, /*  113,  -53.5dB */
	0x0000495B, /*  114,  -53.0dB */	0x00004DB4, /*  115,  -52.5dB */
	0x0000524F, /*  116,  -52.0dB */	0x0000572F, /*  117,  -51.5dB */
	0x00005C5A, /*  118,  -51.0dB */	0x000061D3, /*  119,  -50.5dB */
	0x0000679F, /*  120,  -50.0dB */	0x00006DC2, /*  121,  -49.5dB */
	0x00007443, /*  122,  -49.0dB */	0x00007B27, /*  123,  -48.5dB */
	0x00008273, /*  124,  -48.0dB */	0x00008A2E, /*  125,  -47.5dB */
	0x0000925E, /*  126,  -47.0dB */	0x00009B0A, /*  127,  -46.5dB */
	0x0000A43A, /*  128,  -46.0dB */	0x0000ADF5, /*  129,  -45.5dB */
	0x0000B844, /*  130,  -45.0dB */	0x0000C32F, /*  131,  -44.5dB */
	0x0000CEC0, /*  132,  -44.0dB */	0x0000DB00, /*  133,  -43.5dB */
	0x0000E7FA, /*  134,  -43.0dB */	0x0000F5B9, /*  135,  -42.5dB */
	0x00010449, /*  136,  -42.0dB */	0x000113B5, /*  137,  -41.5dB */
	0x0001240B, /*  138,  -41.0dB */	0x00013559, /*  139,  -40.5dB */
	0x000147AE, /*  140,  -40.0dB */	0x00015B18, /*  141,  -39.5dB */
	0x00016FA9, /*  142,  -39.0dB */	0x00018572, /*  143,  -38.5dB */
	0x00019C86, /*  144,  -38.0dB */	0x0001B4F7, /*  145,  -37.5dB */
	0x0001CEDC, /*  146,  -37.0dB */	0x0001EA49, /*  147,  -36.5dB */
	0x00020756, /*  148,  -36.0dB */	0x0002261C, /*  149,  -35.5dB */
	0x000246B4, /*  150,  -35.0dB */	0x0002693B, /*  151,  -34.5dB */
	0x00028DCE, /*  152,  -34.0dB */	0x0002B48C, /*  153,  -33.5dB */
	0x0002DD95, /*  154,  -33.0dB */	0x0003090D, /*  155,  -32.5dB */
	0x00033718, /*  156,  -32.0dB */	0x000367DD, /*  157,  -31.5dB */
	0x00039B87, /*  158,  -31.0dB */	0x0003D240, /*  159,  -30.5dB */
	0x00040C37, /*  160,  -30.0dB */	0x0004499D, /*  161,  -29.5dB */
	0x00048AA7, /*  162,  -29.0dB */	0x0004CF8B, /*  163,  -28.5dB */
	0x00051884, /*  164,  -28.0dB */	0x000565D0, /*  165,  -27.5dB */
	0x0005B7B1, /*  166,  -27.0dB */	0x00060E6C, /*  167,  -26.5dB */
	0x00066A4A, /*  168,  -26.0dB */	0x0006CB9A, /*  169,  -25.5dB */
	0x000732AE, /*  170,  -25.0dB */	0x00079FDD, /*  171,  -24.5dB */
	0x00081385, /*  172,  -24.0dB */	0x00088E07, /*  173,  -23.5dB */
	0x00090FCB, /*  174,  -23.0dB */	0x00099940, /*  175,  -22.5dB */
	0x000A2ADA, /*  176,  -22.0dB */	0x000AC515, /*  177,  -21.5dB */
	0x000B6873, /*  178,  -21.0dB */	0x000C157F, /*  179,  -20.5dB */
	0x000CCCCC, /*  180,  -20.0dB */	0x000D8EF6, /*  181,  -19.5dB */
	0x000E5CA1, /*  182,  -19.0dB */	0x000F367B, /*  183,  -18.5dB */
	0x00101D3F, /*  184,  -18.0dB */	0x001111AE, /*  185,  -17.5dB */
	0x0012149A, /*  186,  -17.0dB */	0x001326DD, /*  187,  -16.5dB */
	0x00144960, /*  188,  -16.0dB */	0x00157D1A, /*  189,  -15.5dB */
	0x0016C310, /*  190,  -15.0dB */	0x00181C57, /*  191,  -14.5dB */
	0x00198A13, /*  192,  -14.0dB */	0x001B0D7B, /*  193,  -13.5dB */
	0x001CA7D7, /*  194,  -13.0dB */	0x001E5A84, /*  195,  -12.5dB */
	0x002026F3, /*  196,  -12.0dB */	0x00220EA9, /*  197,  -11.5dB */
	0x00241346, /*  198,  -11.0dB */	0x00263680, /*  199,  -10.5dB */
	0x00287A26, /*  200,  -10.0dB */	0x002AE025, /*  201,   -9.5dB */
	0x002D6A86, /*  202,   -9.0dB */	0x00301B70, /*  203,   -8.5dB */
	0x0032F52C, /*  204,   -8.0dB */	0x0035FA26, /*  205,   -7.5dB */
	0x00392CED, /*  206,   -7.0dB */	0x003C9038, /*  207,   -6.5dB */
	0x004026E7, /*  208,   -6.0dB */	0x0043F405, /*  209,   -5.5dB */
	0x0047FACC, /*  210,   -5.0dB */	0x004C3EA8, /*  211,   -4.5dB */
	0x0050C335, /*  212,   -4.0dB */	0x00558C4B, /*  213,   -3.5dB */
	0x005A9DF7, /*  214,   -3.0dB */	0x005FFC88, /*  215,   -2.5dB */
	0x0065AC8C, /*  216,   -2.0dB */	0x006BB2D6, /*  217,   -1.5dB */
	0x00721482, /*  218,   -1.0dB */	0x0078D6FC, /*  219,   -0.5dB */
	0x00800000, /*  220,    0.0dB */	0x008795A0, /*  221,    0.5dB */
	0x008F9E4C, /*  222,    1.0dB */	0x009820D7, /*  223,    1.5dB */
	0x00A12477, /*  224,    2.0dB */	0x00AAB0D4, /*  225,    2.5dB */
	0x00B4CE07, /*  226,    3.0dB */	0x00BF84A6, /*  227,    3.5dB */
	0x00CADDC7, /*  228,    4.0dB */	0x00D6E30C, /*  229,    4.5dB */
	0x00E39EA8, /*  230,    5.0dB */	0x00F11B69, /*  231,    5.5dB */
	0x00FF64C1, /*  232,    6.0dB */	0x010E86CF, /*  233,    6.5dB */
	0x011E8E6A, /*  234,    7.0dB */	0x012F892C, /*  235,    7.5dB */
	0x0141857E, /*  236,    8.0dB */	0x015492A3, /*  237,    8.5dB */
	0x0168C0C5, /*  238,    9.0dB */	0x017E2104, /*  239,    9.5dB */
	0x0194C583, /*  240,   10.0dB */	0x01ACC179, /*  241,   10.5dB */
	0x01C62940, /*  242,   11.0dB */	0x01E11266, /*  243,   11.5dB */
	0x01FD93C1, /*  244,   12.0dB */	0x021BC582, /*  245,   12.5dB */
	0x023BC147, /*  246,   13.0dB */	0x025DA234, /*  247,   13.5dB */
	0x02818508, /*  248,   14.0dB */	0x02A78836, /*  249,   14.5dB */
	0x02CFCC01, /*  250,   15.0dB */	0x02FA7292, /*  251,   15.5dB */
	0x0327A01A, /*  252,   16.0dB */	0x03577AEF, /*  253,   16.5dB */
	0x038A2BAC, /*  254,   17.0dB */	0x03BFDD55, /*  255,   17.5dB */
	0x03F8BD79, /*  256,   18.0dB */	0x0434FC5C, /*  257,   18.5dB */
	0x0474CD1B, /*  258,   19.0dB */	0x04B865DE, /*  259,   19.5dB */
	0x05000000, /*  260,   20.0dB */	0x054BD842, /*  261,   20.5dB */
	0x059C2F01, /*  262,   21.0dB */	0x05F14868, /*  263,   21.5dB */
	0x064B6CAD, /*  264,   22.0dB */	0x06AAE84D, /*  265,   22.5dB */
	0x07100C4D, /*  266,   23.0dB */	0x077B2E7F, /*  267,   23.5dB */
	0x07ECA9CD, /*  268,   24.0dB */
};

#define TAS5805M_DSP_VOLUME_MAX_IDX	(ARRAY_SIZE(tas5805m_dsp_volume) - 1)
#define TAS5805M_DSP_VOLUME_MIN_IDX	0

#define TAS5805M_DSP_VOLUME_MAX_DB	24
#define TAS5805M_DSP_VOLUME_MIN_DB	-110

struct tas5805m_priv {
	struct regmap *regmap;
	bool configured;
	u8 book;
	u8 page;
	u8 mute;
	u8 ctrl_state;
	struct work_struct config_dsp_work;
	struct snd_soc_component *component;
};

static int tas5805m_i2c_send(const struct i2c_client *client,
			     const char *buf, int count)
{
	int ret = i2c_master_send(client, buf, count);
	if (ret != count) {
		dev_err(&client->dev, "I2C error %d\n", ret);
		if (ret < 0)
			return ret;
		else
			return -EIO;
	}

	return 0;
}

static int tas5805m_select_book_page(void *context,
				     u8 book,
				     u8 page)
{
	struct i2c_client *client = context;
	struct tas5805m_priv *tas5805m = i2c_get_clientdata(client);
	u8 data[2];
	int ret;

	pr_debug("tas5805m_select_book_page: %02x, %02x\n", book, page);

	// Keep track of the book and page that have been selected
	if ((book == tas5805m->book) && (page == tas5805m->page)) {
		pr_debug("tas5805m_select_book_page: already on book %02x and "
			 "page %02x\n", book, page);
		return 0;
	}

	if (tas5805m->book != book) {
		if (tas5805m->page != TAS5805M_PAGE_00) {
			// Select page 0 before changing the book
			data[0] = TAS5805M_REG_PAGE_SEL;
			data[1] = TAS5805M_PAGE_00;
			ret = tas5805m_i2c_send(client, data, 2);
			if (ret != 0)
				return ret;
		}

		// Select the book
		data[0] = TAS5805M_REG_BOOK_SEL;
		data[1] = book;
		ret = tas5805m_i2c_send(client, data, 2);
		if (ret != 0)
			return ret;
	}

	// Select the page
	data[0] = TAS5805M_REG_PAGE_SEL;
	data[1] = page;
	ret = tas5805m_i2c_send(client, data, 2);
	if (ret != 0)
		return ret;

	tas5805m->book = book;
	tas5805m->page = page;

	return ret;
}

int tas5805m_hw_read(void *context, unsigned int reg, unsigned int *value)
{
	struct i2c_client *client = context;
	struct i2c_msg xfer[2];
	uint8_t len = TAS5805M_REG_LEN(reg);
	uint8_t book = TAS5805M_REG_BOOK(reg);
	uint8_t page = TAS5805M_REG_PAGE(reg);
	uint8_t offset = TAS5805M_REG_OFFSET(reg);
	uint8_t buf[4];
	uint8_t i;
	int ret;

	if (len == 0)
		return -EINVAL;

	// Select the book and page
	ret = tas5805m_select_book_page(context, book, page);
	if (ret != 0)
		return ret;

	// Write register
	xfer[0].addr = client->addr;
	xfer[0].flags = 0;
	xfer[0].len = 1;
	xfer[0].buf = &offset;

	// Read data
	xfer[1].addr = client->addr;
	xfer[1].flags = I2C_M_RD;
	xfer[1].len = len;
	xfer[1].buf = buf;

	ret = i2c_transfer(client->adapter, xfer, 2);
	if (ret < 0)
		return ret;
	else if (ret != 2)
		return -EIO;

	*value = 0;

	for (i = 0; i < len; i++) {
		*value <<= 8;
		*value |= buf[i];
	}

	pr_debug("tas5805m_hw_read: 0x%08x = 0x%08x\n", reg, *((u32*)value));

	return 0;
}

int tas5805m_hw_write(void *context, unsigned int reg, unsigned int value)
{
	struct i2c_client *client = context;
	uint8_t len = TAS5805M_REG_LEN(reg);
	uint8_t book = TAS5805M_REG_BOOK(reg);
	uint8_t page = TAS5805M_REG_PAGE(reg);
	uint8_t offset = TAS5805M_REG_OFFSET(reg);
	u8 data[5];
	uint8_t i;
	int ret;

	pr_debug("tas5805m_hw_write: 0x%08x, 0x%08x\n", reg, value);

	//I believe this is not needed tas5805m_hw_write is not called for meta values
	if (reg == CFG_META_DELAY) {
		mdelay(value);
		return 0;
	}
	else if (len == 0)
		return -EINVAL;

	// Select the book and page
	ret = tas5805m_select_book_page(context, book, page);
	if (ret != 0)
		return ret;

	data[0] = offset;

	for (i = len; i >= 1; --i) {
		data[i] = value;
		value >>= 8;
	}

	ret = tas5805m_i2c_send(client, data, len + 1);
	if (ret != 0)
		return ret;

	return 0;
}

static bool tas5805m_volatile_reg(struct device *dev, unsigned int reg)
{
	switch (reg) {
	case TAS5805M_REG_RESET_CTRL:
	case TAS5805M_REG_DEVICE_CTRL_2:
		return true;
	}
	return false;
}

static const struct reg_default tas5805m_regmap_default[] = {
	{ TAS5805M_REG_RESET_CTRL,	TAS5805M_REG_RESET_CTRL_INIT	},
	{ TAS5805M_REG_DEVICE_CTRL_2,	TAS5805M_REG_DEVICE_CTRL_2_INIT	},
	{ TAS5805M_REG_SAP_CTRL3,	TAS5805M_REG_SAP_CTRL3_INIT	},
	{ TAS5805M_REG_DIG_VOL_CTL,	TAS5805M_REG_DIG_VOL_CTL_INIT	},
	{ TAS5805M_REG_AGAIN,		TAS5805M_REG_AGAIN_INIT		},
	{ TAS5805M_REG_L_VOL,		TAS5805M_REG_L_VOL_INIT		},
	{ TAS5805M_REG_R_VOL,		TAS5805M_REG_R_VOL_INIT		},
	{ TAS5805M_REG_MISC_CONTROL,		TAS5805M_REG_MISC_CONTROL_INIT		},
};

const struct regmap_config tas5805m_regmap = {
	.reg_bits = 32,
	.val_bits = 32,
	.max_register = TAS5805M_MAX_REGISTER,
	.reg_read = tas5805m_hw_read,
	.reg_write = tas5805m_hw_write,
	.cache_type = REGCACHE_RBTREE,
	.volatile_reg = tas5805m_volatile_reg,
	.reg_defaults = tas5805m_regmap_default,
	.num_reg_defaults = ARRAY_SIZE(tas5805m_regmap_default),
};

static const struct snd_soc_dapm_widget tas5805m_dapm_widgets[] = {
	SND_SOC_DAPM_AIF_IN("DAC IN", "Playback", 0, SND_SOC_NOPM, 0, 0),
	SND_SOC_DAPM_AIF_OUT("ADC OUT", "Capture", 0, SND_SOC_NOPM, 0, 0),
	SND_SOC_DAPM_OUTPUT("OUT"),
	SND_SOC_DAPM_INPUT("IN")
};

static const struct snd_soc_dapm_route tas5805m_audio_map[] = {
	{ "OUT", NULL, "DAC IN" },
	{ "ADC OUT", NULL, "IN" },
};

static int tas5805m_dsp_vol_get(struct snd_kcontrol *kcontrol,
				struct snd_ctl_elem_value *ucontrol)
{
	struct snd_soc_component *component =
		snd_soc_kcontrol_component(kcontrol);
	struct soc_mixer_control *mc =
		(struct soc_mixer_control *)kcontrol->private_value;
	uint32_t val1, val2;
	int i;

	val1 = snd_soc_component_read(component, mc->reg);
	pr_debug("tas5805m_dsp_vol_get: 0x%08x = 0x%08x\n", mc->reg, val1);

	for (i = 0; val1 > tas5805m_dsp_volume[i]; i++)
		;
	ucontrol->value.integer.value[0] = i;

	if (mc->reg != mc->rreg) {
		val2 = snd_soc_component_read(component, mc->rreg);
		pr_debug("tas5805m_dsp_vol_get: 0x%08x = 0x%08x\n",
			 mc->rreg, val2);

		for (i = 0; val2 > tas5805m_dsp_volume[i]; i++)
			;
		ucontrol->value.integer.value[1] = i;
	}

	pr_debug("tas5805m_dsp_vol_get: %ld/%ld\n",
		 ucontrol->value.integer.value[0],
		 ucontrol->value.integer.value[1]);

	return 0;
}

static int tas5805m_dsp_vol_put(struct snd_kcontrol *kcontrol,
				struct snd_ctl_elem_value *ucontrol)
{
	struct snd_soc_component *component =
		snd_soc_kcontrol_component(kcontrol);
	struct soc_mixer_control *mc =
		(struct soc_mixer_control *)kcontrol->private_value;
	int idx1 = ucontrol->value.integer.value[0];
	int idx2 = ucontrol->value.integer.value[1];
	bool stereo = false;
	u32 val1, val2;
	int ret;

	pr_debug("tas5805m_dsp_vol_put: %d/%d\n", idx1, idx2);

	if ((idx1 < 0) || (idx1 > mc->max))
		return -EINVAL;

	val1 = tas5805m_dsp_volume[idx1];

	if (mc->reg != mc->rreg) {
		if ((idx2 < 0) || (idx2 > mc->max))
			return -EINVAL;

		val2 = tas5805m_dsp_volume[idx2];
		stereo = true;
	}

	pr_debug("tas5805m_dsp_vol_put: reg = 0x%08x\n", val1);
	ret = snd_soc_component_write(component, mc->reg, val1);
	if (ret < 0)
		return ret;

	if (stereo) {
		pr_debug("tas5805m_dsp_vol_put: rreg = 0x%08x\n", val2);
		ret = snd_soc_component_write(component, mc->rreg, val2);
		if (ret < 0)
			return ret;
	}

	return 0;
}

static const DECLARE_TLV_DB_MINMAX(tas5805m_dsp_vol_tlv,
				   TAS5805M_DSP_VOLUME_MIN_DB * 100,
				   TAS5805M_DSP_VOLUME_MAX_DB * 100);
static const DECLARE_TLV_DB_MINMAX_MUTE(tas5805m_digital_vol_tlv, -10350, 2400);
static const DECLARE_TLV_DB_MINMAX(tas5805m_again_tlv, -1550, 0);

static const char * const power_mode_texts[] = {"Deep Sleep", "Sleep", "HiZ", "Play"};
static const struct soc_enum power_mode_enum = SOC_ENUM_SINGLE(TAS5805M_REG_DEVICE_CTRL_2, 0, ARRAY_SIZE(power_mode_texts), power_mode_texts);
static const struct soc_enum power_mode_readonly_enum = SOC_ENUM_SINGLE(TAS5805M_REG_POWER_STATE, 0, ARRAY_SIZE(power_mode_texts), power_mode_texts);

static const struct snd_kcontrol_new tas5805m_mixer_controls[] =
{
	SOC_DOUBLE_R_EXT_TLV("Master Playback Volume", TAS5805M_REG_L_VOL,
			     TAS5805M_REG_R_VOL, 0, TAS5805M_DSP_VOLUME_MAX_IDX,
			     0, tas5805m_dsp_vol_get, tas5805m_dsp_vol_put,
			     tas5805m_dsp_vol_tlv),
	SOC_DOUBLE("Master Playback Switch", TAS5805M_REG_SAP_CTRL3,
		   TAS5805M_LEFT_DAC_DPATH_SHIFT,
		   TAS5805M_RIGHT_DAC_DPATH_SHIFT, 1, 0),
	SOC_SINGLE_TLV("Digital Playback Volume", TAS5805M_REG_DIG_VOL_CTL, 0,
		       TAS5805M_PGA_MASK, true, tas5805m_digital_vol_tlv),
	SOC_SINGLE_TLV("Analog Gain Volume", TAS5805M_REG_AGAIN, 0,
		       TAS5805M_ANA_GAIN_MASK, true, tas5805m_again_tlv),

	SOC_ENUM("Power Mode", power_mode_enum),
	SOC_ENUM("Power Mode Readonly", power_mode_readonly_enum),

	SOC_SINGLE("SDOUT Post DSP Switch", TAS5805M_REG_SDOUT_SEL, 0, 1, 1),

	SOC_SINGLE("EQ Switch", TAS5805M_REG_DSP_MISC, 0, 1, 1),
	SOC_SINGLE("DRC Switch", TAS5805M_REG_DSP_MISC, 1, 1, 1),
	SOC_SINGLE("FIR Switch", TAS5805M_REG_DSP_MISC, 2, 1, 1),

	SOC_DOUBLE_STS("Over Current Fault Flag", TAS5805M_REG_CHAN_FAULT, 1, 0, 1, 0),
	SOC_DOUBLE_STS("DC Fault Flag", TAS5805M_REG_CHAN_FAULT, 3, 2, 1, 0),
	SOC_SINGLE_STS("Supply Under Voltage Fault Flag", TAS5805M_REG_GLOBAL_FAULT1, 0, 1, 0),
	SOC_SINGLE_STS("Supply Over Voltage Fault Flag", TAS5805M_REG_GLOBAL_FAULT1, 1, 1, 0),
	SOC_SINGLE_STS("Clock Fault Flag", TAS5805M_REG_GLOBAL_FAULT1, 2, 1, 0),
	SOC_SINGLE_STS("DSP Write Fault Flag", TAS5805M_REG_GLOBAL_FAULT1, 6, 1, 0),
	SOC_SINGLE_STS("CRC Fault Flag", TAS5805M_REG_GLOBAL_FAULT1, 7, 1, 0),
	SOC_SINGLE_STS("Over Temperature Warning Flag", TAS5805M_REG_OT_WARNING, 2, 1, 0),
	SOC_SINGLE_STS("Over Temperature Shutdown Flag", TAS5805M_REG_GLOBAL_FAULT2, 0, 1, 0),
	SOC_SINGLE("Over Temperature Shutdown Recovery Switch", TAS5805M_REG_MISC_CONTROL, 4, 1, 0),
};

static int tas5805m_set_bias_level(struct snd_soc_component *component,
				   enum snd_soc_bias_level level)
{
	struct tas5805m_priv *tas5805m =
		snd_soc_component_get_drvdata(component);
	int ret = 0;

	pr_info("tas5805m_set_bias_level: %d\n", level);

	if(level == SND_SOC_BIAS_OFF) {

		if (tas5805m->configured) {
			ret = snd_soc_component_update_bits(component,TAS5805M_REG_DEVICE_CTRL_2,TAS5805M_CTRL_STATE_MASK,TAS5805M_DEEP_SLEEP);
			pr_info("tas5805m_set_bias_level: SND_SOC_BIAS_OFF\n");
			if (ret < 0){
				printk(">>>>>> [%s:%d] tas5805m debug: return %d\n", __func__, __LINE__, ret);
				return ret;
			}
			}
	}
	printk(">>>>>> [%s:%d] tas5805m debug: return 0\n", __func__, __LINE__);

	return 0;
}

static struct snd_soc_component_driver soc_component_tas5805m = {
	.set_bias_level		= tas5805m_set_bias_level,
	.controls		= tas5805m_mixer_controls,
	.num_controls		= ARRAY_SIZE(tas5805m_mixer_controls),
	.dapm_widgets		= tas5805m_dapm_widgets,
	.num_dapm_widgets	= ARRAY_SIZE(tas5805m_dapm_widgets),
	.dapm_routes		= tas5805m_audio_map,
	.num_dapm_routes	= ARRAY_SIZE(tas5805m_audio_map),
	.suspend_bias_off	= 1,
	.endianness			= 1,
};

static int tas5805m_dai_mute(struct snd_soc_dai *dai, int mute, int stream)
{
	struct snd_soc_component *component = dai->component;
	struct tas5805m_priv *tas5805m =
		snd_soc_component_get_drvdata(component);
	int ret = 0;

	pr_info("tas5805m_dai_mute: %d, %d\n", mute, stream);

	if (tas5805m->configured) {
		if(mute){
			//mute
			ret = snd_soc_component_update_bits(component,TAS5805M_REG_DEVICE_CTRL_2,TAS5805M_MUTE_MASK,TAS5805M_MUTE);
			printk(">>>>>> [%s:%d] tas5805m debug: ret %d\n", __func__, __LINE__, ret);

			//power down
			ret |= snd_soc_component_update_bits(component,TAS5805M_REG_DEVICE_CTRL_2,TAS5805M_CTRL_STATE_MASK,TAS5805M_DEEP_SLEEP);
			printk(">>>>>> [%s:%d] tas5805m debug: ret %d\n", __func__, __LINE__, ret);
		}
		else if(stream == 0){
			//power up and unmute in playbabck
			//this call will only happen in playback if no_capture_mute bit is set
			//power up sequence. This is needed because we are coming up from deep sleep and not slep
			ret = snd_soc_component_update_bits(component,TAS5805M_REG_DEVICE_CTRL_2,TAS5805M_CTRL_STATE_MASK,TAS5805M_HI_Z);
			printk(">>>>>> [%s:%d] tas5805m debug: ret %d\n", __func__, __LINE__, ret);
			ret |= snd_soc_component_update_bits(component,TAS5805M_REG_DEVICE_CTRL_2,TAS5805M_CTRL_STATE_MASK,TAS5805M_PLAY);
			printk(">>>>>> [%s:%d] tas5805m debug: ret %d\n", __func__, __LINE__, ret);

			//unmute
			ret |= snd_soc_component_update_bits(component,TAS5805M_REG_DEVICE_CTRL_2,TAS5805M_MUTE_MASK,0);
		}

		if (ret < 0)
			return ret;
	}

	return 0;
}

static int tas5805m_trigger(struct snd_pcm_substream *substream,
			    int cmd,
			    struct snd_soc_dai *dai)
{
	struct snd_soc_component *component = dai->component;
	struct tas5805m_priv *tas5805m =
		snd_soc_component_get_drvdata(component);

	pr_info("tas5805m_trigger: %d\n", cmd);

	switch (cmd) {
	case SNDRV_PCM_TRIGGER_START:
	case SNDRV_PCM_TRIGGER_RESUME:
	case SNDRV_PCM_TRIGGER_PAUSE_RELEASE:
		if (!tas5805m->configured && (snd_soc_dai_active(dai) == 1))
		{
			// The TAS5805M requires the BCLK to be enabled before
			// the DSP can be configured. The configuration must be
			// done during or after the DAI trigger callback so in
			// order to allow the first stream to play successfully.
			// However, the trigger callback usually executes in an
			// atomic context, which can result in a "scheduling
			// while atomic" bug if the platform I2C driver sleeps
			// during the I2C transaction (e.g. the imx I2C driver).
			// Scheduling the configuration to occur in the process
			// context allows the trigger to be executed in a non-
			// atomic context, allowing the I2C transactions to be
			// successful.
			tas5805m->component = component;
			schedule_work(&tas5805m->config_dsp_work);
		}
		break;
	case SNDRV_PCM_TRIGGER_STOP:
	case SNDRV_PCM_TRIGGER_SUSPEND:
	case SNDRV_PCM_TRIGGER_PAUSE_PUSH:
		break;
	default:
		return -EINVAL;
	}

	return 0;
}

static const struct snd_soc_dai_ops tas5805m_dai_ops = {
	.mute_stream	= tas5805m_dai_mute,
	.trigger	= tas5805m_trigger,
	.no_capture_mute = 1,
};

static struct snd_soc_dai_driver tas5805m_dai = {
	.name		= "tas5805m-amplifier",
	.playback	= {
		.stream_name	= "Playback",
		.channels_min	= 2,
		.channels_max	= 2,
		.rates		= TAS5805M_RATES,
		.formats	= TAS5805M_FORMATS,
	},
	.capture	= {
		.stream_name	= "Capture",
		.channels_min	= 2,
		.channels_max	= 2,
		.rates		= TAS5805M_RATES,
		.formats	= TAS5805M_FORMATS,
	},
	.ops = &tas5805m_dai_ops,
	.symmetric_channels = 1,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	.symmetric_rate = 1,
	.symmetric_sample_bits = 1,
#else
	.symmetric_rates = 1,
	.symmetric_samplebits = 1,
#endif
};

static void tas5805m_config_dsp(struct work_struct *work)
{
	struct tas5805m_priv *tas5805m =
		container_of(work, struct tas5805m_priv, config_dsp_work);
	struct snd_soc_component *component = tas5805m->component;
	int ret = 0;

	pr_info("tas5805m_config_dsp\n");
	printk(">>>>>> [%s:%d] tas5805m debug: tas5805m_config_dsp\n", __func__, __LINE__);

	/*added this sleep to avoid the read error during boot*/
	mdelay(2000);
	regcache_cache_only(tas5805m->regmap, false);

	// Initialize the DSP
	regcache_cache_bypass(tas5805m->regmap, true);
	regmap_write(tas5805m->regmap, TAS5805M_REG_RESET_CTRL,
		     TAS5805M_RST_CONTROL_REG | TAS5805M_RST_MOD);
	mdelay(5);
	regmap_write(tas5805m->regmap, TAS5805M_REG_DEVICE_CTRL_2,
		     TAS5805M_HI_Z);
	regcache_cache_bypass(tas5805m->regmap, true);

	// Write the device configuration
	pr_debug("tas5805m_config_dsp: regcache_sync\n");
	printk(">>>>>> [%s:%d] tas5805m debug: tas5805m_config_dsp: regcache_sync\n", __func__, __LINE__);
	regcache_mark_dirty(tas5805m->regmap);
	ret = regcache_sync(tas5805m->regmap);
	if (ret != 0) {
		dev_err(component->dev,
			"Failed to sync TAS5805M: %d\n",
			ret);
		printk(">>>>>> [%s:%d] tas5805m debug: Failed to sync TAS5805M: %d\n", __func__, __LINE__, ret);
	}
	else {
		snd_soc_component_write(component, TAS5805M_REG_DEVICE_CTRL_2,
					tas5805m->ctrl_state | tas5805m->mute);
		tas5805m->configured = true;
		printk(">>>>>> [%s:%d] tas5805m debug: tas5805m->configured = true, ret = %d\n", __func__, __LINE__, ret);
	}
}

static int tas5805m_parse_config(struct device *dev,
				 struct tas5805m_priv *tas5805m) {
	int i, j, len, ret;
	u32 reg, val, book = 0, page = 0;

	for (i = 0; i < ARRAY_SIZE(tas5805m_config_sequence); i++) {
		reg = tas5805m_config_sequence[i].reg;
		val = tas5805m_config_sequence[i].def;

		switch (reg) {
		case TAS5805M_REG_PAGE_SEL:
			page = val;
			break;
		case TAS5805M_REG_BOOK_SEL:
			book = val;
			break;
		case CFG_META_DELAY:
			pr_info("tas5805m_parse_config: %dms delay\n", val);
			mdelay(val);
			break;
		case CFG_META_BURST:
		case CFG_META_SWITCH:
			pr_debug("tas5805m_parse_config: Ignoring meta value %d\n", reg);
			break;
		default:
			len = (book == TAS5805M_BOOK_00) ? 1 : 4;
			//printk(">>>>>> [%s:%d] tas5805m debug: befor reg 0x%02X = val 0x%02X\n", __func__, __LINE__, reg, val);
			reg = TAS5805M_REG(len, book, page, reg);

			for (j = i + 1; j < i + len; j++) {
				val <<= 8;
				val |= tas5805m_config_sequence[j].def;
			}

			pr_debug("tas5805m_parse_config: %08x = %08x\n",
				  reg, val);

			printk(">>>>>> [%s:%d] tas5805m debug: regmap_write reg 0x%08X = val 0x%08X\n", __func__, __LINE__, reg, val);

			ret = regmap_write(tas5805m->regmap, reg, val);
			if (ret != 0)
				return ret;

			i += (len - 1);
			break;
		}
	}

	return 0;
}

static int tas5805m_i2c_probe(struct i2c_client *i2c)
{
	struct device *dev = &i2c->dev;
	struct regmap *regmap;
	struct regmap_config config = tas5805m_regmap;
	struct tas5805m_priv *tas5805m;
	int ret;

	regmap = devm_regmap_init(&i2c->dev, NULL, i2c, &config);
	if (IS_ERR(regmap)) {
		dev_err(dev, "Failed to initialize regmap: %d\n", ret);
		return PTR_ERR(regmap);
	}

	tas5805m = devm_kzalloc(dev, sizeof(struct tas5805m_priv), GFP_KERNEL);
	if (!tas5805m)
		return -ENOMEM;

	dev_set_drvdata(dev, tas5805m);
	tas5805m->regmap	= regmap;
	tas5805m->book		= 0xff;
	tas5805m->page		= 0xff;
	tas5805m->configured	= false;

	if (device_property_read_bool(dev, "tas5805m,96KHz")) {
		tas5805m_dai.playback.formats |= SNDRV_PCM_RATE_96000;
		tas5805m_dai.capture.formats  |= SNDRV_PCM_RATE_96000;
	}

	// Reset the TAS5805M
		printk(">>>>>> [%s:%d] tas5805m debug: Reset the TAS5805M\n", __func__, __LINE__);

		/*commented below sequence to avoid Asoc erros and avoid IC going deep sleep mode*/
	ret = regmap_write(regmap, TAS5805M_REG_DEVICE_CTRL_2, TAS5805M_HI_Z);
	/*ret |= regmap_write(regmap, TAS5805M_REG_RESET_CTRL,
			    TAS5805M_RST_CONTROL_REG | TAS5805M_RST_MOD);
	if (ret != 0) {
		dev_err(dev, "Failed to initialize TAS5805M: %d\n", ret);
		return ret;
	}*/

	//regcache_cache_only(tas5805m->regmap, true);

	printk(">>>>>> [%s:%d] tas5805m debug: Write the user configuration to cache\n", __func__, __LINE__);
	// Write the user configuration to cache
	ret = tas5805m_parse_config(dev, tas5805m);
	if (ret != 0) {
		dev_err(dev, "Failed to process TAS5805M config: %d\n", ret);
		return ret;
	}
	printk(">>>>>> [%s:%d] tas5805m debug: tas5805m_parse_config() success %d\n", __func__, __LINE__, ret);

	INIT_WORK(&tas5805m->config_dsp_work, tas5805m_config_dsp);

	ret = snd_soc_register_component(dev,
					&soc_component_tas5805m,
					&tas5805m_dai,
					1);
	if (ret != 0) {
		dev_err(dev, "Failed to register component: %d\n", ret);
		return ret;
	}
	printk(">>>>>> [%s:%d] tas5805m debug: tas5805m_probe success return 0\n", __func__, __LINE__);

	return 0;
}

static int tas5805m_remove(struct device *dev)
{
	snd_soc_unregister_component(dev);
	return 0;
}

static int tas5805m_i2c_remove(struct i2c_client *i2c)
{
	tas5805m_remove(&i2c->dev);
	return 0;
}

static const struct i2c_device_id tas5805m_i2c_id[] = {
	{ "tas5805m", },
	{ }
};
MODULE_DEVICE_TABLE(i2c, tas5805m_i2c_id);

#if IS_ENABLED(CONFIG_OF)
static const struct of_device_id tas5805m_of_match[] = {
	{ .compatible = "ti,tas5805m", },
	{ }
};
MODULE_DEVICE_TABLE(of, tas5805m_of_match);
#endif

static struct i2c_driver tas5805m_i2c_driver = {
	.probe_new	= tas5805m_i2c_probe,
	.remove		= tas5805m_i2c_remove,
	.id_table	= tas5805m_i2c_id,
	.driver		= {
		.name		= "tas5805m",
		.owner		= THIS_MODULE,
#if IS_ENABLED(CONFIG_OF)
		.of_match_table	= tas5805m_of_match,
#endif
	},
};

module_i2c_driver(tas5805m_i2c_driver);

MODULE_AUTHOR("Andy Liu <andy-liu@ti.com>");
MODULE_AUTHOR("Daniel Beer <daniel.beer@igorinstitute.com>");
MODULE_AUTHOR("Thomas Moore <tcm0116@gmail.com>");
MODULE_AUTHOR("Mustafa Homsi <mustafa.homsi@rivieh.com>");
MODULE_DESCRIPTION("TAS5805M Audio Amplifier Driver");
MODULE_LICENSE("GPL v2");
