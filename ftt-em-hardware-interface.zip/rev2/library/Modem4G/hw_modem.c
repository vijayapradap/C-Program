#define _GNU_SOURCE

#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>

#include "hw_modem.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"

#define MODEM_RST		3
#define PWRKEY_4G		6
#define PWR_EN_4G		7

#define SET_BIT(val, n)		(val |= (1 << n))
#define CLR_BIT(val, n)		(val &= ~(1 << n))

/** Macro for checking the result and print the log if failure */
#define DO_ERR_INT(result, func, line) \
	if (result != 0) { \
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s: %s @line : %ld\n", \
			func, stErrorMsg[result].cpErrorMsg, line); \
		goto exit ; \
	}

static stModemInfo_t stFieldInfo[] = {
	{ "iccid",						"+ICCID",										"AT+CICCID\r\n" },
	{ "ip-address",					"+CGPADDR",										"AT+CGPADDR\r\n" },
	{ "bandwidth-usage",			"EUTRAN",										"AT+CPSI?\r\n" },
	{ "device-identifier",          "modem.generic.device-identifier",              "-K" },
	{ "manufacturer",               "modem.generic.manufacturer",                   "-K" },
	{ "model",                      "modem.generic.model",                          "-K" },
	{ "revision",                   "modem.generic.revision",                       "-K" },
	{ "equipment-identifier",       "modem.generic.equipment-identifier",           "-K" },
	{ "power-state",                "modem.generic.power-state",                    "-K" },
	{ "access-technologies",        "modem.generic.access-technologies.value",      "-K" },
	{ "signal-quality",             "modem.generic.signal-quality.value",           "-K" },
	{ "imei",                       "modem.3gpp.imei",                              "-K" },
	{ "operator-code",              "modem.3gpp.operator-code",                     "-K" },
	{ "operator-name",              "modem.3gpp.operator-name",                     "-K" },
	{ "registration-state",         "modem.3gpp.registration-state",                "-K" },
	{ "packet-service-state",       "modem.3gpp.packet-service-state",              "-K" },
	{ "operator-mcc",               "modem.location.3gpp.mcc",                      "--location-get -K" },
	{ "operator-mnc",               "modem.location.3gpp.mnc",                      "--location-get -K" },
	{ "location-area-code",         "modem.location.3gpp.lac",                      "--location-get -K" },
	{ "tracking-area-code",         "modem.location.3gpp.tac",                      "--location-get -K" },
	{ "cell-id",                    "modem.location.3gpp.cid",                      "--location-get -K" },
	{ "apn-status",               	"modem.3gpp.profile-manager.list.value",  		"--3gpp-profile-manager-list -K" },
	{ "rx_bytes",                   "/sys/class/net/usb0/statistics/rx_bytes",      "" },
	{ "tx_bytes",                   "/sys/class/net/usb0/statistics/tx_bytes",      "" },
	{ "rx_packets",                 "/sys/class/net/usb0/statistics/rx_packets",    "" },
	{ "rx_bytes",                   "/sys/class/net/usb0/statistics/tx_packets",    "" },
	{ "speed",                      "/sys/class/net/usb0/speed",                    "" },
	{ "set-apn",               		"SetModem",										"%s --simple-connect=\"apn=%s\"" },
	{ "set-band",               	"SetModem",										"AT+CNMP=%d\r\n" },
	{ "$",                          NULL,                                           "" },
};

/** Structure is storing the error code and correcsponding error message */
stErrMsg_t stErrorMsg[] = {
	{ eReturn_ok,                   "OK" },
	{ eReturn_err_unknown,          "Unknown Error" },
	{ eReturn_err_oom,              "Out of Memory" },
	{ eReturn_err_oor,              "Out of Range" },
	{ eReturn_err_oob,              "Out of Buffer" },
	{ eReturn_err_arg,              "Invalid Argument" },
	{ eReturn_err_timeout,          "Error Timeout" },
	{ eReturn_err_open_file,        "Error Opening a File" },
	{ eReturn_err_create_thread,    "Error Creating a Thread" },
	{ eReturn_err_deny,             "Permission Denied" },
	{ eReturn_err_unsupport,        "Operation Unsupported" },
	{ eReturn_err_create_msgq,      "Creating a MsgQ Failed" },
	{ eReturn_err_msg_send,         "MsgQ Sending Failed" },
	{ eReturn_err_io,               "IO Error" },
};

stGnssData_t gstGnssData;

static int8_t HW_MODEM_fnI2cWrite(int32_t i32File, uint8_t u8Addr, uint8_t u8Value) {
	int8_t i8Ret = eReturn_ok;
	uint8_t u8Buffer[2];
	u8Buffer[0] = u8Addr;
	u8Buffer[1] = u8Value;
	if (write(i32File, u8Buffer, 2) != 2) {
		i8Ret = eReturn_err_io;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
exit:
	return i8Ret;
}

static int8_t HW_MODEM_fnI2cRead(int32_t i32File, uint8_t u8Addr, uint8_t *u8Output) {
	int8_t i8Ret = eReturn_ok;
	uint8_t u8Buffer;
	if (write(i32File, &u8Addr, 1) != 1) {
		i8Ret = eReturn_err_io;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	if (read(i32File, &u8Buffer, 1) != 1) {
		i8Ret = eReturn_err_io;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	*u8Output = u8Buffer;
exit:
	return i8Ret;
}

int8_t HW_MODEM_fnPowerOnModem(bool bEnable) {	// 1 turn-on, 0 turn-off

	int8_t i8Ret = eReturn_ok;
	int32_t i32File = open(I2C_DEVICE, O_RDWR);
	uint8_t u8Data = 0;

	if (i32File < 0) {
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}

	if (ioctl(i32File, I2C_SLAVE, I2C_ADDR) < 0) {
		i8Ret = eReturn_err_io;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}

	DO_ERR_INT((i8Ret = HW_MODEM_fnI2cRead(i32File, 0x02, &u8Data)), __func__, __LINE__);

	if (bEnable) {
		SET_BIT(u8Data, MODEM_RST);
		SET_BIT(u8Data, PWRKEY_4G);
		SET_BIT(u8Data, PWR_EN_4G);
	} else {
		CLR_BIT(u8Data, MODEM_RST);
		CLR_BIT(u8Data, PWRKEY_4G);
		CLR_BIT(u8Data, PWR_EN_4G);
	}

	DO_ERR_INT((i8Ret = HW_MODEM_fnI2cWrite(i32File, 0x06, 0x03)), __func__, __LINE__);
	DO_ERR_INT((i8Ret = HW_MODEM_fnI2cWrite(i32File, 0x02, u8Data)), __func__, __LINE__);
exit:
	close(i32File);
	return i8Ret;
}

static void displayGpsData(void) 
{
	const char *cpGnssParams[] = {
		"Fix Mode (2D/3D)",
		"GPS Satellite",
		"GLONASS Satellite",
		"BEIDOU Satellite",
		"Latitude (ddmm.mmmmmm)",
		"N/S Indicator",
		"Longitude (dddmm.mmmmmm)",
		"E/W Indicator",
		"Date (ddmmyy)",
		"UTC-time (hhmmss.s)",
		"MSL Altitude (meters)",
		"Speed (knots)",
		"Course (degrees)",
		"Position DOP",
		"Horizontal DOP",
		"Vertical DOP",
		"Time DOP"
	};

	printf("\n\n");
	for(int i=0; i<70; i++) printf("*");
	printf("\n%*s %*s - %*s\n", 5, "", -30, "Parameter", -45, "Response");
	for(int i=0; i<70; i++) printf("*");
	printf("\n");

	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[0], -55, gstGnssData.u8Mode);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[1], -55, gstGnssData.u8GpsSvs);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[2], -55, gstGnssData.u8GlonassSvs);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[3], -55, gstGnssData.u8BeidouSvs);
	printf("%*s %*s - %*f\n", 5, "", -30, cpGnssParams[4], -55, gstGnssData.dLat);
	printf("%*s %*s - %*c\n", 5, "", -30, cpGnssParams[5], -55, gstGnssData.cNs);
	printf("%*s %*s - %*f\n", 5, "", -30, cpGnssParams[6], -55, gstGnssData.dLong);
	printf("%*s %*s - %*c\n", 5, "", -30, cpGnssParams[7], -55, gstGnssData.cEw);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[8], -55, gstGnssData.u32Date);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[9], -55, gstGnssData.dUtc);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[10], -55, gstGnssData.dAlt);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[11], -55, gstGnssData.dSpeed);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[12], -55, gstGnssData.dCourse);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[13], -55, gstGnssData.dPdop);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[14], -55, gstGnssData.dHdop);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[15], -55, gstGnssData.dVdop);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[16], -55, gstGnssData.dTdop);
	
	for(int i=0; i<70; i++) printf("*");
	printf("\n");
}

static void zeroPadding(char *cpReponse)
{
	for(int i = 0; cpReponse[i] != '\0'; i++)
	{
		if(cpReponse[i] == ',')
		{
			if(cpReponse[i+1] == ',')
			{
				memmove(cpReponse + i + 2, cpReponse + i + 1, strlen(cpReponse) - i);
				cpReponse[i+1] = '0';
			}
		}
    }
}

static void HW_MODEM_fnParseGnssData(char *cpGpsRawBuff)
{
	char carrTemp[BUFF_SIZE];
	zeroPadding(cpGpsRawBuff);

	char *token = strtok(cpGpsRawBuff, ":");
	token = strtok(NULL, ",");
	gstGnssData.u8Mode = atoi(token);

	token = strtok(NULL, ",");
	gstGnssData.u8GpsSvs = atoi(token);

	token = strtok(NULL, ",");
	gstGnssData.u8GlonassSvs = atoi(token);

	token = strtok(NULL, ",");
	if (strlen(token) < 3) {
		gstGnssData.u8BeidouSvs = atoi(token);
		token = strtok(NULL, ",");
	}

	strcpy(carrTemp, token);
	gstGnssData.dLat = atof(carrTemp);
	gstGnssData.u8BeidouSvs = 0;

	token = strtok(NULL, ",");
	gstGnssData.cNs = token[0];

	token = strtok(NULL, ",");
	strcpy(carrTemp, token);
	gstGnssData.dLong = atof(carrTemp);

	token = strtok(NULL, ",");
	gstGnssData.cEw = token[0];

	token = strtok(NULL, ",");
	strcpy(carrTemp, token);
	gstGnssData.u32Date = atoi(carrTemp);
	sscanf(carrTemp, "%2hhd%2hhd%2hhd", &gstGnssData.stDate.u8Day,
		&gstGnssData.stDate.u8Month, &gstGnssData.stDate.u8Year);

	token = strtok(NULL, ",");
	strcpy(carrTemp, token);
	gstGnssData.dUtc = atof(carrTemp);
	sscanf(carrTemp, "%2hhd%2hhd%2hhd.%2hhd", &gstGnssData.stUtc.u8Hour,
		&gstGnssData.stUtc.u8Min, &gstGnssData.stUtc.u8Sec,
		&gstGnssData.stUtc.u8Msec);

	token = strtok(NULL, ",");
	gstGnssData.dAlt = atof(token);

	token = strtok(NULL, ",");
	gstGnssData.dSpeed = atof(token);
	token = strtok(NULL, ",");
	gstGnssData.dCourse = atof(token);
	token = strtok(NULL, ",");
	gstGnssData.dPdop = atof(token);
	token = strtok(NULL, ",");
	gstGnssData.dHdop = atof(token);
	token = strtok(NULL, ",");
	gstGnssData.dVdop = atof(token);
	token = strtok(NULL, ",");
	gstGnssData.dTdop = atof(token);
}

static int8_t set_interface_attribs(int32_t i32Fd, uint32_t u32Speed)
{
	struct termios tty;
	int8_t i8Ret = 0;

    if (tcgetattr(i32Fd, &tty) < 0)
	{
		i8Ret = eReturn_err_unknown;
		printf("Error from tcgetattr: %s\n", strerror(errno));
		DO_ERR_INT(i8Ret, __func__, __LINE__);
    }

	cfsetospeed(&tty, u32Speed);
	cfsetispeed(&tty, u32Speed);

	tty.c_cflag |= (CLOCAL | CREAD);    // ignore modem controls
	tty.c_cflag &= ~CSIZE;
	tty.c_cflag |= CS8;         // 8-bit characters
	tty.c_cflag &= ~PARENB;     // no parity bit
	tty.c_cflag &= ~CSTOPB;     // only need 1 stop bit
	tty.c_cflag &= ~CRTSCTS;    // no hardware flowcontrol

	// setup for non-canonical mode
	tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
	tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
	tty.c_oflag &= ~OPOST;

	// fetch bytes as they become available
	tty.c_cc[VMIN] = 0;
	tty.c_cc[VTIME] = 5;

	if (tcsetattr(i32Fd, TCSANOW, &tty) != 0)
	{
		i8Ret = eReturn_err_unknown;
		printf("Error from tcsetattr: %s\n", strerror(errno));
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
exit:
	return i8Ret;
}

static size_t write_serial(int32_t i32Fd, const char *cpWriteBuf, size_t u32Len)
{
	ssize_t u32Wlen = write(i32Fd, cpWriteBuf, u32Len);
	if (u32Wlen != u32Len) {
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : Error From Write @line : %ld\n", \
			__func__, __LINE__);
		return u32Wlen;
	}
	tcdrain(i32Fd);    // delay for output
	return 0;
}

static ssize_t read_serial(int32_t i32Fd, char *cpReadBuf, size_t u32MaxLen)
{
	ssize_t u32Rlen = read(i32Fd, cpReadBuf, u32MaxLen);
	if (u32Rlen < 0) {
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : Error From Read @line : %ld\n", \
			__func__, __LINE__);
	} else if (u32Rlen == 0) {
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : Read nothing @line : %ld\n", \
			__func__, __LINE__);
	} else {
		cpReadBuf[u32Rlen] = '\0';  // null terminate
	}
	return u32Rlen;
}

static int8_t HW_MODEM_fnModemResponse(int32_t i32Fd, char *cpAtCmd, char *cpResponse)
{
	int8_t i8Ret = write_serial(i32Fd, cpAtCmd, strlen(cpAtCmd));
	if (i8Ret == 0)
	{
		char carrReadBuf[BUFF_SIZE];
		ssize_t u32Len = read_serial(i32Fd, carrReadBuf, sizeof(carrReadBuf) - 1);
		if (u32Len > 0)
		{
			strcpy(cpResponse, carrReadBuf);
			return 0;
		}
		else if (u32Len == 0)
		{
			return -2;
		}
		else
		{
			MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : " \
				"Serial read failed while reading GPS @line : %ld\n", \
				__func__, __LINE__);
			return -3;
		}
	}
	MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : " \
		"Serial write failed while reading GPS @line : %ld\n", \
		__func__, __LINE__);
	return -1;
}

static char *rmStrip(char *cpArgv, uint8_t u8Argl)
{
	uint8_t u8Len = 0;
	while (u8Len < u8Argl)
	{
		if ((cpArgv[u8Len] == '\r') || (cpArgv[u8Len] == '\n'))
		{
			cpArgv[u8Len] = '\0';
		}
		u8Len++;
	}
	return cpArgv;
}

static int32_t SerialInit(void)
{
	FILE *filePtr;
	char carrBuffer[4][20], cPort = 0;
	int32_t i32Fd;

	filePtr = popen("ls /dev/ttyUSB*", "r");
	if (filePtr == NULL)
	{
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : " \
			"Failed to run command @line : %ld\n", \
			__func__, __LINE__);
		return -1;
	}

	while (fgets(carrBuffer[cPort], sizeof(carrBuffer[cPort]), filePtr) != NULL)
	{
		strcpy(carrBuffer[cPort], rmStrip(carrBuffer[cPort], strlen(carrBuffer[cPort])));
		cPort++;
	}
	
	cPort = 1;
	pclose(filePtr);

START:
	i32Fd = open(carrBuffer[cPort], O_RDWR | O_NOCTTY | O_SYNC);
	if (i32Fd < 0)
	{
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : %s @line : %ld\n", \
			stErrorMsg[eReturn_err_open_file].cpErrorMsg, \
			__func__, __LINE__);
		if (cPort < 2)
		{
			cPort++;
			sleep(1);
			goto START;
		}
        return -1;
    }
	/*baudrate 115200, 8 bits, no parity, 1 stop bit */
	return (set_interface_attribs(i32Fd, B115200) != 0) ? -1 : i32Fd;
}

int8_t HW_MODEM_fnEnableInternet(void)
{
	char *cpCommands[] = { "AT\r\n", "AT+DIALMODE=0\r\n", \
		"AT$MYCONFIG=\"usbnetmode\",1\r\n" };
	char carrResponse[BUFF_SIZE];

	int32_t i32Fd = 0;
	int8_t i8Ret = 0;
	
	i32Fd = SerialInit();
	if (i32Fd < 0)
	{
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	} 
	
	for(uint8_t u8I = 0; u8I < 3; u8I++)
	{
		i8Ret = HW_MODEM_fnModemResponse(i32Fd, cpCommands[u8I], carrResponse);
		if (i8Ret < 0)
		{
			i8Ret = eReturn_err_unknown;
			DO_ERR_INT(i8Ret, __func__, __LINE__);
		}
		memset(carrResponse, 0, strlen(carrResponse));
		sleep(4);
	}

	printf("Enabled the internet successfully\n");
exit:
	close(i32Fd);
	return i8Ret;
}

int8_t HW_MODEM_fnPowerOnGps(void)
{
	char *cpGpsCmds[] = { "AT+CVAUXS=1\r\n", \
		"AT+CGNSSPWR=1\r\n", "AT+CGNSSINFO=10\r\n" };
	char carrResponse[BUFF_SIZE];
	
	int32_t i32Fd = 0;
	int8_t i8Ret = 0;
	
	i32Fd = SerialInit();
	if (i32Fd < 0)
	{
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	} 

	for(uint8_t u8I = 0; u8I < 3; u8I++)
	{
		i8Ret = HW_MODEM_fnModemResponse(i32Fd, cpGpsCmds[u8I], carrResponse);
		if (i8Ret < 0)
		{
			i8Ret = eReturn_err_unknown;
			DO_ERR_INT(i8Ret, __func__, __LINE__);
		}
		memset(carrResponse, 0, strlen(carrResponse));
		sleep(4);
	}
	printf("GPS successfully Power-On\n");
exit:
	close(i32Fd);
	return i8Ret;
}

static int8_t HW_MODEM_fnGetGPSLoc(void)
{
	char *cpGnssCmd = "AT+CGNSSINFO\r\n";
	char carrResponse[BUFF_SIZE];
	
	int32_t i32Fd = 0;
	int8_t i8Ret = 0;
	
	i32Fd = SerialInit();
	if (i32Fd < 0)
	{
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	} 

	i8Ret = HW_MODEM_fnModemResponse(i32Fd, cpGnssCmd, carrResponse);
	if (i8Ret < 0)
	{
		i8Ret = eReturn_err_unknown;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}

	if ( !strstr(carrResponse,",,,,,,,,") && (strlen(carrResponse) > 30) )
	{
		HW_MODEM_fnParseGnssData(carrResponse);
		// displayGpsData();
		// printf("\nhttps://www.google.com/maps/search/?api=1&query=%f%c,%f%c\n\n",
		// 	gstGnssData.dLat, gstGnssData.cNs, gstGnssData.dLong, gstGnssData.cEw);
	}
	else if ( strstr(carrResponse, "ERROR") )
	{
		i8Ret = eReturn_err_io;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	else
	{
		i8Ret = 1;
	}
exit:
	close(i32Fd);
	return i8Ret;
} 

int8_t HW_MODEM_fnGetLatLongData(char *cpLatLongitude)
{
	if (HW_MODEM_fnGetGPSLoc() != 0)
	{
		return -1;
	}

	sprintf(cpLatLongitude, "%f%c,%f%c", gstGnssData.dLat,
		gstGnssData.cNs, gstGnssData.dLong, gstGnssData.cEw);
	return strlen(cpLatLongitude);
}

int8_t HW_MODEM_fnModemRestart(void)
{
	int8_t i8Ret = 0;
	DO_ERR_INT((i8Ret = HW_MODEM_fnPowerOnModem(false)), __func__, __LINE__);	
	sleep(2);
	DO_ERR_INT((i8Ret = HW_MODEM_fnPowerOnModem(true)), __func__, __LINE__);	
	printf("modem rebooted successfully\n");
exit:
	return i8Ret;
}

static int8_t HW_MODEM_fnGetSetAtCmd(uint8_t u8Pos, char *cpOutputInfo) 
{
	char carrResponse[BUFF_SIZE];
	char *cpParseRes = NULL, *cpToken = NULL;
	
	int32_t i32Fd = 0;
	int8_t i8Ret = 0, i8Data = 0;

	i32Fd = SerialInit();
	if (i32Fd < 0)
	{
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	} 

	if (u8Pos > 2)
	{
		if (!strcmp(cpOutputInfo, "AUTO"))
			i8Data = 2;
		else if (!strcmp(cpOutputInfo, "GSM"))
			i8Data = 13;
		else if (!strcmp(cpOutputInfo, "WCDMA"))
			i8Data = 14;
		else if (!strcmp(cpOutputInfo, "LTE"))
			i8Data = 38;
		else
		{
			i8Ret = eReturn_err_arg;
			DO_ERR_INT(i8Ret, __func__, __LINE__);
		}

		asprintf(&cpParseRes, stFieldInfo[u8Pos].cpCmd, i8Data);
	}
	else
	{
		asprintf(&cpParseRes, "%s", stFieldInfo[u8Pos].cpCmd);
	}

	if (cpParseRes == NULL)
	{
		i8Ret = eReturn_err_oom;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	
	i8Ret = HW_MODEM_fnModemResponse(i32Fd, cpParseRes, carrResponse);
	if (i8Ret < 0)
	{
		free(cpParseRes);
		i8Ret = eReturn_err_unknown;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	free(cpParseRes);

	if (strstr(carrResponse, "ERROR"))
	{
		i8Ret = eReturn_err_unknown;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	else if (u8Pos > 2)
	{
		printf("output response : %s\n", carrResponse);
		goto exit;
	}
	else
	{
		zeroPadding(carrResponse);
		cpParseRes = strstr(carrResponse, stFieldInfo[u8Pos].cpKey);
		rmStrip(cpParseRes, strlen(cpParseRes));

		switch(u8Pos)
		{
			case 0:
				cpToken = strtok(cpParseRes, " ");
				cpToken = strtok(NULL, " ");
				strcpy(cpOutputInfo, cpToken);
				break;
			case 1:
				cpToken = strtok(cpParseRes, ",");
				cpToken = strtok(NULL, ",");
				strcpy(cpOutputInfo, cpToken);
				break;
			case 2:
				cpToken = strtok(cpParseRes, ",");
				strcpy(cpOutputInfo, cpToken);
				break;
		}
	}
exit:
	close(i32Fd);
	return i8Ret;
}

static int8_t getModemIndex(void)
{
	char carrBuffer[BUFF_SIZE];
	int8_t i8ModemId = -1;
	FILE *filePtr = NULL;
	
	filePtr = popen("mmcli -L", "r");
	if (filePtr == NULL) {
		MLOG_fnOutput(LOG_ERR, "LOG_ERR @func : %s : " \
			"Failed to run command @line : %ld\n", \
			__func__, __LINE__);
		return -1;
	}

	while (fgets(carrBuffer, sizeof(carrBuffer), filePtr) != NULL)
	{
		char *cpTmp = strstr(carrBuffer, M_INDEXPATH);
		if (cpTmp != NULL)
		{
			sscanf(cpTmp, "Modem/%hhd", &i8ModemId);
			if (0 > i8ModemId)
			{
				printf("modemId : %d\n%s\n", i8ModemId, carrBuffer);
			}
		}
	}
	pclose(filePtr);
	return i8ModemId;
}

int8_t HW_MODEM_fnSetGetModemInfo(char *cpInfoKey, char *cpOutputInfo)
{
	char carrBuffer[BUFF_SIZE], *cpSysCmd = NULL;
	int8_t i8I, i8Flag = 0, i8ModemId = -1;
	FILE *filePtr = NULL;

	for(i8I = 0; stFieldInfo[i8I].cpName != "$"; i8I++)
	{
		if (!strcmp(cpInfoKey, stFieldInfo[i8I].cpName))
		{
			if (strstr(stFieldInfo[i8I].cpKey, "modem."))
			{
				if (0 > (i8ModemId = getModemIndex()))
				{
					return i8ModemId;
				}
				asprintf(&cpSysCmd, "mmcli -m %d %s", i8ModemId, stFieldInfo[i8I].cpCmd);
				i8Flag = 1;
			}
			else if(strstr(stFieldInfo[i8I].cpCmd, "AT+"))
			{
				return HW_MODEM_fnGetSetAtCmd(i8I, cpOutputInfo);
			}
			else if(strstr(stFieldInfo[i8I].cpKey, "SetModem"))
			{
				if (cpOutputInfo == NULL || 0 > (i8ModemId = getModemIndex()))
				{
					return i8ModemId;
				}

				sprintf(carrBuffer, "mmcli -m %d ", i8ModemId);
				asprintf(&cpSysCmd, stFieldInfo[i8I].cpCmd, carrBuffer, cpOutputInfo);
				i8Flag = 2;
			}
			else
			{
				asprintf(&cpSysCmd, "cat %s", stFieldInfo[i8I].cpKey);
			}
			break;
        }
    }

	if (cpSysCmd == NULL)
	{
		printf("%s : command not found\n", cpInfoKey);
		return -1;
	}

	filePtr = popen(cpSysCmd, "r");
	if (filePtr == NULL)
	{
		free(cpSysCmd);
		printf("Failed to run command\n" );
		return -1;
    }
    free(cpSysCmd);

	while (fgets(carrBuffer, sizeof(carrBuffer), filePtr) != NULL)
	{
		carrBuffer[strlen(carrBuffer)-1] = '\0';
		if (i8Flag && strstr(carrBuffer, stFieldInfo[i8I].cpKey))
		{	
			cpSysCmd = strstr(carrBuffer, "apn");
			if (cpSysCmd != NULL)
			{
				char *cpTm = strtok(cpSysCmd, ",");
				strcpy(carrBuffer, cpTm);
			}

			char *cpToken = strtok(carrBuffer, ":");
			cpToken = strtok(NULL, ": ");
			strcpy(cpOutputInfo, cpToken);
			cpToken = strtok(NULL, ",,");
			
			if (cpToken != NULL)
			{
				strcat(cpOutputInfo, " ");
				strcat(cpOutputInfo, cpToken);
			}
        }
		else if (!i8Flag)
		{
			strncpy(cpOutputInfo, carrBuffer, 50);
		}
		memset(carrBuffer, 0, sizeof(carrBuffer));
    }
	pclose(filePtr);
	return 0;
}

int8_t HW_MODEM_fnGetGPSData(stGnssData_t *stGnssTemp)
{
	if (HW_MODEM_fnGetGPSLoc() != 0)
	{
		return -1;
	}

	*stGnssTemp = gstGnssData;
	return 0;
}

#if 0
int main(void) {

	if (HW_MODEM_fnPowerOnGps() != 0) return -1;
        sleep(5);

        int ret = 0, check = 0, timeout = 500;

        while(!check && timeout > 0) {

                ret = HW_MODEM_fnGetGPSLoc();
                if (ret < 0) {
                        check = 2;
                } else if (ret == 0) {
                       check = 1;
                       displayGpsData();
                }
                sleep(3);
                timeout--;
        }

        (check == 1) ? printf("GPS Location fixed\n") : (check == 2) ? printf("Error GPS\n") : printf("GPS not fixed timeout closed\n");
exit:
        return 0;

}
#endif

#if 0
int main(int argc, char *argv[]) {

	char location[50];

	HW_MODEM_fnGetSetModemInfo("set-apn", "airtelgprs.com");
	HW_MODEM_fnGetSetModemInfo("set-band", "GSM");

	return 0;

	if (argc != 2) {
		printf("\nusage : sudo ./modem.out <1> or <0>\n" \
				"\n1 : Net and GPS" \
				"\n0 : GPS Only\n\n");
		return -1;
	}
	
	if (atoi(argv[1]) == 1) {

		if (HW_MODEM_fnModemRestart() != 0) return -1;
		sleep(20);
		
		if (HW_MODEM_fnEnableInternet() != 0) return -1;
		sleep(15);

		if (HW_MODEM_fnPowerOnGps() != 0) return -1;
		sleep(5);

	} else {

		//if (HW_MODEM_fnPowerOnGps() != 0) return -1;
		//sleep(5);
	}

	printf("\nInitialization successful\n\n");


	if (HW_MODEM_fnGetLatLongData(location) > 0) {
		printf("\noutput : %s\n", location);
		displayGpsData();
	} else {
		printf("failed to get GPS location\n");
	}

	printf("\nmodem get informations\n\n");

	for (int i = 0; stFieldInfo[i].cpName != "$"; i++) {
                if (HW_MODEM_fnGetSetModemInfo(stFieldInfo[i].cpName, location) == 0) {
                        printf("%*s %*s - %*s\n", 5, "", -30, stFieldInfo[i].cpName, -55, location);
                } else {
                        printf("failed to get the information\n");
			break;
                }
		memset(location, 0, sizeof(location));
        }
#if 0

	if (HW_MODEM_fnGetModemInfo("imei", location) == 0) {
                printf("\n%s \t: %s\n\n", "imei", location);
        } else {
                printf("failed to get the information\n");
        }

	int ret = 0, check = 0, timeout = 20;

	while(!check && timeout > 0) {

		ret = HW_MODEM_fnGetGPSLoc();
		if (ret < 0) {
			check = 2;
		} else if (ret == 0) {
		       check = 1;
		       displayGpsData();
		}	       
		sleep(2);
		timeout--;
	}

	(check == 1) ? printf("GPS Location fixed\n") : (check == 2) ? printf("Error GPS\n") : printf("GPS not fixed timeout closed\n");
#endif

        return 0;
}
#endif
