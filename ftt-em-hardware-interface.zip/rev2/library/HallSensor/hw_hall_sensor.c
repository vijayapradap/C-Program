/**
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      hw_hall_sensor.c
 * @brief     This hall sensor module count the motor's rpm
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/
#include <fcntl.h>

/*=============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Private Includes
==============================================================================*/
#include "hw_hall_sensor.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"

/*=============================================================================
                              Private Macros
==============================================================================*/
//#define DEVICE_NAME "/dev/hall_sensor_driver"

/*==============================================================================
                              External/Public Variables
==============================================================================*/
int32_t gi32FilePointer = 0;

/*==============================================================================
                              Static Variables
==============================================================================*/
/** Structure is storing the error code and correcsponding error message */
static stErrMsg_t stErrorMsg[] = {
        { eReturn_ok,                   "OK" },
        { eReturn_err_unknown,          "Unknown Error" },
        { eReturn_err_oom,              "Out of Memory" },
        { eReturn_err_oor,              "Out of Range" },
        { eReturn_err_oob,              "Out of Buffer" },
        { eReturn_err_arg,              "Invalid Argument" },
        { eReturn_err_timeout,          "Error Timeout" },
        { eReturn_err_open_file,        "Error Opening a File" },
        { eReturn_err_create_thread,    "Error Creating a Thread" },
        { eReturn_err_deny,             "Permission Denied" },
        { eReturn_err_unsupport,        "Operation Unsupported" },
        { eReturn_err_create_msgq,      "Creating a MsgQ Failed" },
        { eReturn_err_msg_send,         "MsgQ Sending Failed" },
        { eReturn_err_io,               "IO Error" },
};

/*==============================================================================
                              Static Functions
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/
/** Macro for checking the result and print the log if failure */
#define DO_ERR_INT(result, func, line) \
        if (result != 0) { \
                MLOG_fnOutput(LOG_ERR, "LOG_ERR: %s: %s at line %ld\n", \
                                func, stErrorMsg[result].cpErrorMsg, line); \
                goto exit ;}

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

/*!
 * @brief		This function initialize the hall sensor
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval 0 		Success
 * @retval -1		Failure
 */
int8_t HW_HALLSENSOR_fnInit(int8_t *i8_pUartPort) 
{

	uint8_t i8Ret = 0;

	gi32FilePointer = open(i8_pUartPort, O_RDONLY);
	if(gi32FilePointer < 0) {
		i8Ret = eReturn_err_open_file;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
exit:
	return i8Ret;
}

/*!
 * @brief		This function deinitialize the hall sensor
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 * @retval EINVAL	NA
 */
void HW_HALLSENSOR_fnDeinit(void) {
	close(gi32FilePointer);
}

/*!
 * @brief		This function read the value from hall sensor
 *
 * @param[in]		No argument
 * @param[out]		NA
 *
 * @retval EOK 		NA
 */
int8_t HW_HALLSENSOR_fnRead(void) {
	int8_t i8Ret = 0;
	char cGpioStatus;
	if (read(gi32FilePointer, &cGpioStatus, sizeof(char)) == -1) {
		i8Ret = eReturn_err_io;
		DO_ERR_INT(i8Ret, __func__, __LINE__);
	}
	i8Ret = (cGpioStatus - 0x30);
	MLOG_fnOutput(LOG_INFO, "LOG_INFO: %s @ %ld: executed successfully\n", __func__, __LINE__);
exit:
	return i8Ret;
}

#if 0
int main(void) {

	HW_HALLSENSOR_fnInit();

	int count = 0;
	while(1) {

		if (HW_HALLSENSOR_fnRead() == 1) {
			count++;
			printf("count : %d\n", count);
		}
		if (count > 120)
			break;
	}

	HW_HALLSENSOR_fnDeinit();

	return 0;
}
#endif

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd. *********END OF FILE****/
