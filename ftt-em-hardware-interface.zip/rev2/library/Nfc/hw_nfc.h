/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      nfc.h
 * @brief     This is the header file for nfc controller to communication with
 *            nfc tag
 ******************************************************************************/

#ifndef _NFC_H_
#define _NFC_H_

/*==============================================================================
                              System Includes
==============================================================================*/

#include <stdint.h>


/*==============================================================================
                              functions prototypes
==============================================================================*/

/*!
@brief		<b>Initialize the nfc controller. </b>
@param[in]	i8_pPath - path  
@param[out]	None
@retval EOK: if initialization successful.
@retval errno: initialization failed.
*/
int32_t HW_NFC_fnInit(int8_t *i8_pPath);
/*!
@brief		<b>function to send commands to the nfc controller. </b>
@param[in]	pBuff - commands  
@param[in]	buffLen -  length of commands
@param[out]	None
@retval EOK: if sent successful.
@retval errno: if failed to send.
*/
int32_t HW_NFC_fnSend(char *pBuff, int32_t buffLen);
/*!
@brief		<b>function to receive from the nfc controller. </b>
@param[in]	pBuff - to store result  
@param[in]	buffLen -  length of of buffer
@param[out]	None
@retval EOK: if read successful.
@retval errno: if failed to read.
*/
int32_t HW_NFC_fnReceive(char *pBuff, int32_t buffLen);
/*!
@brief		<b>function to receive from the nfc controller. </b>
@param[in]	pRx - buffer to store result 
@param[in]	pTx - buffer to send commands
@param[in]	TxLen -  length of of buffer
@param[in]	RxLen -  length of of buffer
@param[out]	None
@retval EOK: if read successful.
@retval errno: if failed to read.
*/
int32_t HW_NFC_fnTransceive(char *pTx, int32_t TxLen, char *pRx, int32_t RxLen);
/*!
@brief		<b>function to close he nfc controller. </b>
@param[in]	None
@param[out]	None
@retval None
*/
void HW_NFC_fnClose();
/*!
@brief		<b>function to close he nfc controller. </b>
@param[in]	None
@param[out]	None
@retval None
*/
void HW_NFC_fnReset();

#endif 


/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/