/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      nfc.c
 * @brief     This is the source file for nfc controller to communication with
 *            nfc tag
 ******************************************************************************

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <stdint.h>

/*==============================================================================
                              private Includes
==============================================================================*/
#include "hw_nfc.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
#include "../inc/hw_interface_liberrors.h"


/*==============================================================================
                              global variable
==============================================================================*/
int32_t i32_nfcFd;

/*==============================================================================
                              static function 
==============================================================================*/
static int32_t reset_controller();

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
int32_t HW_NFC_fnInit(int8_t *i8_pPath)
{
    i32_nfcFd = 0;
    i32_nfcFd = open(i8_pPath , O_RDWR);
    if(-1 == i32_nfcFd)
    {
        MLOG_fnOutput(LOG_DEBUG,"HW_NFC_fnInit(): failed to open path for NFC Controller error == %d" , i32_nfcFd);
        return i32_nfcFd;
    }

    int32_t i32_nfcDetect = reset_controller(); 
    if(EOK != i32_nfcDetect) 
    {
        MLOG_fnOutput(LOG_DEBUG,"HW_NFC_fnInit(): failed to detect PN7160 NFC Controller error == %d" , i32_nfcDetect);
        return i32_nfcDetect;
    }

    return EOK;
}

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
static int32_t reset_controller()
{
    char NCICoreReset[] = {0x20, 0x00, 0x01, 0x01};
    char NCICoreInit2_0[] = {0x20, 0x01, 0x02, 0x00, 0x00};
    char Answer[256];
    int NbBytes = 0;
   
    HW_NFC_fnReset();
    HW_NFC_fnTransceive(NCICoreReset, sizeof(NCICoreReset), Answer, sizeof(Answer));

    /* Catch potential notification */
    usleep(100*1000);
    NbBytes = HW_NFC_fnReceive(Answer, sizeof(Answer));

    HW_NFC_fnTransceive(NCICoreReset, sizeof(NCICoreReset), Answer, sizeof(Answer));

    /* Catch potential notification */
    usleep(100*1000);
    NbBytes = HW_NFC_fnReceive(Answer, sizeof(Answer));

    if((NbBytes == 12) && (Answer[0] == 0x60) && (Answer[1] == 0x00) && (Answer[3] == 0x02))
    {
	    NbBytes = HW_NFC_fnTransceive(NCICoreInit2_0, sizeof(NCICoreInit2_0), Answer, sizeof(Answer));
        if((NbBytes < 19) || (Answer[0] != 0x40) || (Answer[1] != 0x01) || (Answer[3] != 0x00))    
        {
            MLOG_fnOutput(LOG_DEBUG,"reset_controller() : Error communicating with NFC Controller error == %d" , EFAILURE);
            return EFAILURE;
        }
    }
    
    return EOK;
}

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
int32_t HW_NFC_fnSend(char *pBuff, int32_t buffLen)
{
    int32_t i32_ReturnValue  = write(i32_nfcFd, pBuff, buffLen);
    if(0 >=i32_ReturnValue) 
    {
        /* retry to i32_nfcFd standby mode */
        i32_ReturnValue = write(i32_nfcFd, pBuff, buffLen);
        if(0 >=i32_ReturnValue) return 0;
    }
    return i32_ReturnValue;
}

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
int32_t HW_NFC_fnReceive(char *pBuff, int32_t buffLen)
{

    int32_t i32_ReturnSize;
    struct timeval tv;
    fd_set rfds;
    int32_t i32_ReturnValue;

    FD_ZERO(&rfds);
    FD_SET(i32_nfcFd, &rfds);
    tv.tv_sec = 2;
    tv.tv_usec = 1;
    i32_ReturnValue = select(i32_nfcFd+1, &rfds, NULL, NULL, &tv);
    if(i32_ReturnValue <= 0) return 0;

    i32_ReturnValue = read(i32_nfcFd, pBuff, 3);
    if (i32_ReturnValue <= 0) return 0;
    i32_ReturnSize = 3;
    if(pBuff[2] + 3 > buffLen) return 0;

    i32_ReturnValue = read(i32_nfcFd, &pBuff[3], pBuff[2]);
    if (i32_ReturnValue <= 0) return 0;
    i32_ReturnSize += i32_ReturnValue;

    return i32_ReturnSize;

}

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
int32_t HW_NFC_fnTransceive(char *pTx, int32_t TxLen, char *pRx, int32_t RxLen)
{
    if(HW_NFC_fnSend(pTx, TxLen) == 0) return 0;
    return HW_NFC_fnReceive(pRx, RxLen);
}

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
void HW_NFC_fnClose()
{
    if(i32_nfcFd) close(i32_nfcFd);
}

/*==============================================================================
                            see header for function prototype 
==============================================================================*/
void HW_NFC_fnReset()
{
    ioctl(i32_nfcFd, _IOW(0xE9, 0x01, long), 0);
    usleep(10 * 1000);
    ioctl(i32_nfcFd, _IOW(0xE9, 0x01, long), 1);
    usleep(10 * 1000);
}

/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/
