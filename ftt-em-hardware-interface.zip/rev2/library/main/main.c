#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include <signal.h>

// Include headers for different modules
#include "../mmWave_radar/hw_mmWave_radar.h"
#include "../OdorSensor/hw_odor_sensor.h"
#include "../Led/hw_fill_light.h"
#include "../Barcode/hw_barcode_scanner.h"
#include "../Modem4G/hw_modem.h"
#include "../HallSensor/hw_hall_sensor.h"
#include "../Ds18b20/hw_ds18b20_sensor.h"
#include "../PowerControlBoard/hw_power_supply_board.h"
#include "../MotorDriver/hw_motor_controller.h"
#include "../HwReadConfig/hw_read_config.h"
#include "../BrightnessCtl/hw_brightness_control.h"
#include "../HardwareVersion/hw_TLA2024.h"
#include "../Ntc/hw_ntcSensorMod.h"
#include "../Nfc/hw_nfc.h"

// Define module constants
#define EXIT 0
#define MODULE_RADAR 1
#define MODULE_ODOR 2
#define MODULE_FILL_LIGHT 3
#define MODULE_BARCODE 4
#define MODULE_MODEM 5
#define MODULE_HALL_SENSOR 6
#define MODULE_DS18B20 7
#define MODULE_MOTOR 8
#define MODULE_CAMARA 9
#define MODULE_BACKLIGHT 10
#define MODULE_ADC 11
#define MODULE_NTC 12
#define MODULE_SPEAKER 13
#define MODULE_POWER_SUPPLY 14
#define NFC_TAG 15


#define LIGHT_ON 1
#define LIGHT_OFF 0

stGnssData_t gstGnssData;

void runRadarModule(st_HwModulesConfig_t* commonConfig;);
void runOdorModule(st_HwModulesConfig_t* commonConfig);
void runFillLightModule();
void runBarcodeModule(st_HwModulesConfig_t* commonConfig);
int32_t runModemModule();
void runHallSensorModule(st_HwModulesConfig_t* commonConfig);
void runDs18b20Module(st_HwModulesConfig_t* commonConfig);
void runMotorDriverModule(st_HwModulesConfig_t* commonConfig);
void runCamara();
void runBacklight();
void runAdc();
void runNtc(int channel);
void runNfc();
void runSpeakerTest();
int32_t runPowerSupplyModule(int arg , st_HwModulesConfig_t* commonConfig);
void psb_help();


void *ODOR_readThread(void *arg);
void *BARCODE_readThread(void *arg);
void *thread_func(void *arg);
static void Functional();


/** Macro for checking the result and print the log if failure */
#define DO_ERR_INT(result, func, line) \
        if (result != 0) { \
                MLOG_fnOutput(LOG_ERR, "LOG_ERR: %s: %s at line %ld\n", \
                                func, stErrorMsg[result].cpErrorMsg, line); \
                goto exit ;}

char sai8_MwopOvenStatuData[] = "{\
\"i32_HeatingState\":%d,\
\"i8_DoorState\":%d,\
\"f32_TotalVoltage\":%.2f,\
\"f32_FreqVoltage\":%.2f,\
\"f32_TotalCurrent\":%.2f,\
\"f32_FreCurrent\":%.2f,\
\"i32_TotalPower\":%d,\
\"i32_FrePower\":%d\
}";


bool timeoutFlag = false;

static void watchdog(int signum) {
    (void)signum;
    timeoutFlag = true;
}

typedef int32_t (*fnRegisterHallSensorCallback_t)(int8_t *data);/*callbac function for hallsensor count*/
fnRegisterHallSensorCallback_t fptr_fnHallsensorCallback = NULL;
int32_t fnRegisterHallSensorCallback(PSB_fnDoorStateCallback_t Cbfun);
int32_t fnUnregisterHallsensorCallback(void);

int32_t fnRegisterHallSensorCallback(fnRegisterHallSensorCallback_t fptr_fnCbFun)
{

    if (fptr_fnCbFun == NULL)
    {
        printf("LOG_ERR: fnRegisterHallSensorCallback: fptr_fnCbFun is NULL!\n");
        return HW_LIB_FAILURE;
    }

    fptr_fnHallsensorCallback = fptr_fnCbFun;

    printf("LOG_DEBUG: fnRegisterHallSensorCallback: callback function registered\n");
    printf("\n\n===========================================================================================================\n");
    return EOK;
}

int32_t fnUnregisterHallsensorCallback(void)
{
    fptr_fnHallsensorCallback = NULL;
    printf("LOG_DEBUG: PSB_fnUnregisterDoorStateCallback: callback function unregistered\n");
    printf("===========================================================================================================\n\n");
    return EOK;
}

static int32_t hall_sensor_countCb(int8_t *data)
{
    if ((NULL == data))
    {
        printf("hall_sensor_countCb: Invalid params!\n");
        return -1;
    }
    
    printf("hall_sensor_countCb: sensor count = %d, %s\n", atoi(data), atoi(data) ? "Hall sensor SUCCESS": "Hall sensor FAILURE");
    return 0;
}

static int32_t PSB_fbHandleDoorStateCb(int8_t *data)
{
    if ((NULL == data))
    {
        printf("PSB_fbHandleDoorStateCb: Invalid params!\n");
        return -1;
    }
    
    printf("PSB_fbHandleDoorStateCb: door state %d, door %s\n", atoi(data), atoi(data) ? "open" : "close");
    return 0;
}

static int32_t PSB_fnHandleFreqBoardExceptionCb(int8_t *data)
{
    if ((NULL == data))
    {
        printf("PSB_fnHandleFreqBoardExceptionCb: Invalid params!\n");
        return -1;
    }
    
    printf("PSB_fnHandleFreqBoardExceptionCb: exception data %s\n", data);
    return 0;
}


//modem

static void displayGpsData(void) 
{

	const char *cpGnssParams[] = {
		"Fix Mode (2D/3D)",
		"GPS Satellite",
		"GLONASS Satellite",
		"BEIDOU Satellite",
		"Latitude (ddmm.mmmmmm)",
		"N/S Indicator",
		"Longitude (dddmm.mmmmmm)",
		"E/W Indicator",
		"Date (ddmmyy)",
		"UTC-time (hhmmss.s)",
		"MSL Altitude (meters)",
		"Speed (knots)",
		"Course (degrees)",
		"Position DOP",
		"Horizontal DOP",
		"Vertical DOP",
		"Time DOP"
	};

	printf("\n\n");
	for(int i=0; i<70; i++) printf("*");
	printf("\n%*s %*s - %*s\n", 5, "", -30, "Parameter", -45, "Response");
	for(int i=0; i<70; i++) printf("*");
	printf("\n");

	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[0], -55, gstGnssData.u8Mode);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[1], -55, gstGnssData.u8GpsSvs);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[2], -55, gstGnssData.u8GlonassSvs);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[3], -55, gstGnssData.u8BeidouSvs);
	printf("%*s %*s - %*f\n", 5, "", -30, cpGnssParams[4], -55, gstGnssData.dLat);
	printf("%*s %*s - %*c\n", 5, "", -30, cpGnssParams[5], -55, gstGnssData.cNs);
	printf("%*s %*s - %*f\n", 5, "", -30, cpGnssParams[6], -55, gstGnssData.dLong);
	printf("%*s %*s - %*c\n", 5, "", -30, cpGnssParams[7], -55, gstGnssData.cEw);
	printf("%*s %*s - %*d\n", 5, "", -30, cpGnssParams[8], -55, gstGnssData.u32Date);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[9], -55, gstGnssData.dUtc);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[10], -55, gstGnssData.dAlt);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[11], -55, gstGnssData.dSpeed);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[12], -55, gstGnssData.dCourse);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[13], -55, gstGnssData.dPdop);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[14], -55, gstGnssData.dHdop);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[15], -55, gstGnssData.dVdop);
	printf("%*s %*s - %*.2f\n", 5, "", -30, cpGnssParams[16], -55, gstGnssData.dTdop);
	
	for(int i=0; i<70; i++) printf("*");
	printf("\n");
}


int main() 
{
    int32_t condition = 1;
    int32_t psb_select = 0;

    st_HwModulesConfig_t commonConfig;
    memset(&commonConfig , 0 , sizeof(commonConfig));
    int32_t i32_ReturnValue1 = HW_Interface_fnReadConfig(&commonConfig);

    if (i32_ReturnValue1 != 0) {
        printf("Error reading configuration: %d\n", i32_ReturnValue1);
    }

    while(condition)
    {
        
        int selectedModule;

        printf("\n=============================================================================\n");
        printf("Select module to run:\n");
        printf("0. Stop the test application\n");
        printf("1. Radar\n");
        printf("2. Odor Sensor\n");
        printf("3. Fill Light\n");
        printf("4. Barcode Scanner\n");
        printf("5. Modem4g\n");
        printf("6. Hall Sensor\n");
        printf("7. Ds18b20 Sensor\n");
        printf("8. Motor driver\n");
        printf("9. Camara Module\n");
        printf("10. Brightness Control\n");
        printf("11. adc\n");
        printf("12. ntc\n");
        printf("13. speaker\n");
        printf("14. Power supply board\n");
        printf("15. Nfc tag");
        printf("Enter your choice: ");
        printf("\n=============================================================================\n\n");
        scanf("%d", &selectedModule);

        switch (selectedModule) 
        {
            case EXIT:
                condition = 0;
                break;
            case MODULE_RADAR:
                runRadarModule(&commonConfig);
                break;
            case MODULE_ODOR:
                runOdorModule(&commonConfig);
                break;
            case MODULE_FILL_LIGHT:
                runFillLightModule(&commonConfig);
                break;
            case MODULE_BARCODE:
                runBarcodeModule(&commonConfig);
                break;
            case MODULE_MODEM:
                runModemModule();
                break;
            case MODULE_HALL_SENSOR:
                runHallSensorModule(&commonConfig);
                break;
            case MODULE_DS18B20:
                runDs18b20Module(&commonConfig);
                break;
            case MODULE_MOTOR:

                fnRegisterHallSensorCallback(hall_sensor_countCb);
                runMotorDriverModule(&commonConfig);
                fnUnregisterHallsensorCallback();           
                break;   
            case MODULE_CAMARA:
                runCamara();
                break;
            case MODULE_BACKLIGHT:
                int selectedScreen;
                printf("0. Stop the test application\n");
                printf("1. for 7 inch screen\n");
                printf("2. for 15 inch screen\n");
                printf("Enter your choice: ");
                scanf("%d", &selectedScreen);
            
                switch(selectedScreen)
                {
                    case 0:
                        break;
                    case 1:
                        HW_BrightnessCTRL_fnInit7Inch();
                        while(1)
                        {
                            int percent ;
                            printf("Enter percentage between 0 to 100:\n ");
                            scanf("%d",&percent);
                            if((percent < 0) || (percent > 100))
                            {
                                printf("please enter between 0 -100\n");
                            }
                            else
                            {
                                HW_BrightnessCTRL_fnControl7Inch(percent);
                            }
                        }
                        break;
                    case 2:
                        HW_BrightnessCTRL_fnInit15Inch();
                        while(1)
                        {
                            int percent ;
                            printf("Enter percentage between 0 to 100:\n ");
                            scanf("%d",&percent);
                            if((percent < 0) || (percent > 100))
                            {
                                printf("please enter between 0 -100\n");
                            }
                            else
                            {
                                HW_BrightnessCTRL_fnControl15Inch(percent);
                            }
                        }
                        break;
                    default:
                        printf("invalid value\n");
                        break;
                }
                break;

            case MODULE_ADC:
                runAdc();
                break;

            case MODULE_NTC:
		 HW_ADC_fnInit();
                runNtc(2);/*NTC 1 -> channel 2 in ADC*/
                runNtc(3);/*NTC 2 -> channel 3 in ADC*/
                break;
                
            case MODULE_SPEAKER:
                runSpeakerTest();
                break;

            case MODULE_POWER_SUPPLY:
                psb_help();
                scanf("%d", &psb_select);

                 runPowerSupplyModule(psb_select , &commonConfig);
                break;

            case NFC_TAG:
                runNfc();
                break;
            default:
                printf("Invalid choice\n");
                break;
        }

    }

    return 0;
}

// Function implementations

void runRadarModule(st_HwModulesConfig_t* commonConfig) 
{

    printf("console %d, buadrate %d, port %s\n", commonConfig->b_consolDebug,
            commonConfig->mmWave_radar.i32_baudrate, commonConfig->mmWave_radar.i8_uartPort);



    int serial_fd = HW_RADAR_fnInit(commonConfig->mmWave_radar.i8_uartPort ,\
     commonConfig->mmWave_radar.i32_baudrate);
    if (serial_fd == -1) 
    {
        fprintf(stderr, "Error initializing UART connection\n");
        return;
    }
    
    printf("Radar init done\n");
    
    float distance;
    int32_t i = 0;
    do
    {
        sleep(1);
        distance = HW_RADAR_fnReadData();
        printf("Distance is %f\n", distance);
        i++;
    }while (i < 10);
    
    HW_RADAR_fnCloseUart();
}

void runOdorModule(st_HwModulesConfig_t* commonConfig) 
{

    printf("console %d, buadrate %d, port %s\n", commonConfig->b_consolDebug,
            commonConfig->odor_sensor.i32_baudrate, commonConfig->odor_sensor.i8_uartPort);


    int32_t i32_InitReturnValue = HW_ODOR_fnInit(commonConfig->odor_sensor.i32_baudrate,\
     commonConfig->odor_sensor.i8_uartPort);

    if (i32_InitReturnValue != 0) 
    {
        printf("Odor sensor initialization failed %d\n", i32_InitReturnValue);
    } 
    else 
    {
        printf("Odor sensor initialization success\n");
    }
    
    pthread_t read_thread;
    pthread_create(&read_thread, NULL, ODOR_readThread, NULL);
    pthread_join(read_thread, NULL);

    HW_ODOR_fnClose();
    printf("UART closed\n");
}

void *ODOR_readThread(void *arg) 
{
    st_BurntSmellSensor_t st_ODOR_sensor;
    int32_t loop = 0;
    while (loop < 5) 
    {
        int ret = HW_ODOR_fnReadData(&st_ODOR_sensor);
        if (ret == 0) 
        {
            printf("Temperature: %u degree Celsius\n", st_ODOR_sensor.ui32_temperature);
            printf("Voltage 1: %u V\n", st_ODOR_sensor.ui32_Voltage1);
            printf("Voltage 2: %u V\n", st_ODOR_sensor.ui32_Voltage2);
            printf("Threshold Voltage1: %u V\n", st_ODOR_sensor.ui32_ThresholdValue1);
            printf("Threshold Voltage2: %u V\n", st_ODOR_sensor.ui32_ThresholdValue2);
            printf("GasType: %u\n", st_ODOR_sensor.ui8_GasType);
            printf("Pre-heating Signals: %u\n", st_ODOR_sensor.ui8_PreHeatingSignal);
            printf("Fault signal: %u\n", st_ODOR_sensor.ui8_FaultSignal);
            printf("Status signal: %u\n", st_ODOR_sensor.ui8_StatusSignal);
            printf("\n");
        }
        loop++;
    }
}

void runFillLightModule(st_HwModulesConfig_t* commonConfig)
{

    printf("console %d, path %s\n", commonConfig->b_consolDebug,
    commonConfig->fill_light.i8_path);

    int ret = HW_FILL_LIGHT_fnInit(commonConfig->fill_light.i8_path);
    if (ret == EOK) 
    {
        printf("LED init done\n");
    }

    ret = HW_FILL_LIGHT_fnTurnOn();
    if (ret == EOK) 
    {
        printf("LED is on\n");
    }
    sleep(5);

    ret = HW_FILL_LIGHT_fnTurnOff();
    if (ret == EOK) 
    {
        printf("LED is off\n");
    }
}

void runBarcodeModule(st_HwModulesConfig_t* commonConfig) 
{
    printf("console %d, buadrate %d, port %s\n", commonConfig->b_consolDebug,
            commonConfig->barcode_scanner.i32_baudrate, commonConfig->barcode_scanner.i8_uartPort);

    system("gpioset 2 0=1");
    sleep(1);
    int32_t i32_ReturnValue = HW_BARCODE_fnInit(commonConfig->barcode_scanner.i32_baudrate, \
    commonConfig->barcode_scanner.i8_uartPort);

    
    if (i32_ReturnValue == 0) 
    {
        printf("Barcode initialization completed\n"); 
    } 
    else 
    { 
        printf("Barcode initialization failed\n");
    }


    int32_t i32_LightOn = HW_BARCODE_fnLightOnOffState(LIGHT_ON);
    if (i32_LightOn == 0) 
    {
        printf("Light on command success\n"); 
    } 
    else 
    {
        printf("Light on command failed\n");
    } 

    sleep(1);

    int32_t i32_LightOff = HW_BARCODE_fnLightOnOffState(LIGHT_OFF); 
    if (i32_LightOff != 0) 
    {
        printf("Light off command failed\n");
    } 
    else 
    {
        printf("Light off command success\n");
    }

    pthread_t read_thread;
    pthread_create(&read_thread, NULL, BARCODE_readThread, NULL);
    pthread_join(read_thread, NULL);
}


void *BARCODE_readThread(void *arg) 
{
    char recv_buff[2048] = {0};
    int32_t rsize = 0;
    int32_t btotal = 0;
    int32_t isDataReceived = 1;
    while (isDataReceived) 
    {
        memset(recv_buff, 0, sizeof(recv_buff));
        do 
        {
            rsize = HW_BARCODE_fnReadData(&recv_buff[btotal], 128, 200);
            if (rsize > 0) 
            {
                btotal += rsize;
            }
        } while ((rsize > 0) && (btotal < 2048) && (recv_buff[btotal] != 0x0d));
        if (btotal > 0) 
        {
            recv_buff[btotal] = '\0';
            printf("Received data in main: %s\n", recv_buff);
            btotal = 0;
        }
    }
}

int32_t runModemModule()
{
    char *params[] = {"iccid", "ip-address", "bandwidth-usage", "device-identifier", "manufacturer", \
        "model", "revision", "equipment-identifier", "signal-quality", "imei", "operator-code", "operator-name", \
        "registration-state", "packet-service-state", "operator-mcc", "operator-mnc", "location-area-code", \
        "tracking-area-code", "cell-id", "apn-status", "rx_bytes", "tx_bytes", "rx_packets", "rx_bytes" };

    char location[255];

    for(int i=0; i<70; i++) printf("*");
    printf("\n%*s %*s - %*s\n", 5, "", -30, "Parameter", -45, "Response");
    for(int i=0; i<70; i++) printf("*");
    printf("\n");

    for (int i = 0; params[i] != NULL; i++) {
        if (HW_MODEM_fnSetGetModemInfo(params[i], location) == 0) {
            printf("%*s %*s - %*s\n", 5, "", -30, params[i], -55, location);
        } else {
            printf("failed to get the information\n");
            break;
        }
        memset(location, 0, sizeof(location));
    }

    printf("\n\n\ttrying to power-on gps waiting for GPS data\n");
    if(HW_MODEM_fnPowerOnGps() != 0) {
        printf("GPS power-on getting failed\n");
        return -1;
    }
    sleep(5);
    printf("\n\n\tGPS power-on successfully\n");

#if 0 // sample program to get all gps data using structure

    stGnssData_t stGnssData;
    if (HW_MODEM_fnGetGPSData(&stGnssData) == 0) {
            printf("output data : %f\n", stGnssData.dLat);
            printf("output data : %f\n", stGnssData.dLong);
    }
#endif

    if(HW_MODEM_fnGetLatLongData(location) > 0)
    {
        displayGpsData();
    }
    else
    {
        printf("failed to get gps location\n");
    }
}

void runHallSensorModule(st_HwModulesConfig_t* commonConfig)
{

    printf("console %d, path %s\n", commonConfig->b_consolDebug,
    commonConfig->hall_sensor.i8_path);


    HW_HALLSENSOR_fnInit(commonConfig->hall_sensor.i8_path);

    signal(SIGALRM, watchdog);
    alarm(5);

	int count = 0;
    timeoutFlag = false;
	while(timeoutFlag == false ) {

		if (HW_HALLSENSOR_fnRead() == 1) {
			count++;
			printf("count : %d\n", count);
		}
	}

    if (count == 0) {
        printf("\n\nmake sure motor is rotating or not\n");
        printf("If rotating hall sensor isn't working\n\n");
        if(NULL != fptr_fnHallsensorCallback)
        {
            int8_t i8_buffer[4] = {0};
            snprintf(i8_buffer, 4, "%d", count);
            printf("LOG_DEBUG: runHallSensorModule: i8_buffer%s\n", i8_buffer);
            fptr_fnHallsensorCallback(i8_buffer);
        }

    } else {
        printf("Hall sensor is working fine\n");
       if(NULL != fptr_fnHallsensorCallback)
        {
            int8_t i8_buffer[4] = {0};
            snprintf(i8_buffer, 4, "%d", count);
            printf("LOG_DEBUG: runHallSensorModule: i8_buffer%s\n", i8_buffer);
            fptr_fnHallsensorCallback(i8_buffer);
        }
    }

	HW_HALLSENSOR_fnDeinit();

}


void runDs18b20Module(st_HwModulesConfig_t* commonConfig)
{
    printf("console %d, path %s\n", commonConfig->b_consolDebug,
    commonConfig->ds18b20_sensor.i8_path);


    HW_DS18B20_fnInitSensor(commonConfig->ds18b20_sensor.i8_path); 
    int i;
    for(i=0;i<10;i++)
    {
    
        float result=0;
        HW_DS18B20_fnReadTempVal(&result);
        printf("temp value is : %lf \n",result);
    }
  
    HW_DS18B20_fnCloseSensor();
}


void *thread_func(void *arg)
{
    int32_t i32_ret = 0;
    while(1)
    {
        do
        {
            //i32_ret = PSB_fnReadPAEdata_1();
            if(0 == i32_ret)
            {
                printf("PSB_fnReadPAEdata: success i32_ret %d\n", i32_ret);
            }
            else
            {
                printf("PSB_fnReadPAEdata: failed i32_ret %d\n", i32_ret);
            }
            usleep(200);
        } while (i32_ret != 0);
   }
}



void runMotorDriverModule(st_HwModulesConfig_t* commonConfig)
{

    printf("console %d, path %s\n", commonConfig->b_consolDebug,
    commonConfig->motor.i8_path);

    if (HW_MOTOR_fnInit(commonConfig->motor.i8_path) != 0) {
        printf("motor init is failed\n");
    }

    if (HW_MOTOR_fnSetDirection() != 0) {
        printf("HW_MOTOR_fnSetDirection failed\n");
    }

    if (HW_MOTOR_fnSetSpeed(100) != 0) {
        printf("HW_MOTOR_fnSetSpeed failed\n");
    }
    if (HW_MOTOR_fnRun(eMotor_run) != 0) {
        printf("HW_MOTOR_fnRun failed\n");
    }
    printf("motor starting and hall sensor counting the rpm\n");

    runHallSensorModule(commonConfig);

    if (HW_MOTOR_fnSetSpeed(0) != 0) {
        printf("HW_MOTOR_fnSetSpeed failed\n");
    }

    if (HW_MOTOR_fnRun(eMotor_stop) != 0) {
        printf("HW_MOTOR_fnRun failed\n");
    }
    HW_MOTOR_fnDeInit();
}

void runCamara()
{
    system("export DISPLAY=:0.0");
    sleep(1);
    system("sudo pkexec env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY nautilus");
    system("sudo -u Onanouser ffplay /dev/video0");
   // system("sudo -u Onanouser cheese");
}

void runSpeakerTest()
{
    //system("sudo apt install libsox-fmt-all");
    //system("pactl list short sinks");
    system("pactl set-default-sink alsa_output.usb-BurrBrown_from_Texas_Instruments_USB_AUDIO_CODEC-00.iec958-stereo");
    sleep(3);
    system("play /home/Onanouser/Cup_Shadow.mp3");
}

void runNtc(int channel)
{
    int i = 0;
    while (i < 10)
    {
        int temp_val = HW_NTC_fnReadTempVal(channel);
        printf("temp_val of NTC%d = %d\n", channel, temp_val);
        sleep(2);
        i++;
    }
}

void runAdc()
{
    HW_ADC_fnInit();
    int32_t i32_hwVersion;
    i32_hwVersion = HW_ADC_fnReadHWVersion();
    printf("\n\nADC HW Version is %d\n\n\n",i32_hwVersion);
}


void psb_help()
{
    printf("\n<option> could be\n");
    printf("\t1 for reading all fan status\n");
    printf("\t2 for start all fans\n");
    printf("\t3 for stop all fans\n");
    printf("\t4 to statr magenetron fan\n");
    printf("\t5 to statr inverter fan\n");
    printf("\t6 to statr exhaust fan fan\n");
    printf("\t7 to start reading PAE data\n");
    printf("\t8 to Read Microwave status data\n");
    printf("\t9 to start heating\n");
    printf("\t10 to stop heating\n");
    printf("\t11 to start heating with fans on\n");
    printf("\t12 to stop heating with fans on\n");
    printf("\t13 to read software version\n");
}

int32_t runPowerSupplyModule(int arg , st_HwModulesConfig_t* commonConfig)
{
    unsigned int i = 0;
    uint16_t ui16_speed = 0x64;
    uint8_t ui8_FanStatus = 0;
    uint8_t PSB_ret = 0;
    FanSatatus_t st_FanStatus = {0};
    int8_t PSB_SetfanRet = 0;
    MWOP_HEATING_STATUS_t st_OvenStatus;
    int8_t i8_PAEstatusData[512] = {0};
    int32_t i32_DataLen = sizeof(i8_PAEstatusData) - 1;
    int8_t i8_SwVersion[5] = {0};

    if((arg < 0) && (arg > 13))
    {
        psb_help();
        return 0;
    }

    printf("console %d, buadrate %d, port %s\n", commonConfig->b_consolDebug,
            commonConfig->power_supply_board.i32_baudrate, commonConfig->power_supply_board.i8_uartPort);

    int32_t ret = PSB_fnUartInit(commonConfig->power_supply_board.i8_uartPort, \
                                commonConfig->power_supply_board.i32_baudrate, \
                                commonConfig->b_consolDebug);

    if(ret != 0)
    {
        printf("PSB_fnUartInit() failed\n");
        return -1;
    }
    else
    {
        printf("PSB_fnUartInit success\n");
    }

    i = arg;
    printf("\nEntered psb Option %d\n", i);

    switch(i)
    {
        case 1:
            PSB_SetfanRet = PSB_fnReadFanStatus(0x80, &st_FanStatus);
            printf("\nPSB_fnSetfanRet %d st_FanStatus.state = %d st_FanStatus.speed = %d \n",PSB_SetfanRet,  st_FanStatus.state, st_FanStatus.speed);
            PSB_SetfanRet = PSB_fnReadFanStatus(0x81, &st_FanStatus);
            printf("\nPSB_fnSetfanRet %d st_FanStatus.state = %d st_FanStatus.speed = %d \n",PSB_SetfanRet,  st_FanStatus.state, st_FanStatus.speed);

            PSB_SetfanRet = PSB_fnReadFanStatus(0x82, &st_FanStatus);
            printf("\nPSB_fnSetfanRet %d st_FanStatus.state = %d st_FanStatus.speed = %d \n",PSB_SetfanRet,  st_FanStatus.state, st_FanStatus.speed);
            break;
        case 2:
            PSB_SetfanRet = PSB_fnSetFan(0x80, 1, 100);
            printf("\nPSB_fnSetfanRet = %d\n", PSB_SetfanRet);
            //sleep(1);
            PSB_SetfanRet = PSB_fnSetFan(0x81, 1, 100);
            printf("\nPSB_fnSetfanRet = %d\n", PSB_SetfanRet);
            //sleep(1);
            PSB_SetfanRet = PSB_fnSetFan(0x82, 1, 100);
            printf("\nPSB_fnSetfanRet = %d\n", PSB_SetfanRet);
            break;
        case 3:
            PSB_fnSetFan(0x80, 0, 0);
            printf("\nPSB_fnSetfanRet = %d\n", PSB_SetfanRet);
            //sleep(1);
            PSB_fnSetFan(0x81, 0, 0);
            printf("\nPSB_fnSetfanRet = %d\n", PSB_SetfanRet);
            //sleep(1);
            PSB_fnSetFan(0x82, 0, 0);
            printf("\nPSB_fnSetfanRet = %d\n", PSB_SetfanRet);
            break;
        case 4:
            PSB_SetfanRet = PSB_fnReadFanStatus(0x80, &st_FanStatus);/*magnetron fan*/
            printf("\nPSB_fnSetfanRet %d st_FanStatus.state = %d st_FanStatus.speed = %d \n",PSB_SetfanRet,  st_FanStatus.state, st_FanStatus.speed);
            break;
        case 5:
            PSB_SetfanRet = PSB_fnReadFanStatus(0x81, &st_FanStatus);/*inverter fan*/
            printf("\nPSB_fnSetfanRet %d st_FanStatus.state = %d st_FanStatus.speed = %d \n",PSB_SetfanRet,  st_FanStatus.state, st_FanStatus.speed);
            break;
        case 6:
            PSB_SetfanRet = PSB_fnReadFanStatus(0x82, &st_FanStatus);
            printf("\nPSB_fnSetfanRet %d st_FanStatus.state = %d st_FanStatus.speed = %d \n",PSB_SetfanRet,  st_FanStatus.state, st_FanStatus.speed);
            break;
        case 7:
            printf("ready for reading\n");
            PSB_fnRegisterDoorStateCallback(PSB_fbHandleDoorStateCb);
            PSB_fnFreqBoardExceptionCallback_t(PSB_fnHandleFreqBoardExceptionCb);
            pthread_t thread_readPAEdata;
            //pthread_create(&thread_readPAEdata, NULL, thread_func, NULL);
            pthread_create(&thread_readPAEdata, NULL, PSB_fnReadPAEdata, NULL);

            pthread_join(thread_readPAEdata, NULL);
            
            sleep(4);
            /*unregister the data callback if needed*/
            PSB_fnUnregisterDoorStateCallback();
            PSB_fnUregisterFrequenceBoardExceptionCallback();

            break;
        case 8:
            memset(i8_PAEstatusData, 0, sizeof(i8_PAEstatusData));
            memset(&st_OvenStatus, 0, sizeof(MWOP_HEATING_STATUS_t));
            ret = PSB_fnReadOvenStatus(MWOP_FUNC_READ_STATUS, &st_OvenStatus);/*read micro wave oven status*/
            printf("ret of PSB_fnReadOvenStatus %d\n", ret);
            snprintf(i8_PAEstatusData, i32_DataLen, sai8_MwopOvenStatuData,
                (int32_t)st_OvenStatus.i32_HeatingState, (int32_t)st_OvenStatus.i8_DoorState,
                st_OvenStatus.f32_TotalVoltage, st_OvenStatus.f32_FreqVoltage,
                st_OvenStatus.f32_TotalCurrent, st_OvenStatus.f32_FreCurrent,
                st_OvenStatus.i32_TotalPower, st_OvenStatus.i32_FrePower);
            printf("\nPSB_fnReadOvenStatus: %s\n", i8_PAEstatusData);
           break;
        case 9:
            ret = PSB_fnStartHeating(1000);
            printf("ret of PSB_fnSetHeating %d\n", ret);
           break;
        case 10:
            ret = PSB_fnStopHeating();
            printf("ret of PSB_fnSetHeating %d\n", ret);
           break;
        case 11:
            ret = PSB_fnSetHeatingWithFans(eMWOP_HEATING_START,1000);
            printf("ret of PSB_fnSetHeatingWithFans %d\n", ret);
	  break;
        case 12:
            ret = PSB_fnSetHeatingWithFans(eMWOP_HEATING_STOP,0);
            printf("ret of PSB_fnSetHeatingWithFans %d\n", ret);
	  break;
        case 13:
            ret = PSB_fnReadSwVersion(i8_SwVersion);
            printf("ret of PSB_fnReadSwVersion %d, i8_SwVersion %s\n", ret, i8_SwVersion);
	    break;
            default:
            psb_help();
            break;
    }
}

void runNfc()
{

    int ret =  HW_NFC_fnInit("/dev/nxpnfc");

    if(0 == ret)
    {
        printf("nfc init done \n");
    }
    
    Functional();

}

static void Functional() 
{
    char NCIStartDiscovery[] = {0x21, 0x03, 0x09, 0x04, 0x00, 0x01, 0x01, 0x01, 0x02, 0x01, 0x06, 0x01};
    char NCIRestartDiscovery[] = {0x21, 0x06, 0x01, 0x03};
    char Answer[256];
    int size = 0;

    printf("Functional test mode, starting discovery loop ...\n");
    if (HW_NFC_fnTransceive(NCIStartDiscovery, sizeof(NCIStartDiscovery), Answer, sizeof(Answer)) == 0) 
    {
        printf("Failed to start discovery loop: No response\n");
        return;
    }
    if ((Answer[0] != 0x41) || (Answer[1] != 0x03) || (Answer[3] != 0x00)) 
    {
        printf("Cannot start discovery loop\n");
        return;
    }
    printf("NFC Controller is now in functional mode \n");

    while (1) 
    {
        do 
        {        
           size = HW_NFC_fnReceive(Answer, sizeof(Answer));
        } while ((Answer[0] != 0x61) || ((Answer[1] != 0x05) && (Answer[1] != 0x03)));

        for(int i = 0; i < size; i++) 
        {
          printf("%02X ", Answer[i]);
        }
        printf("\n");
        
        if (HW_NFC_fnTransceive(NCIRestartDiscovery, sizeof(NCIRestartDiscovery), Answer, sizeof(Answer)) == 0) 
        {
            printf("Failed to restart discovery loop\n");
        }
    }
}


//sudo apt install v4l-utils
//sudo apt install libsox-fmt-all
