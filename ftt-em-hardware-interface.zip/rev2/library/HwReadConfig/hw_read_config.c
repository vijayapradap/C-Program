/*
* @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
* All trademarks are owned or licensed by Eaden Technology Pte Ltd,
* its subsidiaries or affiliated companies.
*
******************************************************************************
*
* @file      hw_read_config.c
* @brief     This is the source file for reading configuration for all hardware interface
*******************************************************************************
*/

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <string.h>
#include <errno.h>

/*==============================================================================
                              Private Includes
==============================================================================*/
#include "hw_read_config.h"
#include "../json/cJSON.h"

#include "../inc/hw_interface_liberrors.h"

/*==============================================================================
                             macros
==============================================================================*/
#define CONFIG_READ_BUF_SIZE 4096
#define CONFIGFILE "/etc/EADEN/hw_lib/config/HwInterfaceConfig.json"

/*==============================================================================
                             local functions prototype
==============================================================================*/
/** this function is for parsing read configuration data for all hardware module */
static void parseModuleConfig(cJSON *moduleConfigJson, st_ModuleConfig_t *moduleConfig);

/*==============================================================================
                              functions Defination
==============================================================================*/


/*!
@brief		<b> reading configuration of data for all hardware module.</b>
@param[in]	 st_HwModulesConfig_t - pointer to structure
@param[out]	 None
@retval None
*/
int32_t HW_Interface_fnReadConfig(st_HwModulesConfig_t *HwModulesConfig)
{
    FILE *fp = fopen(CONFIGFILE, "r");
    if (NULL == fp)
    {
        return errno;
    }

    char buffer[CONFIG_READ_BUF_SIZE];
    size_t len = fread(buffer, 1, sizeof(buffer), fp);
    fclose(fp);

    if (!len)
    {
        return errno;
    }

    cJSON *json = cJSON_Parse(buffer);
    if (NULL == json)
    {
        return EFAILURE;
    }

    cJSON *moduleConfig;

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "odor_sensor");
    if (NULL != moduleConfig)
    {
       parseModuleConfig(moduleConfig, &(HwModulesConfig->odor_sensor));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "power_supply_board");
    if (NULL != moduleConfig)
    {
       parseModuleConfig(moduleConfig, &(HwModulesConfig->power_supply_board));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "barcode_scanner");
    if (NULL != moduleConfig)
    {
        parseModuleConfig(moduleConfig, &(HwModulesConfig->barcode_scanner));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "ds18b20_sensor");
    if (moduleConfig != NULL)
    {
        parseModuleConfig(moduleConfig, &(HwModulesConfig->ds18b20_sensor));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "motor");
    if (moduleConfig != NULL)
    {
        parseModuleConfig(moduleConfig, &(HwModulesConfig->motor));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "hall_sensor");
    if (moduleConfig != NULL)
    {
        parseModuleConfig(moduleConfig, &(HwModulesConfig->hall_sensor));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "mmWave_radar");

    if (NULL != moduleConfig)
    {
       parseModuleConfig(moduleConfig, &(HwModulesConfig->mmWave_radar));
    }

    moduleConfig = cJSON_GetObjectItemCaseSensitive(json, "fill_light");

    if (NULL != moduleConfig)
    {
       parseModuleConfig(moduleConfig, &(HwModulesConfig->fill_light));
    }

    cJSON *consoleDebug = cJSON_GetObjectItemCaseSensitive(json, "console_debug");
	if(NULL != consoleDebug)
    {
        HwModulesConfig->b_consolDebug = cJSON_IsTrue(consoleDebug);
    }

    /* Add more module configurations here as needed */

    cJSON_Delete(json);
    return 0;
}

/*!
@brief		<b> Initializes the barcode scanner.</b>
@param[in]	 None
@param[out]	 None
@retval None
*/
static void parseModuleConfig(cJSON *moduleConfigJson, st_ModuleConfig_t *moduleConfig)
{
    cJSON *uartPort = cJSON_GetObjectItemCaseSensitive(moduleConfigJson, "uart_port");
    if (cJSON_IsString(uartPort) && (NULL != uartPort->valuestring))
    {
        strncpy(moduleConfig->i8_uartPort, uartPort->valuestring, MAX_PORT_LENGTH);
        printf("LOG_DEBUG: %s: moduleConfig->i8_uartPort %s\n", __func__, moduleConfig->i8_uartPort);
    }

    cJSON *baudrate = cJSON_GetObjectItemCaseSensitive(moduleConfigJson, "baudrate");
    if (cJSON_IsNumber(baudrate))
    {
        moduleConfig->i32_baudrate = baudrate->valueint;
        printf("LOG_DEBUG: %s: moduleConfig->i32_baudrate %d\n", __func__, moduleConfig->i32_baudrate);
    }

    cJSON *consoleDebug = cJSON_GetObjectItemCaseSensitive(moduleConfigJson, "console_debug");
    if (cJSON_IsBool(consoleDebug))
    {
        moduleConfig->b_consolDebug = cJSON_IsTrue(consoleDebug);
         printf("LOG_DEBUG: %s: moduleConfig->b_consolDebug %d\n", __func__, moduleConfig->b_consolDebug);
   }


    cJSON *dev_file = cJSON_GetObjectItemCaseSensitive(moduleConfigJson, "dev_file");
    if (cJSON_IsString(dev_file) && (NULL != dev_file->valuestring))
    {
        strncpy(moduleConfig->i8_path, dev_file->valuestring, MAX_PORT_LENGTH);
        printf("LOG_DEBUG: %s: moduleConfig->i8_path %s\n", __func__, moduleConfig->i8_path);
    }
}
/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/
