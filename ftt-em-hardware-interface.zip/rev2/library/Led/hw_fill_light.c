// /**
//  *
//  * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
//  * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
//  * its subsidiaries or affiliated companies.
//  *
//  ******************************************************************************
//  * @file      fill_light.h
//  * @brief     This is the source file for controlling fill light with
//  *            main board

//  ******************************************************************************
//  */


// /*==============================================================================
// *         system includes
// ================================================================================*/
// #include <stdio.h>
// #include <stdlib.h>
// #include <stdint.h>

// /*==============================================================================
// *         Project includes
// ================================================================================*/
// #include "hw_fill_light.h"
// #include "../inc/hw_interface_liberrors.h"


// /*==============================================================================
// *         macros
// ================================================================================*/
// #define I2C_BUS_NUMBER 1
// #define I2C_CHIP_ADDRESS 0x20

// /*==============================================================================
//                             see header for function prtotype
// ==============================================================================*/
// int32_t HW_FILL_LIGHT_fninit()
// {
//     char command[50];
//     sprintf(command, "i2cset -y %d 0x%x 0x06 0xff", I2C_BUS_NUMBER, I2C_CHIP_ADDRESS);
//     int32_t i32_RetVal =  system(command);
//     if(0 != i32_RetVal)
//     {
//         return i32_RetVal;
//     }
//     return EOK;
// }

// /*==============================================================================
//                             see header for function prtotype
// ==============================================================================*/
// int32_t HW_FILL_LIGHT_fnTurnOn()
// {
//     char command[50];
//     sprintf(command, "i2cset -y %d 0x%x 0x02 0xfc", I2C_BUS_NUMBER, I2C_CHIP_ADDRESS);
//     int32_t i32_RetVal = system(command);
//     if(0 != i32_RetVal)
//     {
//         return i32_RetVal;
//     }
//     return EOK;

// }

// /*==============================================================================
//                             see header for function prtotype
// ==============================================================================*/
// int32_t HW_FILL_LIGHT_fnTurnOff()
// {

//     char command[50];
//     sprintf(command, "i2cset -y %d 0x%x 0x02 0xff", I2C_BUS_NUMBER, I2C_CHIP_ADDRESS);
//     int32_t i32_RetVal = system(command);
//     if(0 != i32_RetVal)
//     {
//         return i32_RetVal;
//     }
//     return EOK;

// }



// /************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/




/****************************       version 2   ********************************/

/**
 *
 * @copyright (c) 2024 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      fill_light.h
 * @brief     This is the source file for controlling fill light with
 *            main board

 ******************************************************************************
 */


/*==============================================================================
*         system includes
================================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>

/*==============================================================================
*         Project includes
================================================================================*/
#include "hw_fill_light.h"
#include "../msglog/mlog.h"
#include "../json/cJSON.h"
#include "../inc/hw_interface_liberrors.h"

/*==============================================================================
*         macros
================================================================================*/
#define I2C_CHIP_ADDRESS   0x20
#define CONFIG_REG 0x06
#define PORT0_REG 0x02

/*==============================================================================
*         globale variable
================================================================================*/
int32_t gi32_fileFd = 0;

/*==============================================================================
                            static function
==============================================================================*/
static int32_t HW_FILL_LIGHT_fn_I2C_Write(uint8_t reg, uint8_t value);
static int32_t HW_FILL_LIGHT_fn_I2C_Read(uint8_t reg, uint8_t *value);

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_FILL_LIGHT_fnInit(int8_t *i32_pI2C_Path)
{
   uint8_t current_value;

    if ((gi32_fileFd = open(i32_pI2C_Path, O_RDWR)) < 0)
    {
        return EFAILURE;
    }

    if (ioctl(gi32_fileFd, I2C_SLAVE, I2C_CHIP_ADDRESS) < 0)
    {
        MLOG_fnOutput(LOG_DEBUG, "HW_FILL_LIGHT_fn_I2C_Open(): Failed to acquire bus access ",
        "and/or talk to slave, error == %d", EFAILURE);
        close(gi32_fileFd);
        return EFAILURE;
    }

    if (HW_FILL_LIGHT_fn_I2C_Read(CONFIG_REG, &current_value) != EOK)
    {
        return EFAILURE;
    }

    return HW_FILL_LIGHT_fn_I2C_Write(CONFIG_REG, (current_value & 0xFC));
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_FILL_LIGHT_fnTurnOn() 
{
    uint8_t current_value;
    if (HW_FILL_LIGHT_fn_I2C_Read(PORT0_REG, &current_value) != EOK)
    {
        return EFAILURE;
    }

    return HW_FILL_LIGHT_fn_I2C_Write(PORT0_REG, (current_value & 0xFC));
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_FILL_LIGHT_fnTurnOff() 
{
    uint8_t current_value;
    if (HW_FILL_LIGHT_fn_I2C_Read(PORT0_REG, &current_value) != EOK)
    {
        return EFAILURE;
    }

    uint8_t new_value = (current_value |  0x03);
    return HW_FILL_LIGHT_fn_I2C_Write(PORT0_REG, new_value);
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
static int32_t HW_FILL_LIGHT_fn_I2C_Write(uint8_t reg, uint8_t value) 
{
    if (0 > gi32_fileFd)
    {
        return EFAILURE;
    }

    uint8_t buffer[2] = {reg, value};
    if (write(gi32_fileFd, buffer, 2) != 2)
    {
        MLOG_fnOutput(LOG_DEBUG, "HW_FILL_LIGHT_fn_I2C_Write(): Failed to write to the i2c bus",
        "error == %d", EFAILURE);
        return EFAILURE;
    }

    return EOK;
}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
static int32_t HW_FILL_LIGHT_fn_I2C_Read(uint8_t reg, uint8_t *value)
{
     if (0 > gi32_fileFd)
    {
        return EFAILURE;
    }

    if (write(gi32_fileFd, &reg, 1) != 1)
    {
        MLOG_fnOutput(LOG_DEBUG, "HW_FILL_LIGHT_fn_I2C_Read(): Failed to write to the i2c bus" ,
        "error == %d", EFAILURE);
        return EFAILURE;
    }

    if (read(gi32_fileFd, value, 1) != 1)
    {
         return EFAILURE;
    }

    return EOK;

}

/*==============================================================================
                            see header for function prtotype
==============================================================================*/
int32_t HW_FILL_LIGHT_fnClose()
{
  if(-1 != gi32_fileFd)
  {
    close(gi32_fileFd);
    gi32_fileFd = -1;
    return EOK;

  }
  return EFAILURE;

}


/************ (C) COPYRIGHT (c) 2024 Eaden Technology Pte Ltd *********END OF FILE****/
