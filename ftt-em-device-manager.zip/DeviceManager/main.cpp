/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      main.cpp
 * @brief     This is main.cpp file for DeviceManger module.
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/

/*=============================================================================
                              Project Includes
==============================================================================*/
#include "device_twin.h"
#include "device_manager.h"
#include "rest_api_call.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <atomic>

extern "C"
{
  #include "azure_iot_lib.h"
}
/*==============================================================================
                              Private Includes
==============================================================================*/

/*==============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/
IOTHUB_DEVICE_CLIENT_LL_HANDLE deviceClientHandle;
IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;
size_t messagesReceivedByInput1Queue_dw = 0;
//size_t messagesReceivedByInput1Queue = 0;
size_t msgReceivedByInput1Queue = 0;
bool is_published = false;
std::string g_deviceId;
std::string g_planNumber;
std::vector<std::thread> g_vecOfThreads;
bool isDeviceTypeCertRenewed = false;
std::string userBindId = "";
// Flag to stop the thread
std::atomic<bool> stopThread(false);
/*==============================================================================
                              Static Variables
==============================================================================*/
static const char* x509certificate;
static const char* x509privatekey;
/*==============================================================================
                              Static Functions 
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/
using json = nlohmann::json;
std::time_t timestamp = std::time(nullptr);
char gaReportedPropertiesAck[] = "{\
    \"route_message_id\": %d,\
    \"status\": %d,\
    \"timestamp\": %ld \
}";

/*!

@brief      Update and publish reported properties to the specified route.
@param[in]  reportedJson JSON string containing the reported properties.
@param[out] ackBuffer Buffer to store the acknowledgment message.
@param[in]  bufferLength Length of the acknowledgment buffer.
@param[in]  ackCode Acknowledgment code indicating the type of acknowledgment.
@param[in]  status Status code indicating the result of the operation.

@retval     None

*/
void runUpdateWeatherInfoApi() {
    while (!stopThread) {
        // Call updateWeatherInfo function
        bool result = updateWeatherInfo();
        if (result) {
            std::cout << "Weather info updated successfully." << std::endl;
        } else {
            std::cerr << "Failed to update weather info." << std::endl;
        }
        
        for( int i=0; i<5; i++ )
            ThreadAPI_Sleep(60000);
        // Sleep for 5 minutes
        // std::this_thread::sleep_for(std::chrono::minutes(5));

    }
}


/*!

@brief      Update and publish reported properties to the specified route.
@param[in]  reportedJson JSON string containing the reported properties.
@param[out] ackBuffer Buffer to store the acknowledgment message.
@param[in]  bufferLength Length of the acknowledgment buffer.
@param[in]  ackCode Acknowledgment code indicating the type of acknowledgment.
@param[in]  status Status code indicating the result of the operation.

@retval     None

*/
void DeviceTwin_fnUpdateReportedProperties(const char* reportedJson, char* ackBuffer, int bufferLength, int ackCode, int status) {
    
    IOTHUB_CLIENT_RESULT publishReportedPropStatus;

    snprintf(ackBuffer, bufferLength, gaReportedPropertiesAck, ackCode, status, timestamp);
    printf("Reported Property Ack to OTA: %s\n", ackBuffer);
    fflush(stdout);

    publishReportedPropStatus = AZURE_IOT_fnPublishMessageToRoute(iotHubModuleClientHandle, (const char*)ackBuffer, DEVICE_MANAGER_OUTPUT_ROUTE);
    if( IOTHUB_CLIENT_OK != publishReportedPropStatus)
    {
        printf("\nERROR: %d !! Failed to publish reported property Data !!\n", publishReportedPropStatus);
        fflush(stdout);
    }
    else
    {
        printf("\nSUCCESS: !! Succesfully published reported properties data !! \n");
        fflush(stdout);
    }
}

/*!

@brief      Updates the "user_binding_done" flag to false in the configuration file.
@details    Reads `device_settings.json`, sets "user_binding_done" to `false`, and writes the changes back. 
            Prints success or error messages to stdout.

@exception  std::exception If an error occurs during file I/O or JSON processing.

@retval     None.

*/
void updateUnbindingFlagInConfig()
{
    try
    {
        std::ifstream configFile(DPS_CONFIG_FILE_PATH);
        if (configFile.is_open())
        {
            json configData;
            configFile >> configData;
            configFile.close();
            configData["user_binding_done"] = false;

            std::ofstream configFileOut(DEVICE_SETTING_FILE_PATH);
            configFileOut << configData.dump(4);
            configFileOut.close();

            printf("Updated 'isDeviceTypeCertRenewed' to true in dps_config.json\n");
            fflush(stdout);
        }
        else
        {
            printf("Failed to open config file: %s\n",DEVICE_SETTING_FILE_PATH);
            fflush(stdout);
        }
    }
    catch (const std::exception& e)
    {
        printf("Error updating the config file: %s\n", e.what());
        fflush(stdout);
    }
}

/*!

@brief      Publishes the factory reset status message to the specified Azure IoT Hub route.
@param[in]  factoryReset  Reference to a JSON object containing the factory reset status details.

@retval     None. This function prints the success or failure of the message publication to stdout.

*/
void publishFactoryResetStatus(json& factoryReset) 
{
    std::string factoryResetString = factoryReset.dump();
    const char* factoryResetCString = factoryResetString.c_str();

    IOTHUB_CLIENT_RESULT publishStatus = AZURE_IOT_fnPublishMessageToRoute(iotHubModuleClientHandle, factoryResetCString, DEVICE_MANAGER_OUTPUT_ROUTE);
    
    if (IOTHUB_CLIENT_OK != publishStatus) 
    {
        printf("\nERROR: %d !! Failed to publish reported property Data !!\n", publishStatus);
        fflush(stdout);
    } 
    else 
    {
        printf("\nSUCCESS: !! Successfully published reported properties data !!\n%s\n", factoryResetCString);
        fflush(stdout);
    }
}

/*!

@brief      Executes a system command and updates the factory reset progress.
@details    Runs the specified system command, updates the `factoryReset` JSON object based on the 
            command's success or failure, and publishes the updated status. 
@param[in]  command  The system command to execute.
@param[in]  factoryReset  JSON object to store and update the progress status.
@param[in]  progressUpdate   Progress percentage to set upon successful command execution.

@retval     None. Progress and error messages are printed to stdout.

*/

void executeSystemCommand(const char* command, json& factoryReset, int progressUpdate) 
{
    int ret = system(command);
    if (ret == -1) 
    {
        factoryReset["progress"] = -1;
        printf("Error: Failed to execute system command.\n");
        fflush(stdout);
    } 
    else if (WIFEXITED(ret)) 
    {
        int statusCode = WEXITSTATUS(ret);
        if (statusCode == 0) {
            factoryReset["progress"] = progressUpdate;
            printf("Command executed successfully with %d%% completion.\n", progressUpdate);
        } 
        else 
        {
            factoryReset["progress"] = -1;
            printf("Error: Command executed but returned non-zero status: %d\n", statusCode);
        }
        fflush(stdout);
    } 
    else 
    {
        factoryReset["progress"] = -1;
        printf("Error: Command did not terminate normally.\n");
        fflush(stdout);
    }
    publishFactoryResetStatus(factoryReset);
}

/*!

@brief      Performs a factory reset by clearing configuration files, deleting Wi-Fi records, and updating the status.
@details    Executes commands to unbind user details, delete various files, and clear Wi-Fi records. 
            Updates and publishes the progress status.
@param      None

@retval     None. Progress and error messages are printed to stdout.

*/
int fReset = 0;
void DeviceTwin_fnFactoryReset() {

    /** Unbinding User details */
    json factoryReset = {
        {"route_message_id", MSG_ID_FACTORY_RESET_PROGRESS},
        {"progress", 0},
        {"timestamp", std::time(nullptr)}
    };

    ThreadAPI_Sleep(1000);

    switch (fReset)
    {
        case 0:
            factoryReset["progress"] = unbindUserDetails(userBindId) ? 15 : -1;
            if (factoryReset["progress"] == 15) {
                updateUnbindingFlagInConfig();
            }
            publishFactoryResetStatus(factoryReset);
            fReset++;
            break;
        case 1:
            executeSystemCommand("rm -f /etc/smart_oven/cooking_records/*", factoryReset, 30);
            fReset++;
            break;
        case 2:
            executeSystemCommand("rm -f /etc/smart_oven/log/*", factoryReset, 45);
            fReset++;
            break;
        case 3:
            executeSystemCommand("> /etc/smart_oven/config/user_config.json", factoryReset, 60);
            fReset++;
            break;
        case 4:
            executeSystemCommand("> /etc/smart_oven/config/user_agreement.json", factoryReset, 75);
            fReset++;
            break;
        case 5:
            executeSystemCommand("> /etc/smart_oven/config/privacy_policy.json", factoryReset, 90);
            fReset++;
            break;
        default:
            break;
    }
}


/*!

@brief      Execute device manager commands based on the received message body.
@param[in]  messageBody Pointer to the received message body as a byte array.

@retval     IOTHUB_CLIENT_RESULT Result of the command execution, either IOTHUB_CLIENT_OK or IOTHUB_CLIENT_ERROR.

*/
IOTHUB_CLIENT_RESULT DeviceManagerCmdExecuteFunction(const unsigned char* messageBody) {
    IOTHUB_CLIENT_RESULT publishStatus = IOTHUB_CLIENT_OK;
    char aReportedPropAckBuffer[REPORTED_PROP_BUFFER_LENGTH] = {0};
    int32_t i32_DataLen = sizeof(aReportedPropAckBuffer);

    JSON_Value* root_value = json_parse_string(reinterpret_cast<const char*>(messageBody));
    if (root_value == NULL) {
        printf("Failed to parse JSON\n");
        fflush(stdout);
        return IOTHUB_CLIENT_ERROR;
    }

    JSON_Object* root_object = json_value_get_object(root_value);
    if (root_object == NULL) {
        printf("Failed to get root object\n");
        fflush(stdout);
        json_value_free(root_value);
        return IOTHUB_CLIENT_ERROR;
    }

    int msgType = static_cast<int>(json_object_get_number(root_object, "route_message_id"));
    printf("Incoming msgType: %d \n", msgType);
    fflush(stdout);

    std::string otaUpdateString;
    const char* reportedJson = nullptr;
    char* ota_update_string = nullptr;
    char* new_ota_update_string = nullptr;
    JSON_Value* new_root_value = nullptr;
    JSON_Object* new_root_object = nullptr;

    try {
        if (!json_object_has_value(root_object, "ota_update")) 
        {
            printf("\"ota_update\" key not found\n");
            fflush(stdout);
        } 
        else 
        {
            JSON_Object* ota_update_object = json_object_get_object(root_object, "ota_update");
            if (ota_update_object == NULL) {
                printf("\"ota_update\" object not found\n");
                fflush(stdout);
                publishStatus = IOTHUB_CLIENT_ERROR;
            } else {

                json_object_set_string(ota_update_object, "device_id", g_deviceId.c_str());
                json_object_set_string(ota_update_object, "plan_number", g_planNumber.c_str());

                JSON_Value* ota_update_value = json_object_get_wrapping_value(ota_update_object);
                ota_update_string = json_serialize_to_string(ota_update_value);

                new_root_value = json_value_init_object();
                new_root_object = json_value_get_object(new_root_value);
                json_object_set_value(new_root_object, "ota_update", json_parse_string(ota_update_string));

                new_ota_update_string = json_serialize_to_string(new_root_value);

                otaUpdateString = std::string(new_ota_update_string);
                reportedJson = otaUpdateString.c_str();
                printf("Reported Properties Json : %s\n", reportedJson);
                fflush(stdout);
            }
        }

        if (publishStatus == IOTHUB_CLIENT_OK) {

            switch (msgType) {
                case MSG_ID_INVALID:
                    break;
                case MSG_ID_OTA_UPDATE_ACK:
                    // Handle OTA update acknowledgment
                    break;

                case MSG_ID_OTA_UPDATE_CONFIRMATION:
                    if (DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(reportedJson)) {
                        printf("Successfully reported properties updated!!!!\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_CONFIRMATION, 0);
                    } else {
                        printf("Failed to set reported properties\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_CONFIRMATION, 1);
                        publishStatus = IOTHUB_CLIENT_ERROR;
                    }
                    break;

                case MSG_ID_OTA_UPDATE_INPROGRESS:

                    ThreadAPI_Sleep(1000);
                    if ( json_object_dotget_number(root_object, "ota_update.progress") == 0 )
                        ThreadAPI_Sleep(2000);

                    if (DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(reportedJson)) {
                        printf("Successfully reported properties updated!!!!\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_INPROGRESS, 0);
                    } else {
                        printf("Failed to set reported properties\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_INPROGRESS, 1);
                        publishStatus = IOTHUB_CLIENT_ERROR;
                    }
                    break;

                case MSG_ID_OTA_UPDATE_SUCCESS:
                    if (DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(reportedJson)) {
                        printf("Successfully reported properties updated!!!!\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_SUCCESS, 0);
                    } else {
                        printf("Failed to set reported properties\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_SUCCESS, 1);
                        publishStatus = IOTHUB_CLIENT_ERROR;
                    }
                    break;

                case MSG_ID_OTA_UPDATE_FAILED:
                    if (DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(reportedJson)) {
                        printf("Successfully reported properties updated!!!!\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_FAILED, 0);
                    } else {
                        printf("Failed to set reported properties\n");
                        fflush(stdout);
                        DeviceTwin_fnUpdateReportedProperties(reportedJson, aReportedPropAckBuffer, i32_DataLen, ACK_CODE_OTA_UPDATE_FAILED, 1);
                        publishStatus = IOTHUB_CLIENT_ERROR;
                    }
                    break;
                case MSG_ID_FACTORY_RESET:
                    fReset = 0;
                case MSG_ID_FACTORY_RESET_ACK:
                    if (!strcmp(json_object_get_string(root_object, "command"), "factory_reset") || \
                            !strcmp(json_object_get_string(root_object, "command"), "progress_response"))
                        DeviceTwin_fnFactoryReset();
                    break;
                case 251:
                {
                    int bindstatus = static_cast<int>(json_object_get_number(root_object, "user_bind_status"));

                    if ( bindstatus == 4 )
                    {
                        json userBindingMsg;

                        bool usrResult = updateUserDetails(userBindId);

                        userBindingMsg["route_message_id"] = 250 ;
                        userBindingMsg["timestamp"] =  std::time(nullptr);

                        userBindingMsg["params"]["user_bind_status"]=(usrResult == true) ? 1 : 3 ;

                        std::string userBindingMsgStr = userBindingMsg.dump();
                        const char* userBindMsgCString = userBindingMsgStr.c_str();

                        printf("Bind status data  :: %s\n", userBindMsgCString);
                        fflush(stdout);

                        if (IOTHUB_CLIENT_OK != AZURE_IOT_fnPublishMessageToRoute(iotHubModuleClientHandle, userBindMsgCString, DEVICE_MANAGER_OUTPUT_ROUTE)) 
                        {
                            printf("\nERROR: !! Failed to publish reported property Data !!\n");
                            fflush(stdout);
                        } 
                        else 
                        {
                            printf("\nSUCCESS: !! Successfully published reported properties data !!\n");
                            fflush(stdout);
                        }

                        if ( updatePrivacyPolicy() != true)
                        {
                            printf("\nFailed to update the  updatePrivacyPolicy!!\n");
                            fflush(stdout);
                        }
                        if ( updateUserAgreement() != true)
                        {
                            printf("\nFailed to update the  updateUserAgreement!!\n");
                            fflush(stdout);
                        }
                        if ( updateUserBinding(usrResult) != true )
                        {
                            printf("\nFailed to update the  updateUserBinding!!\n");
                            fflush(stdout);
                        }
                    }
                }
                default:
                    printf("Unknown message type: \n");
                    fflush(stdout);
                    break;
            }
        }
    } 
    catch (const std::exception& e) 
    {
        printf("Exception occurred: %s\n", e.what());
        fflush(stdout);
        publishStatus = IOTHUB_CLIENT_ERROR;
    }

    if (new_ota_update_string != nullptr) 
    {
        json_free_serialized_string(new_ota_update_string);
    }
    json_value_free(root_value);
    json_value_free(new_root_value);

    return publishStatus;
}

/*!

@brief      Callback function to handle the confirmation result of a sent message.
@param[in]  result Result of the message send operation (IOTHUB_CLIENT_CONFIRMATION_RESULT).
@param[in]  userContextCallback Pointer to user-defined context, typically a MESSAGE_INSTANCE.

@retval     None

*/
static void SendConfirmationCallback(IOTHUB_CLIENT_CONFIRMATION_RESULT result, void *userContextCallback)
{
    MESSAGE_INSTANCE *messageInstance = (MESSAGE_INSTANCE *)userContextCallback;
    printf("Confirmation[%zu] received for message with result = %d\r\n\n", messageInstance->messageTrackingId, result);
    fflush(stdout);
    IoTHubMessage_Destroy(messageInstance->messageHandle);
    free(messageInstance);
}

/*!

@brief      Create and initialize a MESSAGE_INSTANCE from the given IoT Hub message handle.
@param[in]  message Handle to the IoT Hub message to be cloned.

@retval     Pointer to the created MESSAGE_INSTANCE, or NULL if allocation or cloning failed.

*/
static MESSAGE_INSTANCE *CreateMessageInstance(IOTHUB_MESSAGE_HANDLE message)
{
    MESSAGE_INSTANCE *messageInstance = (MESSAGE_INSTANCE *)malloc(sizeof(MESSAGE_INSTANCE));
    if (NULL == messageInstance)
    {
        printf("Failed allocating 'MESSAGE_INSTANCE' for pipelined message\r\n");
        fflush(stdout);
    }
    else
    {
        memset(messageInstance, 0, sizeof(*messageInstance));

        if ((messageInstance->messageHandle = IoTHubMessage_Clone(message)) == NULL)
        {
            free(messageInstance);
            messageInstance = NULL;
        }
        else
        {
            messageInstance->messageTrackingId = messagesReceivedByInput1Queue_dw;
        }
    }

    return messageInstance;
}

/*!

@brief      Callback function to handle incoming messages for the IoT Hub module.
@param[in]  message Handle to the received IoT Hub message.
@param[in]  userContextCallback Pointer to user-defined context, typically the IoT Hub module client handle.

@retval     IOTHUBMESSAGE_DISPOSITION_RESULT Result of message processing, either IOTHUBMESSAGE_ACCEPTED or IOTHUBMESSAGE_ABANDONED.

*/
static IOTHUBMESSAGE_DISPOSITION_RESULT InputQueue1Callback(IOTHUB_MESSAGE_HANDLE message, void *userContextCallback)
{
    IOTHUBMESSAGE_DISPOSITION_RESULT result;
    IOTHUB_CLIENT_RESULT clientResult;
    iotHubModuleClientHandle = (IOTHUB_MODULE_CLIENT_LL_HANDLE)userContextCallback;

    unsigned const char *messageBody;
    size_t contentSize;

    if (IoTHubMessage_GetByteArray(message, &messageBody, &contentSize) != IOTHUB_MESSAGE_OK)
    {
        // messageBody = "<null>";;
        ;
    }

    printf("Received Message [%zu]\r\n Data: [%s]\r\n",
           messagesReceivedByInput1Queue_dw, messageBody);
    fflush(stdout);

    clientResult = DeviceManagerCmdExecuteFunction(messageBody);

    if (clientResult != IOTHUB_CLIENT_OK)
    {
        // IoTHubMessage_Destroy(messageInstance->messageHandle);
        // free(messageInstance);
        printf("IoTHubModuleClient_LL_SendEventToOutputAsync failed on sending msg#=%zu, err=%d\n", messagesReceivedByInput1Queue_dw, clientResult);
        fflush(stdout);
        result = IOTHUBMESSAGE_ABANDONED;
    }
    else
    {
        result = IOTHUBMESSAGE_ACCEPTED;
    }

    messagesReceivedByInput1Queue_dw++;
    return result;
}

/*!

@brief      Handles certificate renewal based on the configuration file.
@details    If the device type certificate is renewed, updates `dps_config.json` and reports the status. 
            Resets relevant flags in the config file.
@param      None

@retval     None

*/

void updateCertRenewedFlagInConfig()
{
    try
    {
        std::ifstream configFile(DPS_CONFIG_FILE_PATH);
        if (configFile.is_open())
        {
            json configData;
            configFile >> configData;
            configFile.close();
            configData["isDeviceTypeCertRenewed"] = true;

            std::ofstream configFileOut(DPS_CONFIG_FILE_PATH);
            configFileOut << configData.dump(4);
            configFileOut.close();

            printf("Updated 'isDeviceTypeCertRenewed' to true in dps_config.json\n");
            fflush(stdout);
        }
        else
        {
            printf("Failed to open config file: %s\n", DPS_CONFIG_FILE_PATH);
            fflush(stdout);
        }
    }
    catch (const std::exception& e)
    {
        printf("Error updating the config file: %s\n", e.what());
        fflush(stdout);
    }
}

/*!

@brief      Process and handle updates to the device twin JSON.
@param[in]  deviceTwinJson JSON string representing the device twin.

@retval     None

*/
void DeviceTwin_fnProcessDeviceTwinUpdate(const std::string& deviceTwinJson) 
{
    json deviceTwin = nullptr;
    json otaUpdate = nullptr;
    json modifiedOtaUpdate = nullptr;

    try 
    {
        deviceTwin = json::parse(deviceTwinJson);

        if ((deviceTwin.contains("isDeviceTypeCertRenewed") && deviceTwin["isDeviceTypeCertRenewed"].is_boolean() && deviceTwin["isDeviceTypeCertRenewed"] == true) ||
            (deviceTwin.contains("desired") && deviceTwin["desired"].contains("isDeviceTypeCertRenewed") && deviceTwin["desired"]["isDeviceTypeCertRenewed"].is_boolean() && deviceTwin["desired"]["isDeviceTypeCertRenewed"] == true))
        {
            // update the file dps_config.json, isDeviceTypeCertRenewed = true;
            updateCertRenewedFlagInConfig();
            isDeviceTypeCertRenewed = true;
        }

        if(deviceTwin["desired"]["businessAttribute"].contains("adminBind") ||
           deviceTwin["businessAttribute"].contains("adminBind"))
        {
            printf("User Binding triggered.\n");

            int user_binding_triggered = 0;
            //std::string userBindId = "";

            if(deviceTwin["desired"]["businessAttribute"].contains("adminBind"))
            {
                user_binding_triggered = deviceTwin["desired"]["businessAttribute"]["adminBind"].get<int>();
                userBindId = deviceTwin["desired"]["businessAttribute"]["adminBindUserId"].get<std::string>();

            }
            else
            {
                user_binding_triggered = deviceTwin["businessAttribute"]["adminBind"].get<int>();
                userBindId = deviceTwin["businessAttribute"]["adminBindUserId"].get<std::string>();

            }
            if(user_binding_triggered == 1 )
            {
                json bindingStartedMsg;
                bindingStartedMsg["route_message_id"] = 250 ;
                bindingStartedMsg["timestamp"] =  std::time(nullptr);

                bindingStartedMsg["user_bind_status"]= 4 ;

                std::string bindingStartedMsgStr = bindingStartedMsg.dump();
                const char* bindingStartedMsgCString = bindingStartedMsgStr.c_str();

                IOTHUB_CLIENT_RESULT publishReportedBindingStartedMsgStatus;
                printf("Desired Property OTA Update :: %s\n", bindingStartedMsgCString);
                fflush(stdout);

                publishReportedBindingStartedMsgStatus = AZURE_IOT_fnPublishMessageToRoute(iotHubModuleClientHandle, bindingStartedMsgCString, DEVICE_MANAGER_OUTPUT_ROUTE);

                if (IOTHUB_CLIENT_OK != publishReportedBindingStartedMsgStatus) 
                {
                    printf("\nERROR: %d !! Failed to publish reported property Data !!\n", publishReportedBindingStartedMsgStatus);
                    fflush(stdout);
                } 
                else 
                {
                    printf("\nSUCCESS: !! Successfully published reported properties data !!\n");
                    fflush(stdout);
                }
            }
        }
        bool newUpdateAvailable = false;
        if (deviceTwin.contains("new_update_available")) 
        {
            if (deviceTwin["new_update_available"].is_boolean())
            {
                newUpdateAvailable = deviceTwin["new_update_available"].get<bool>();
            } 
            else 
            {
                printf("\"new_update_available\" is not a boolean & time is: %ld\n", std::time(nullptr));
                fflush(stdout);
                is_published = false;
                return;
            }
        } 
        else if (deviceTwin.contains("desired") && deviceTwin["desired"].contains("new_update_available")) 
        {
            newUpdateAvailable = deviceTwin["desired"]["new_update_available"].get<bool>();
        } 
        else 
        {
            printf("\"new_update_available\" property is not present & time is: %ld\n", std::time(nullptr));
            fflush(stdout);
            is_published = false;
            return;
        }

        if (newUpdateAvailable && !is_published) 
        {
            if (deviceTwin.contains("ota_update")) 
            {
                otaUpdate = deviceTwin["ota_update"];
                if (otaUpdate.contains("device_id") && otaUpdate["device_id"].is_string())
                {
                    g_deviceId = otaUpdate["device_id"];
                }
                else
                {
                    printf("Error: Missing or invalid 'device_id' in ota_update\n");
                    fflush(stdout);
                }
                if (otaUpdate.contains("plan_number") && otaUpdate["plan_number"].is_string())
                {
                    g_planNumber = otaUpdate["plan_number"];
                }
                else
                {
                    printf("Error: Missing or invalid 'plan_number' in ota_update\n");
                    fflush(stdout);
                }
            } 
            else if (deviceTwin.contains("desired") && deviceTwin["desired"].contains("ota_update")) 
            {
                otaUpdate = deviceTwin["desired"]["ota_update"];
                if (otaUpdate.contains("device_id") && otaUpdate["device_id"].is_string())
                {
                    g_deviceId = otaUpdate["device_id"];
                }
                else
                {
                    printf("Error: Missing or invalid 'device_id' in ota_update\n");
                    fflush(stdout);
                }
                if (otaUpdate.contains("plan_number") && otaUpdate["plan_number"].is_string())
                {
                    g_planNumber = otaUpdate["plan_number"];
                }
                else
                {
                    printf("Error: Missing or invalid 'plan_number' in ota_update\n");
                    fflush(stdout);
                }
            } 
            else 
            {
                printf("\"ota_update\" property is not present & time is: %ld\n", std::time(nullptr));
                fflush(stdout);
                return;
            }

            modifiedOtaUpdate = {
                {"route_message_id", MSG_ID_OTA_UPDATE_RECEIVED},
                {"ota_update", otaUpdate},
                {"timestamp", std::time(nullptr)}
            };
            std::string otaUpdateString = modifiedOtaUpdate.dump();
            const char* otaUpdateCString = otaUpdateString.c_str();

            IOTHUB_CLIENT_RESULT publishReportedPropStatus;
            printf("Desired Property OTA Update :: %s\n", otaUpdateCString);
            fflush(stdout);

            publishReportedPropStatus = AZURE_IOT_fnPublishMessageToRoute(iotHubModuleClientHandle, otaUpdateCString, DEVICE_MANAGER_OUTPUT_ROUTE);
            if (IOTHUB_CLIENT_OK != publishReportedPropStatus) 
            {
                printf("\nERROR: %d !! Failed to publish reported property Data !!\n", publishReportedPropStatus);
                fflush(stdout);
            } 
            else 
            {
                printf("\nSUCCESS: !! Successfully published reported properties data !!\n");
                fflush(stdout);
            }

            is_published = true;
        }
        else if (!newUpdateAvailable) 
        {
            is_published = false;
        }
        else 
        {
            printf("No new update available & time is: %ld\n", std::time(nullptr));
            fflush(stdout);
        }

    }
    catch (json::parse_error& e) 
    {
        printf("JSON parsing error: %s\n", e.what());
        fflush(stdout);
    } 
    catch (json::type_error& e) 
    {
        printf("JSON type error: %s\n", e.what());
        fflush(stdout);
    } 
    catch (std::exception& e) 
    {
        printf("Exception error: %s\n", e.what());
        fflush(stdout);
    }
}

/*!

@brief      Processes certificate renewal status based on configuration.
@details    If the device type certificate has been renewed, updates the configuration file and reports 
            the status. Resets relevant flags in the configuration file.
@param      None

@retval     None

*/

void readConfigAndHandleCertRenewal()
{
    if (isDeviceTypeCertRenewed)
    {
        try
        {
            std::ifstream configFile(DPS_CONFIG_FILE_PATH);
            if (configFile.is_open())
            {
                json configData;
                configFile >> configData;
                configFile.close();

                if (configData.contains("deviceCertRenewed") && configData["deviceCertRenewed"].is_boolean())
                {
                    bool deviceCertRenewed = configData["deviceCertRenewed"].get<bool>();

                    if (deviceCertRenewed)
                    {
                        json certRenewalReportedJson = {
                            {"deviceCertRenewed", true},
                            {"Device_ID", deviceId}};

                        const std::string certRenewalReportedJsonString = certRenewalReportedJson.dump();
                        DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(certRenewalReportedJsonString);
                        configData["deviceCertRenewed"] = false;
                        configData["isDeviceTypeCertRenewed"] = false;
                        std::ofstream configFileOut(DPS_CONFIG_FILE_PATH);
                        configFileOut << configData.dump(4);
                        configFileOut.close();

                        isDeviceTypeCertRenewed = false;
                    }
                }
            }
            else
            {
                printf("Failed to open config file: %s\n", DPS_CONFIG_FILE_PATH);
                fflush(stdout);
            }
        }
        catch (const std::exception& e)
        {
            printf("Error reading or updating the config file: %s\n", e.what());
            fflush(stdout);
        }
    }
}


/*!

@brief      Callback function for handling updates to the device twin.
@param[in]  updateState State of the device twin update.
@param[in]  payLoad Pointer to the payload containing the device twin update.
@param[in]  size Size of the payload.
@param[in]  userContextCallback User context (unused in this callback).

@retval     None

*/
void DeviceTwin_fnFetchDeviceTwinCallback(DEVICE_TWIN_UPDATE_STATE updateState, const unsigned char* payLoad, size_t size, void* userContextCallback) {
    (void)userContextCallback;
    std::string deviceTwinJson(reinterpret_cast<const char*>(payLoad), size);
    printf("Device Twin update received (state=%s, size=%zu): %s\r\n\n\n", MU_ENUM_TO_STRING(DEVICE_TWIN_UPDATE_STATE, updateState), size, payLoad);
    fflush(stdout);
    DeviceTwin_fnProcessDeviceTwinUpdate(deviceTwinJson);
}

/*!

@brief      Perform operations related to device twin management.
@param[in]  connectionString Connection string for the IoT Hub.
@param[in]  deviceConnectionString Connection string for the specific device.
@param[in]  deviceId ID of the device.

@retval     None

*/
void DeviceTwin_fnPerformDeviceTwinOperations()
{
    DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetInitialReportedProperties();

    if (deviceClientHandle != nullptr)
    {
        IoTHubDeviceClient_LL_SetDeviceTwinCallback(deviceClientHandle, DeviceTwin_fnFetchDeviceTwinCallback, nullptr);
    }
    else
    {
        printf("deviceClientHandle is null\n");
        fflush(stdout);
    }
}

/*!

@brief      Constructs the device connection string
@param[in]  iothub_name The name of the IoT Hub
@param[in]  device_id The ID of the device
@param[in]  key The shared access key for the device

@retval     std::string The constructed device connection string

*/
std::string DeviceTwin_fnConstructDeviceConnectionString(const std::string& iothub_host_name, const std::string& device_id)
{
    return "HostName=" + iothub_host_name + ";DeviceId=" + device_id + ";x509=true";
}

/*!

@brief      Initialize the IoT Hub module connection.
@param[in]  None

@retval     IOTHUB_MODULE_CLIENT_LL_HANDLE Handle to the IoT Hub module client, or NULL if initialization failed.

*/
static IOTHUB_MODULE_CLIENT_LL_HANDLE InitializeConnection()
{
    if ((iotHubModuleClientHandle = IoTHubModuleClient_LL_CreateFromEnvironment(MQTT_Protocol)) == NULL)
    {
        printf("ERROR: IoTHubModuleClient_LL_CreateFromEnvironment failed\r\n");
        fflush(stdout);
    }
    else
    {
        printf("SUCESS: IoTHubModuleClient_LL_CreateFromEnvironment created\r\n");
        fflush(stdout);
        // Uncomment the following lines to enable verbose logging.
        // bool traceOn = true;
        // IoTHubModuleClient_LL_SetOption(iotHubModuleClientHandle, OPTION_LOG_TRACE, &trace);
    }

    return iotHubModuleClientHandle;
}

/*!

@brief      Deinitialize the IoT Hub module connection, Device Handle and clean up resources.
@param[in]  None

@retval     None

*/
static void DeInitializeConnection()
{
    if (iotHubModuleClientHandle != NULL)
    {
        IoTHubModuleClient_LL_Destroy(iotHubModuleClientHandle);
    }

    if(deviceClientHandle != NULL)
    {
        IoTHubDeviceClient_LL_Destroy(deviceClientHandle);
    }
    
    IoTHub_Deinit();
}

/*!

@brief      Set up the input message callback for the IoT Hub module.
@param[in]  None

@retval     0 if the callback was set successfully, 1 otherwise.

*/
static int SetupCallbacksForModule()
{
    int ret;

    if (IoTHubModuleClient_LL_SetInputMessageCallback(iotHubModuleClientHandle, "device_manager_in", InputQueue1Callback, (void *)iotHubModuleClientHandle) != IOTHUB_CLIENT_OK)
    {
        printf("ERROR: IoTHubModuleClient_LL_SetInputMessageCallback(\"input1\")..........FAILED!\r\n");
        fflush(stdout);
        ret = 1;
    }
    else
    {
        printf("SUCCESS: IoTHubModuleClient_LL_SetInputMessageCallback(\"input1\")..........SUCCESS!\r\n");
        fflush(stdout);
        ret = 0;
    }

    return ret;
}

/*!

@brief      Initialize the IoT Hub module connection, set up callbacks, and enter a loop to process incoming messages.
@param[in]  None

@retval     None

*/
void iothub_module()
{
    printf("thread iothub_module initialized\n");
    fflush(stdout);
    srand((unsigned int)time(NULL));

    if ((iotHubModuleClientHandle = InitializeConnection()) != NULL && SetupCallbacksForModule() == 0)
    {
        // Main loop for handling incoming messages
        printf("Waiting for incoming messages.\r\n");
        fflush(stdout);
        while (true)
        {
            IoTHubModuleClient_LL_DoWork(iotHubModuleClientHandle);
            readConfigAndHandleCertRenewal();
            ThreadAPI_Sleep(100);
        }
    }

    DeInitializeConnection();
}

void create_deviceHandle()
{   
    x509certificate = DeviceManager::DeviceTwinHandler::read_certificate();
    
    x509privatekey = DeviceManager::DeviceTwinHandler::read_keys();

    std::string iotHubHostName = std::getenv("IOTEDGE_IOTHUBHOSTNAME");

    printf("IOTEDGE_IOTHUBHOSTNAME: %s\n", iotHubHostName.c_str());
    fflush(stdout);
    deviceConnectionString = DeviceTwin_fnConstructDeviceConnectionString(iotHubHostName, deviceId);
    printf("Device Connection String: %s\n", deviceConnectionString.c_str());
    fflush(stdout);

    deviceClientHandle = IoTHubDeviceClient_LL_CreateFromConnectionString(deviceConnectionString.c_str(), MQTT_Protocol);
    if (deviceClientHandle == NULL)
    {
        printf("Failure creating IotHub device. Hint: Check your connection string.\r\n");
        fflush(stdout);
    }
    else
    {
        bool urlEncodeOn = true;
        (void)IoTHubDeviceClient_LL_SetOption(deviceClientHandle, OPTION_AUTO_URL_ENCODE_DECODE, &urlEncodeOn);
        if ((IoTHubDeviceClient_LL_SetOption(deviceClientHandle, OPTION_X509_CERT, x509certificate) != IOTHUB_CLIENT_OK) ||
            (IoTHubDeviceClient_LL_SetOption(deviceClientHandle, OPTION_X509_PRIVATE_KEY, x509privatekey) != IOTHUB_CLIENT_OK))
        {
            printf("failure to set options for x509, aborting\r\n");
            fflush(stdout);
        }
        DeviceTwin_fnPerformDeviceTwinOperations();
    }
    
    while(true)
    {
        IoTHubDeviceClient_LL_DoWork(deviceClientHandle);
        ThreadAPI_Sleep(1000);
    }

    DeInitializeConnection();
}

/*!

@brief      Main function for initializing IoT Hub connections and performing device twin operations.

@retval     0 upon successful execution, indicating normal program termination.

*/
int main()
{   
    DeviceManager::DeviceTwinHandler::DeviceTwin_fnFetchDpsInfo();
    deviceId = registrationId;
    // updatePrivacyPolicy();
    // updateUserAgreement();
    
    IoTHub_Init();

    std::thread iotHubThread1(create_deviceHandle);
    ThreadAPI_Sleep(1000);
    std::thread iotHubThread2(iothub_module);

    std::thread weatherThread(runUpdateWeatherInfoApi);

    if (iotHubThread1.joinable())
    {
        iotHubThread1.join();
    }

    if (iotHubThread2.joinable())
    {
        iotHubThread2.join();
    }
    stopThread = true;
    if (weatherThread.joinable()) {
        weatherThread.join();  // Wait for the thread to finish
    }

    return 0;
}