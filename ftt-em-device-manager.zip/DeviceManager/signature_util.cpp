#include "signature_util.h"


std::string computeMD5(const std::string& data) {
    unsigned char digest[MD5_DIGEST_LENGTH];
    MD5(reinterpret_cast<const unsigned char*>(data.c_str()), data.size(), digest);

    std::stringstream ss;
    for (int i = 0; i < MD5_DIGEST_LENGTH; ++i)
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(digest[i]);

    return ss.str();
}

std::string computeHMACSHA256(const std::string& key, const std::string& data) {
    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int digestLen;

    HMAC_CTX* hmac_ctx = HMAC_CTX_new();
    HMAC_CTX_reset(hmac_ctx);
    
    HMAC_Init_ex(hmac_ctx, key.c_str(), key.length(), EVP_sha256(), NULL);
    HMAC_Update(hmac_ctx, reinterpret_cast<const unsigned char*>(data.c_str()), data.length());
    HMAC_Final(hmac_ctx, digest, &digestLen);

    HMAC_CTX_free(hmac_ctx);

    return std::string(reinterpret_cast<char*>(digest), digestLen);
}

std::string base64Encode(const std::string& data) {
    BIO* bio = BIO_new(BIO_s_mem());
    BIO* b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    BIO_write(bio, data.c_str(), data.size());
    BIO_flush(bio);

    BUF_MEM* bufferPtr = NULL;
    BIO_get_mem_ptr(bio, &bufferPtr);
    std::string output(bufferPtr->data, bufferPtr->length - 1);
    BIO_free_all(bio);

    return output;
}

std::string urlEncode(const std::string& str) {
    CURL* curl = curl_easy_init();
    char* output = curl_easy_escape(curl, str.c_str(), str.size());
    std::string result(output);
    curl_free(output);
    curl_easy_cleanup(curl);
    return result;
}

std::string generateSign(const std::string& uniqueCode, const std::string& modelCode,
                         const std::string& timestamp, const std::string& salt) {
    std::string key = uniqueCode + "#" + salt;
    std::string md5Key = computeMD5(key);
    std::cout << "MD5 Key: " << md5Key << std::endl;

    std::string valueToSignature = "uniqueCode=" + uniqueCode + "&modelCode=" + modelCode +
                                   "&timestamp=" + timestamp + "&key=" + md5Key;

    std::string hmac = computeHMACSHA256(uniqueCode, valueToSignature);

    std::string encodedSignature = base64Encode(hmac);
    std::string urlEncodedSignature = urlEncode(encodedSignature);

    return urlEncodedSignature;
}
