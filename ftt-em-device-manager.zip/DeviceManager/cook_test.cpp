
#include <iostream>
#include <stdio.h>

#include "cook.h"

using namespace std;

void fun2(){
    cout << "hey its fun2";
}

void iothub_module_cpp(){
    fun2();
    cout << "heycpp\n";   
}

/*
#include <stdio.h>
void iothub_module(){
    printf("hey");   
}
*/