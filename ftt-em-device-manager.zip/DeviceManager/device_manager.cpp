
/**
 *
 * @copyright (c) 2024. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd.
 *
 ******************************************************************************
 * @file      device_manager.cpp
 * @brief     This file handels the remote commands, etc over the routes mechanisum
 *
 ******************************************************************************
 */
#define USE_EDGE_MODULES true
/*=============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*=============================================================================
                              Project Includes
==============================================================================*/
#include "azureiot/iothub_module_client_ll.h"
#include "azureiot/iothub_client_options.h"
#include "azureiot/iothub_message.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "azureiot/iothubtransportmqtt.h"
#include "azureiot/iothub.h"
#include "azureiot/iothubtransportmqtt.h"
#include "time.h"

#include "device_manager.h"
/*c2d include*/ //150324
#include "azureiot/iothub_device_client_ll.h"
/*=============================================================================
                              Private Includes
==============================================================================*/
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"


bool sendDataToRoute = false; //150324
char ch_rmtCmdBuff[20];

/**
 * @brief Structure representing a message instance.
 */
typedef struct MESSAGE_INSTANCE_TAG
{
    IOTHUB_MESSAGE_HANDLE messageHandle;
    size_t messageTrackingId;  /**< For tracking the messages within the user callback. */
} MESSAGE_INSTANCE;

size_t messagesReceivedByInput1Queue = 0;

/**
 * @brief Callback function for sending confirmation.
 * @param result Result of confirmation.
 * @param userContextCallback User context callback.
 */
static void SendConfirmationCallback(IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback)
{
    MESSAGE_INSTANCE* messageInstance = (MESSAGE_INSTANCE*)userContextCallback;
    printf("Confirmation[%zu] received for message with result = %d\r\n", messageInstance->messageTrackingId, result);
    IoTHubMessage_Destroy(messageInstance->messageHandle);
    free(messageInstance);
}

/**
 * @brief Create a message instance.
 * @param message IoT Hub message handle.
 * @return Pointer to the message instance.
 */
static MESSAGE_INSTANCE* CreateMessageInstance(IOTHUB_MESSAGE_HANDLE message)
{
    MESSAGE_INSTANCE* messageInstance = (MESSAGE_INSTANCE*)malloc(sizeof(MESSAGE_INSTANCE));
    if (NULL == messageInstance)
    {
        printf("Failed allocating 'MESSAGE_INSTANCE' for pipelined message\r\n");
    }
    else
    {
        memset(messageInstance, 0, sizeof(*messageInstance));

        if ((messageInstance->messageHandle = IoTHubMessage_Clone(message)) == NULL)
        {
            free(messageInstance);
            messageInstance = NULL;
        }
        else
        {
            messageInstance->messageTrackingId = messagesReceivedByInput1Queue;
        }
    }

    return messageInstance;
}

/**
 * @brief This call back function handels the input messgaes comming from the route
 * @param message payload received fromthe cloud
 * @param userContextCallback User context callback.
 * @return Result of message disposition.
 */
static IOTHUBMESSAGE_DISPOSITION_RESULT module_routeInCallback(IOTHUB_MESSAGE_HANDLE message, void *userContextCallback)
{
    bool SendMsgToRoute = false;

    IOTHUBMESSAGE_DISPOSITION_RESULT result;
    IOTHUB_CLIENT_RESULT clientResult;
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle = (IOTHUB_MODULE_CLIENT_LL_HANDLE)userContextCallback;

    unsigned const char *messageBody;
    size_t contentSize;
    
    char json_str[50];

    if (IoTHubMessage_GetByteArray(message, &messageBody, &contentSize) == IOTHUB_MESSAGE_OK)
    {   
        memset(json_str, 0x20, contentSize); // clear every byte
        strcpy(json_str, (const char*)(messageBody));
        json_str[contentSize] = NULL;
    }

    printf("\n\n LOGS: Received message from route as messageBody : [%s]\n", messageBody);
    printf("\n\n LOGS: Received message from route as json_str : [%s]\n", json_str);

    rapidjson::Document document;
    char u8_RmtCmdMsg[20]; 

    document.SetObject();
    document.Parse(json_str);
    if (!document.IsObject())
    {
        printf("ERROR: document is not a type object\n");
    }

    if (document.HasMember("msgid"))
    {   
        int m_msgId = document["msgid"].GetUint();
        switch (m_msgId)
        {
        case 0xff:
            printf("future use\n");
            break;

        default:
            printf("Error, Message id mismatch\n");
            break;
        }
    }

    if (SendMsgToRoute)
    {
        IOTHUB_MESSAGE_HANDLE p_routeMessage;

        p_routeMessage = IoTHubMessage_CreateFromString(u8_RmtCmdMsg);

        MESSAGE_INSTANCE *messageInstance = CreateMessageInstance(p_routeMessage);
        if (NULL == messageInstance)
        {
            result = IOTHUBMESSAGE_ABANDONED;
        }
        else
        {
            printf("Sending message %s, cnt (%zu), to the next module in pipeline\n\n", u8_RmtCmdMsg, messagesReceivedByInput1Queue);

            clientResult = IoTHubModuleClient_LL_SendEventToOutputAsync(iotHubModuleClientHandle, messageInstance->messageHandle, "device_manager_out", SendConfirmationCallback, (void *)messageInstance);
            if (clientResult != IOTHUB_CLIENT_OK)
            {
                IoTHubMessage_Destroy(messageInstance->messageHandle);
                free(messageInstance);
                printf("IoTHubModuleClient_LL_SendEventToOutputAsync failed on sending msg#=%zu, err=%d\n", messagesReceivedByInput1Queue, clientResult);
                result = IOTHUBMESSAGE_ABANDONED;
            }
            else
            {
                result = IOTHUBMESSAGE_ACCEPTED;
            }
        }
    }
    messagesReceivedByInput1Queue++;
    return result;
}

/**
 * @brief Initialize IoT Hub connection.
 * @return Handle to IoT Hub module client.
 */
static IOTHUB_MODULE_CLIENT_LL_HANDLE InitializeConnection()
{
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;

    if (IoTHub_Init() != 0)
    {
        printf("Failed to initialize the platform.\r\n");
        iotHubModuleClientHandle = NULL;
    }
    else if ((iotHubModuleClientHandle = IoTHubModuleClient_LL_CreateFromEnvironment(MQTT_Protocol)) == NULL)
    {
        printf("ERROR: IoTHubModuleClient_LL_CreateFromEnvironment failed\r\n");
    }
    else
    {
        // Uncomment the following lines to enable verbose logging.
         //bool traceOn = true;
         //IoTHubModuleClient_LL_SetOption(iotHubModuleClientHandle, OPTION_LOG_TRACE, &trace);
    }

    return iotHubModuleClientHandle;
}

/**
 * @brief Deinitialize IoT Hub connection.
 * @param iotHubModuleClientHandle Handle to IoT Hub module client.
 */
static void DeInitializeConnection(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle)
{
    if (iotHubModuleClientHandle != NULL)
    {
        IoTHubModuleClient_LL_Destroy(iotHubModuleClientHandle);
    }
    IoTHub_Deinit();
}

/**
 * @brief Set up callbacks for IoT Hub module.
 * @param iotHubModuleClientHandle Handle to IoT Hub module client.
 * @return Result of setting up callbacks.
 */
static int SetupCallbacksForModule(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle)
{
    int ret;

    if (IoTHubModuleClient_LL_SetInputMessageCallback(iotHubModuleClientHandle, "device_manager_in", module_routeInCallback, (void*)iotHubModuleClientHandle) != IOTHUB_CLIENT_OK)
    {
        printf("ERROR: IoTHubModuleClient_LL_SetInputMessageCallback(\"routeIn\")..........FAILED!\r\n");
        ret = 1;
    }
    else
    {
        ret = 0;
    }

    return ret;
}


uint8_t u8_cloudDataBuffer[50];
uint8_t u8_directMethodName[] = "remoteCommandMethod";

/*
{"msgid": 2011, "cooking_cmd" : 0} //start
{"msgid": 2011, "cooking_cmd" : 1} //stop
{"msgid": 2011, "cooking_cmd" : 2} //pause
{"msgid": 2011, "cooking_cmd" : 3} //resume
{"msgid": 2012,  "child_lock":true} //child lock
{"msgid": 2012,  "child_lock"false} //child unlock
*/

#define MSGID_COOKING_COMMAND 2011
#define MSGID_CHILD_LOCK_COMMAND 2012
#define MSGID_CHILD_LOCK_ENABLE_COMMAND true
#define MSGID_CHILD_LOCK_DISABLE_COMMAND false
#define MSGID_DEVICE_CONFIGURATION 2013
#define MSGID_DEVICE_DIAGNOSTICS_INFO_COMMAND 2014

/**
 * @brief This function handels the input commands received from the cloud.
 * 
 * @param   iotHubModuleClientHandle    Handle to IoT Hub module client.
 * @param   method_name                 Method name invoked from the cloud should match the method name present in module
 * @param   payload                     the payload received in method invoke request
 * @param   size                        the number of bytes in the payload
 * @param   response                    double pointer to send back the response payload to cloud
 * @param   response_size               size in bytes of response payload
 * @param   userContextCallback         User specified context that will be provided to the
 *  
 * @return Result of setting up callbacks.
 * 
 */

int module_directMethodCallback(const char *method_name, const unsigned char *payload, size_t size, unsigned char **response, size_t *response_size, void *userContextCallback)
{
    (void)userContextCallback;
    int result;
    uint8_t responseType = 0;
    uint8_t cmdVal = 0;
    uint8_t caseError = 0;
    enum possibleErrorList
    {
        inavlid_cmd = 100,
    };

    if (strcmp((char *)u8_directMethodName, method_name) == 0)
    {
        printf("### Received Binary message\r\nData: %s\r\n", payload);
        rapidjson::Document document;

        sendDataToRoute = false;
        memset(u8_cloudDataBuffer, 0x20, 50); // clear every byte with space ascii value
        strcpy((char *)u8_cloudDataBuffer, (const char *)payload);
        u8_cloudDataBuffer[size] = NULL;

        document.SetObject();
        document.Parse((char *)u8_cloudDataBuffer);
        if (!document.IsObject())
        {
            printf("ERROR: document is not a type object\n");
        }

        if (document.HasMember("msgid")) // if received payload is vaild
        {
            memset(ch_rmtCmdBuff, 0x20, 20); // clear the buffer
            //cmdVal = 0;
            //cmdVal = document["msgid"].GetUint(); // fetch msgid value

            switch ( document["msgid"].GetUint() ) // check msgid
            {

            case MSGID_COOKING_COMMAND:
            {
                if (document.HasMember("cooking_cmd")) // for cooking operations
                {

                    switch ((document["cooking_cmd"].GetUint()))
                    {

                    case MSG_ID_START_COOKING_CMD:
                    {
                        strcpy(ch_rmtCmdBuff, "START_COOKING_CMD");
                        sendDataToRoute = true;
                        break;
                    }

                    case MSG_ID_STOP_COOKING_CMD:
                    {
                        strcpy(ch_rmtCmdBuff, "STOP_COOKING_CMD");
                        sendDataToRoute = true;
                        break;
                    }

                    case MSG_ID_RESUME_COOKING_CMD:
                    {
                        strcpy(ch_rmtCmdBuff, "RESUME_COOKING_CMD");
                        sendDataToRoute = true;
                        break;
                    }

                    case MSG_ID_PAUSE_COOKING_CMD:
                    {
                        strcpy(ch_rmtCmdBuff, "PAUSE_COOKING_CMD");
                        sendDataToRoute = true;
                        break;
                    }

                    default:
                        caseError = inavlid_cmd;
                        sendDataToRoute = false;
                        break;
                    }
                }
                else{
                        caseError = inavlid_cmd;
                        sendDataToRoute = false;  
                }
                break;
            }

            case MSGID_CHILD_LOCK_COMMAND:
            {
                if (document.HasMember("child_lock")) // for cooking operations
                {
                    cmdVal = 0;
                    cmdVal = document["child_lock"].GetUint();
                    switch (cmdVal)
                    {
                    case MSGID_CHILD_LOCK_ENABLE_COMMAND:
                    {
                        strcpy(ch_rmtCmdBuff, "CHILD_LOCK_ENABLE_CMD");
                        sendDataToRoute = true;
                        break;
                    }

                    case MSGID_CHILD_LOCK_DISABLE_COMMAND:
                    {
                        strcpy(ch_rmtCmdBuff, "CHILD_LOCK_DISABLE_CMD");
                        sendDataToRoute = true;
                        break;
                    }

                    default:
                        sendDataToRoute = false;
                        break;
                    }
                }
                break;
            }

            case MSGID_DEVICE_DIAGNOSTICS_INFO_COMMAND:
            {
                if (document.HasMember("diagnostics")) // for cooking operations
                {
                    strcpy(ch_rmtCmdBuff, "GET_DIAGNOSTICS_DETAILS_CMD");
                    sendDataToRoute = true;
                }
                break;
            }

            case MSGID_DEVICE_CONFIGURATION:
            {
                if (document.HasMember("devconfig")) // for cooking operations
                {
                    strcpy(ch_rmtCmdBuff, "DEVICE_CONFIG_CHANGE_CMD");
                    sendDataToRoute = true;
                }
                break;
            }

            default:
                sendDataToRoute = false;
                break;
            }

        } // if msgid value is present
        else
        {
            caseError = inavlid_cmd;
        }

    } // if msgid key is present
    else
    {
        caseError = inavlid_cmd;
    }

    if ((caseError == 0) && (sendDataToRoute == true))
    {
        const char deviceMethodResponse[] = "{\"Response\": \"100\"}";
        *response_size = sizeof(deviceMethodResponse) - 1;
        *response = (unsigned char *)malloc(*response_size);
        (void)memcpy(*response, deviceMethodResponse, *response_size);
        result = 200;
    }
    else
    {
        switch (caseError)
        {
        case inavlid_cmd:
        {
            printf("Error, Message id mismatch\n");
            const char deviceMethodResponse[] = "{\"Response\": \"100\"}";
            *response_size = sizeof(deviceMethodResponse) - 1;
            *response = (unsigned char *)malloc(*response_size);
            (void)memcpy(*response, deviceMethodResponse, *response_size);
            result = -1;
            break;
        }

        default:
            const char deviceMethodResponse[] = "{\"Response\": \"unkown error\"}";
            *response_size = sizeof(deviceMethodResponse) - 1;
            *response = (unsigned char *)malloc(*response_size);
            (void)memcpy(*response, deviceMethodResponse, *response_size);
            result = -1;
            break;
        }
    }
    return result;
}

/*
int module_directMethodCallback(const char *method_name, const unsigned char *payload, size_t size, unsigned char **response, size_t *response_size, void *userContextCallback)
{
    (void)userContextCallback;
    int result;

    if (strcmp((char*)u8_directMethodName, method_name) == 0)
    {
        printf("Received Binary message\r\nData: %s\r\n", payload);
        rapidjson::Document document;
        
        sendDataToRoute = false;
        memset(u8_cloudDataBuffer, 0x20, 50); // clear every byte with space ascii value
        strcpy((char*)u8_cloudDataBuffer, (const char*)payload);
        u8_cloudDataBuffer[size] = NULL;

        document.SetObject();
        document.Parse((char*)u8_cloudDataBuffer);
        if (!document.IsObject())
        {
            printf("ERROR: document is not a type object\n");
        }

        if (document.HasMember("msgid"))
        {   
            int m_msgId = 0;
            m_msgId = document["msgid"].GetUint();
            memset(ch_rmtCmdBuff, 0x20, 20);
            switch (m_msgId)
            {

            case MSG_ID_START_COOKING_CMD:
            {   
                const char deviceMethodResponse[] = "{\"Response\": \"msg id found in msgid 2011\"}";
                *response_size = sizeof(deviceMethodResponse) - 1;
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                result = 200;
                strcpy(ch_rmtCmdBuff, "START_COOKING_CMD");
                sendDataToRoute = true;
            }
            break;

            case MSG_ID_STOP_COOKING_CMD:
            {
                strcpy(ch_rmtCmdBuff, "STOP_COOKING_CMD");
                sendDataToRoute = true;
            }
            break;

            case MSG_ID_RESUME_COOKING_CMD:
            {
                strcpy(ch_rmtCmdBuff, "RESUME_COOKING");
                
                sendDataToRoute = true;
            }
            break;

            case MSG_ID_PAUSE_COOKING_CMD:
            {
                strcpy(ch_rmtCmdBuff, "PAUSE_COOKING");
                sendDataToRoute = true;
            }
            break;

            case MSG_ID_MAGNETRON_TIME_CMD:
            {
                strcpy(ch_rmtCmdBuff, "FUTURE USE");
            }
            break;

            case MSG_ID_CHILD_LOCK_CMD:
            {
                strcpy(ch_rmtCmdBuff, "ENABLE_CHILD_LOCK");
                sendDataToRoute = true;
            }
            break;

            default:
                printf("Error, Message id mismatch\n");
                const char deviceMethodResponse[] = "{\"Response\": \"msg id found but msg id mismatch\"}";
                *response_size = sizeof(deviceMethodResponse) - 1;
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                result = 200;
                break;
            }
        }
        else
        {
            printf("no msg id found");
            *response_size = size;
            *response = (unsigned char *)malloc(*response_size);
            (void)memcpy(*response, u8_cloudDataBuffer, size);
            result = 200;
        }
        
    }
    else
    {
        // All other entries are ignored.
        const char deviceMethodResponse[] = "{\"Response\": \"invalid method name\"}";
        *response_size = sizeof(deviceMethodResponse) - 1;
        *response = (unsigned char *)malloc(*response_size);
        (void)memcpy(*response, deviceMethodResponse, *response_size);
        result = -1;
    }
    return result;
}
*/

/**
 * @brief Main function for IoT Hub module in C++.
 * @warning: Do not call IoTHubModuleClient_LL_Destroy() or IoTHubModuleClient_LL_DoWork() from inside your application's callback.
 */
void IothubModuleHandler()
{   
    bool moduleRunner = true;
    IOTHUB_CLIENT_TRANSPORT_PROVIDER protocol;
    protocol = MQTT_Protocol;
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;

    srand((unsigned int)time(NULL));
    
    if((iotHubModuleClientHandle = InitializeConnection()) != NULL && SetupCallbacksForModule(iotHubModuleClientHandle) == 0)
    {   
        IoTHubModuleClient_LL_SetModuleMethodCallback(iotHubModuleClientHandle, module_directMethodCallback, NULL);
      
        do
        {
            IoTHubModuleClient_LL_DoWork(iotHubModuleClientHandle);
            if (sendDataToRoute == true)
            {
                sendDataToRoute = false;
                IOTHUB_MESSAGE_HANDLE p_routeMessage;
                p_routeMessage = IoTHubMessage_CreateFromString(ch_rmtCmdBuff);
                MESSAGE_INSTANCE *messageInstance = CreateMessageInstance(p_routeMessage);
                IoTHubModuleClient_LL_SendEventToOutputAsync(iotHubModuleClientHandle, messageInstance->messageHandle, "device_manager_out", SendConfirmationCallback, (void *)messageInstance);
                messagesReceivedByInput1Queue++;
            }
            ThreadAPI_Sleep(10);
        }
        while( moduleRunner == true );
    }
    DeInitializeConnection(iotHubModuleClientHandle);
}

/************ (C) COPYRIGHT (c) 2024 *********END OF FILE****/

