#ifndef SIGN_UTIL_H
#define SIGN_UTIL_H

#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <openssl/hmac.h>
#include <openssl/md5.h>
#include <openssl/sha.h>  // Include for SHA definitions
#include <openssl/evp.h>
#include <openssl/buffer.h>
#include <curl/curl.h>

// Function to compute MD5 hash
std::string computeMD5(const std::string& data);

// Function to compute HMAC SHA-256
std::string computeHMACSHA256(const std::string& key, const std::string& data);

// Function to encode data in base64
std::string base64Encode(const std::string& data);

// Function to URL encode a string
std::string urlEncode(const std::string& str);

// Function to generate the signature
std::string generateSign(const std::string& uniqueCode, const std::string& modelCode,
                         const std::string& timestamp, const std::string& salt);

#endif // SIGN_UTIL_H
