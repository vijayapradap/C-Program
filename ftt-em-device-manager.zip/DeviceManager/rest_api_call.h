#ifndef CURL_REQUEST_H
#define CURL_REQUEST_H

#include <string>
#include "signature_util.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <memory>
#include "json.hpp"
#include <filesystem>
#include <regex>
#include <chrono>
#include <ctime>
#include <cstdlib>
#include <nlohmann/json.hpp>

// Function to perform a GET request and store the response in a JSON file
bool updateUserDetails(const std::string userBindId);

bool updatePrivacyPolicy( void );

bool updateUserAgreement( void );

bool updateUserBinding( bool );

bool unbindUserDetails(const std::string userBindId);

bool updateWeatherInfo( void );

// Function to generate a signature using HMAC-SHA256
//std::string requestAzureSign(const std::string& uniqueCode, const std::string& modelCode, const std::string& timestamp);

#endif // CURL_REQUEST_H
