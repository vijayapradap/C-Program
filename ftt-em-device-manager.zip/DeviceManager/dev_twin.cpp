/**
 *
 * @copyright (c) 2023 Organization Name. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      sample_template.cpp
 * @brief     This module is responsible for such and such task 
 * @author    Dipendra.Kumar
 * @version   1.0
 * @date      July 24 , 2023
 *
 ******************************************************************************
 */


/*==============================================================================
                              System Includes
==============================================================================*/
#include <iostream>
// extern "C"
// {
//  #include<string.h>
//  #include<stdio.h>
// }
/*=============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Private Includes
==============================================================================*/
#include "dev_twin.h"
/*==============================================================================
                              Private Macros
==============================================================================*/
// The protocol you wish to use should be uncommented
#define SAMPLE_MQTT
//#define SAMPLE_MQTT_OVER_WEBSOCKETS
//#define SAMPLE_AMQP
//#define SAMPLE_AMQP_OVER_WEBSOCKETS
//#define SAMPLE_HTTP

#ifdef SAMPLE_MQTT
extern "C"
{
#include "iothubtransportmqtt.h"
}
#endif // SAMPLE_MQTT

#ifdef SAMPLE_MQTT_OVER_WEBSOCKETS
extern "C"
{
    #include "iothubtransportmqtt_websockets.h"
}
#endif // SAMPLE_MQTT_OVER_WEBSOCKETS

#ifdef SAMPLE_AMQP
extern "C"
{
    #include "iothubtransportamqp.h"
}
#endif // SAMPLE_AMQP

#ifdef SAMPLE_AMQP_OVER_WEBSOCKETS
extern "C"
{
    #include "iothubtransportamqp_websockets.h"
}
#endif // SAMPLE_AMQP_OVER_WEBSOCKETS

#ifdef SAMPLE_HTTP
extern "C"
{
    #include "iothubtransporthttp.h"
}
#endif // SAMPLE_HTTP

#ifdef SET_TRUSTED_CERT_IN_SAMPLES
extern "C"
{
#include "certs.h"
}
#endif // SET_TRUSTED_CERT_IN_SAMPLES

#define DOWORK_LOOP_NUM     3
/*==============================================================================
                              External/Public Variables
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/
/* Paste in the your iothub device connection string  */
static const char* pConnectionString = "HostName=embedded-iot-hub-test.azure-devices.net;DeviceId=TestDeviceDipendra;SharedAccessKey=vvZ8KA20vdgKnIdoq5ksVIOlmX6zcfCad7D30QthxT8=";

/*==============================================================================
                              Static Functions 
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/
namespace DEVICE_MANAGER
{

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
//  Converts the Car object into a JSON blob with reported properties that is ready to be sent across the wire as a twin.
char* DeviceTwin::DEVICE_TWIN_fnSerializeToJson(Car* car)
{
    char* pResult;

    JSON_Value* pRootValue = json_value_init_object();
    JSON_Object* pRootObject = json_value_get_object(pRootValue);

    // Only reported properties:
    (void)json_object_set_string(pRootObject, "plastOilChangeDate", car->plastOilChangeDate);
    (void)json_object_dotset_string(pRootObject, "stMaker.pstMakerName", car->stMaker.pMakerName);
    (void)json_object_dotset_string(pRootObject, "stMaker.pStyle", car->stMaker.pStyle);
    (void)json_object_dotset_number(pRootObject, "stMaker.i32Year", car->stMaker.i32Year);
    (void)json_object_dotset_number(pRootObject, "stState.u8ReportedMaxSpeed", car->stState.u8ReportedMaxSpeed);
    (void)json_object_dotset_number(pRootObject, "stState.i32SoftwareVersion", car->stState.i32SoftwareVersion);
    (void)json_object_dotset_string(pRootObject, "stState.pVanityPlate", car->stState.pVanityPlate);

    pResult = json_serialize_to_string(pRootValue);

    json_value_free(pRootValue);

    return pResult;
}


/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */

//  Converts the desired properties of the Device Twin JSON blob received from IoT Hub into a Car object.
Car* DeviceTwin::DEVICE_TWIN_fnParseFromJson(const char* pJson, DEVICE_TWIN_UPDATE_STATE UpdateState)
{
    Car* pCar = new Car;
    JSON_Value* pRootValue = NULL;
    JSON_Object* pRootObject = NULL;

    if (NULL == pCar)
    {
        std::cout<<"ERROR: Failed to allocate memory\r\n";
    }

    else
    {
        (void)memset(pCar, 0, sizeof(Car));

        pRootValue = json_parse_string(pJson);
        pRootObject = json_value_get_object(pRootValue);

        // Only desired properties:
        JSON_Value* pChangeOilReminder;
        JSON_Value* pDesiredMaxSpeed;
        JSON_Value* pLatitude;
        JSON_Value* pLongitude;

        if (UpdateState == DEVICE_TWIN_UPDATE_COMPLETE)
        {
            pChangeOilReminder = json_object_dotget_value(pRootObject, "desired.pChangeOilReminder");
            pDesiredMaxSpeed = json_object_dotget_value(pRootObject, "desired.stSettings.u8DesiredMaxSpeed");
            pLatitude = json_object_dotget_value(pRootObject, "desired.stSettings.stLocation.dLatitude");
            pLongitude = json_object_dotget_value(pRootObject, "desired.stSettings.stLocation.dLongitude");
        }
        else
        {
            pChangeOilReminder = json_object_dotget_value(pRootObject, "pChangeOilReminder");
            pDesiredMaxSpeed = json_object_dotget_value(pRootObject, "stSettings.u8DesiredMaxSpeed");
            pLatitude = json_object_dotget_value(pRootObject, "stSettings.stLocation.dLatitude");
            pLongitude = json_object_dotget_value(pRootObject, "stSettings.stLocation.dLongitude");
        }

        if (pChangeOilReminder != NULL)
        {
            const char* pData = json_value_get_string(pChangeOilReminder);

            if (pData != NULL)
            {
                pCar->pChangeOilReminder = new char;
                if (NULL != pCar->pChangeOilReminder)
                {
                    (void)strcpy(pCar->pChangeOilReminder, pData);
                }
            }
        }

        if (pDesiredMaxSpeed != NULL)
        {
            pCar->stSettings.u8DesiredMaxSpeed = (uint8_t)json_value_get_number(pDesiredMaxSpeed);
        }

        if (pLatitude != NULL)
        {
            pCar->stSettings.stLocation.dLatitude = json_value_get_number(pLatitude);
        }

        if (pLongitude != NULL)
        {
            pCar->stSettings.stLocation.dLongitude = json_value_get_number(pLongitude);
        }
        json_value_free(pRootValue);
    }

    return pCar;
}



/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */

void DeviceTwin::DEVICE_TWIN_fnGetCompleteDeviceTwinOnDemandCallback(DEVICE_TWIN_UPDATE_STATE UpdateState, 
                            const unsigned char* pPayLoad, size_t size, void* pUserContextCallback)
{
    (void)UpdateState;
    (void)pUserContextCallback;
   std::cout<<"GetTwinAsync result:\r\n"<<(int)size<<"\r\n"<<pPayLoad<<std::endl;
    // printf("GetTwinAsync result:\r\n%.*s\r\n", (int)size, payLoad);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void DeviceTwin::DEVICE_TWIN_fnDeviceTwinCallback(DEVICE_TWIN_UPDATE_STATE UpdateState, const unsigned char* pPayLoad, size_t size, void* pUserContextCallback)
{
    (void)UpdateState;
    (void)size;

    DeviceTwin twinObj;

    Car* pOldCar = (Car*)pUserContextCallback;
    // Car* newCar = parseFromJson((const char*)pPayLoad, UpdateState);
    Car* pNewCar = twinObj.DEVICE_TWIN_fnParseFromJson((const char*)pPayLoad, UpdateState);

    if (NULL == pNewCar)
    {
        std::cout<<"ERROR: parseFromJson returned NULL\r\n";
    }
    else
    {
        if (pNewCar->pChangeOilReminder != NULL)
        {
            if ((pOldCar->pChangeOilReminder != NULL) && (strcmp(pOldCar->pChangeOilReminder, pNewCar->pChangeOilReminder) != 0))
            {
                free(pOldCar->pChangeOilReminder);
            }

            if (pOldCar->pChangeOilReminder == NULL)
            {
                // printf("Received a new pChangeOilReminder = %s\n", pNewCar->pChangeOilReminder);
                std::cout<<"Received a new pChangeOilReminder = "<<pNewCar->pChangeOilReminder<<std::endl;

                // if ( NULL != (pOldCar->pChangeOilReminder = malloc(strlen(pNewCar->pChangeOilReminder) + 1)))
                if ( NULL != (pOldCar->pChangeOilReminder = new char ) )

                {
                    (void)strcpy(pOldCar->pChangeOilReminder, pNewCar->pChangeOilReminder);

                    delete pNewCar->pChangeOilReminder;
                    // free(pNewCar->pChangeOilReminder);
                }
            }
        }

        if (pNewCar->stSettings.u8DesiredMaxSpeed != 0)
        {
            if (pNewCar->stSettings.u8DesiredMaxSpeed != pOldCar->stSettings.u8DesiredMaxSpeed)
            {
                // printf("Received a new u8DesiredMaxSpeed = %" PRIu8 "\n", pNewCar->stSettings.u8DesiredMaxSpeed);
                pOldCar->stSettings.u8DesiredMaxSpeed = pNewCar->stSettings.u8DesiredMaxSpeed;
            }
        }

        if (pNewCar->stSettings.stLocation.dLatitude != 0)
        {
            if (pNewCar->stSettings.stLocation.dLatitude != pOldCar->stSettings.stLocation.dLatitude)
            {
                // printf("Received a new latitude = %f\n", pNewCar->stSettings.stLocation.dLatitude);
                pOldCar->stSettings.stLocation.dLatitude = pNewCar->stSettings.stLocation.dLatitude;
            }
        }

        if (pNewCar->stSettings.stLocation.dLongitude != 0)
        {
            if (pNewCar->stSettings.stLocation.dLongitude != pOldCar->stSettings.stLocation.dLongitude)
            {
                // printf("Received a new longitude = %f\n", pNewCar->stSettings.stLocation.dLongitude);
                pOldCar->stSettings.stLocation.dLongitude = pNewCar->stSettings.stLocation.dLongitude;
            }
        }


        delete pNewCar;
        pNewCar = NULL;
    }
}


/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void DeviceTwin::DEVICE_TWIN_fnReportedStateCallback(int i32StatusCode, void* pUserContextCallback)
{
    (void)pUserContextCallback;
    std::cout<<"Device Twin reported properties update completed with result:"<<i32StatusCode<<std::endl;

}


/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void DeviceTwin::DEVICE_TWIN_fnDeviceTwinRun( void )
{
    IOTHUB_CLIENT_TRANSPORT_PROVIDER protocol;
    IOTHUB_DEVICE_CLIENT_HANDLE iotHubClientHandle;

    // Select the Protocol to use with the connection
#ifdef SAMPLE_MQTT
    protocol = MQTT_Protocol;
#endif // SAMPLE_MQTT
#ifdef SAMPLE_MQTT_OVER_WEBSOCKETS
    protocol = MQTT_WebSocket_Protocol;
#endif // SAMPLE_MQTT_OVER_WEBSOCKETS
#ifdef SAMPLE_AMQP
    protocol = AMQP_Protocol;
#endif // SAMPLE_AMQP
#ifdef SAMPLE_AMQP_OVER_WEBSOCKETS
    protocol = AMQP_Protocol_over_WebSocketsTls;
#endif // SAMPLE_AMQP_OVER_WEBSOCKETS
#ifdef SAMPLE_HTTP
    protocol = HTTP_Protocol;
#endif // SAMPLE_HTTP

    if (IoTHub_Init() != 0)
    {
        std::cout<<"Failed to initialize the platform.\r\n";
    }
    else
    {
        if ((iotHubClientHandle = IoTHubDeviceClient_CreateFromConnectionString(pConnectionString, protocol)) == NULL)
        {
            std::cout<<"ERROR: iotHubClientHandle is NULL!\r\n";
        }
        else
        {
            // Uncomment the following lines to enable verbose logging (e.g., for debugging).
            //bool traceOn = true;
            //(void)IoTHubDeviceClient_SetOption(iotHubClientHandle, OPTION_LOG_TRACE, &traceOn);
#if defined SAMPLE_MQTT || defined SAMPLE_MQTT_OVER_WEBSOCKETS
        //Setting the auto URL Encoder (recommended for MQTT). Please use this option unless
        //you are URL Encoding inputs yourself.
        //ONLY valid for use with MQTT
        bool bUrlEncodeOn = true;
        (void)IoTHubDeviceClient_SetOption(iotHubClientHandle, OPTION_AUTO_URL_ENCODE_DECODE, &bUrlEncodeOn);
#endif

#ifdef SET_TRUSTED_CERT_IN_SAMPLES
            // Setting the Trusted Certificate.
            // This is only necessary on systems without built-in certificate stores.
            if (IoTHubDeviceClient_SetOption(iotHubClientHandle, "TrustedCerts", certificates) != IOTHUB_CLIENT_OK)
            {
                std::cout<<"failure to set option \"TrustedCerts\"\r\n";
            }
#endif // SET_TRUSTED_CERT_IN_SAMPLES

            Car car;
            memset(&car, 0, sizeof(Car));
            // car.plastOilChangeDate = "2016";
            // car.stMaker.pMakerName = "Fabrikam";
            // car.stMaker_t.pStyle = "sedan";
            car.stMaker.i32Year = 2014;
            car.stState.u8ReportedMaxSpeed = 100;
            car.stState.i32SoftwareVersion = 1;
            // car.stState.pVanityPlate = "1I1";

            char* pReportedProperties = DEVICE_TWIN_fnSerializeToJson(&car);

            /*This API provides a way to retrieve the complete device Twin properties on-demand*/
            (void)IoTHubDeviceClient_GetTwinAsync(iotHubClientHandle, DEVICE_TWIN_fnGetCompleteDeviceTwinOnDemandCallback, NULL);
            
            /* This API sends a report of the device's properties and their current values. (Resported State ) */
            (void)IoTHubDeviceClient_SendReportedState(iotHubClientHandle, (const unsigned char*)pReportedProperties, strlen(pReportedProperties), DEVICE_TWIN_fnReportedStateCallback, NULL);
            
            /*This API sets the callback for async cloud to device method calls.*/
            // (void)IoTHubDeviceClient_SetDeviceMethodCallback(iotHubClientHandle, deviceMethodCallback, NULL);
            
            /*This API specifies a callback to be used when the device receives a state update ( Desired State )*/
            (void)IoTHubDeviceClient_SetDeviceTwinCallback(iotHubClientHandle, DEVICE_TWIN_fnDeviceTwinCallback, &car);

            (void)getchar();

            IoTHubDeviceClient_Destroy(iotHubClientHandle);
        
            // delete reportedProperties;
            // delete car.pChangeOilReminder;
        }

        IoTHub_Deinit();
    } 
}


// Namespace
/************ (C) COPYRIGHT (c) 2023 Organization Name *********END OF FILE****/
}
