#ifndef COOKING_H
#define COOKING_H

//#define USE_EDGE_MODULES true
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <iostream>
/*Azure includes*/
#include "azureiot/iothub_module_client_ll.h"
#include "azureiot/iothub_client_options.h"
#include "azureiot/iothub_message.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "azureiot/iothubtransportmqtt.h"
#include "azureiot/iothub.h"
#include "azureiot/iothubtransportmqtt.h"
#include "time.h"
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "cook.h"

#define E_FAIL false
#define E_PASS true
#define MSG_ID_START_COOKING_CMD        2011
#define MSG_ID_STOP_COOKING_CMD         2012
#define MSG_ID_RESUME_COOKING_CMD       2013
#define MSG_ID_PAUSE_COOKING_CMD        2014
#define MSG_ID_MAGNETRON_TIME_CMD       2015
#define MSG_ID_CHILD_LOCK_CMD           2016

class remote_commands
{
public:
    void startCooking(char *ptr)
    {
        strcpy(ptr, "START_COOKING");
    }
    void stopCooking(char *ptr)
    {
        strcpy(ptr, "STOP_COOKING");
    }
    void resumeCooking(char *ptr)
    {
        strcpy(ptr, "RESUME_COOKING");
    }
    void pauseCooking(char *ptr)
    {
        strcpy(ptr, "PAUSE_COOKING");
    }
    void magnetron_timming(u_int16_t magnetron_time)
    {
        // TODO:add here magnetron timming functioanllity , this will interfaced with hardware static lib
    }
    void child_lock_unlock(u_int8_t lock_status)
    {
        // TODO:add here child lock unlock functioanllity , this will interfaced with hardware static lib
    }
}; 

typedef struct MESSAGE_INSTANCE_TAG
{
    IOTHUB_MESSAGE_HANDLE messageHandle;
    size_t messageTrackingId;  // For tracking the messages within the user callback.
} 
MESSAGE_INSTANCE;

size_t messagesReceivedByInput1Queue = 0;

// SendConfirmationCallback is invoked when the message that was forwarded on from 'InputQueue1Callback'
// pipeline function is confirmed.
static void SendConfirmationCallback(IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback)
{
    // The context corresponds to which message# we were at when we sent.
    MESSAGE_INSTANCE* messageInstance = (MESSAGE_INSTANCE*)userContextCallback;
    printf("Confirmation[%zu] received for message with result = %d\r\n", messageInstance->messageTrackingId, result);
    IoTHubMessage_Destroy(messageInstance->messageHandle);
    free(messageInstance);
}

// Allocates a context for callback and clones the message
// NOTE: The message MUST be cloned at this stage.  InputQueue1Callback's caller always frees the message
// so we need to pass down a new copy.
static MESSAGE_INSTANCE* CreateMessageInstance(IOTHUB_MESSAGE_HANDLE message)
{
    MESSAGE_INSTANCE* messageInstance = (MESSAGE_INSTANCE*)malloc(sizeof(MESSAGE_INSTANCE));
    if (NULL == messageInstance)
    {
        printf("Failed allocating 'MESSAGE_INSTANCE' for pipelined message\r\n");
    }
    else
    {
        memset(messageInstance, 0, sizeof(*messageInstance));

        if ((messageInstance->messageHandle = IoTHubMessage_Clone(message)) == NULL)
        {
            free(messageInstance);
            messageInstance = NULL;
        }
        else
        {
            messageInstance->messageTrackingId = messagesReceivedByInput1Queue;
        }
    }

    return messageInstance;
}

static unsigned char *bytearray_to_str(const unsigned char *buffer, size_t len)
{
    unsigned char *ret = (unsigned char *)malloc(len + 1);
    memcpy(ret, buffer, len);
    ret[len] = '\0';
    return ret;
}

static IOTHUBMESSAGE_DISPOSITION_RESULT InputQueue1Callback(IOTHUB_MESSAGE_HANDLE message, void *userContextCallback)
{
    bool send_msg_to_route = false;

    remote_commands rmt_obj;

    IOTHUBMESSAGE_DISPOSITION_RESULT result;
    IOTHUB_CLIENT_RESULT clientResult;
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle = (IOTHUB_MODULE_CLIENT_LL_HANDLE)userContextCallback;

    unsigned const char *messageBody;
    size_t contentSize;
    
    char json_str[50];
    /*convert data into string*/
    if (IoTHubMessage_GetByteArray(message, &messageBody, &contentSize) == IOTHUB_MESSAGE_OK)
    {   
        memset(json_str, 0x20, contentSize); // clear every byte
        strcpy(json_str, (const char*)(messageBody));
        json_str[contentSize] = NULL;
    }

    printf("\n\n Received message from route as messageBody : [%s]\n", messageBody);
    printf("\n\n Received message from route as json_str : [%s]\n", json_str);

    /*decode json & chcek the keys*/
    rapidjson::Document document;
    char ptr[20]; 

    document.SetObject();
    document.Parse(json_str);
    if (!document.IsObject())
    {
        printf("Error: document is not a type object\n");
    }

    if (document.HasMember("msgid"))
    {
        int m_msgId = document["msgid"].GetUint();
        switch (m_msgId)
        {
        case MSG_ID_START_COOKING_CMD:
        {
            
            rmt_obj.startCooking(ptr);
            puts(ptr);
            send_msg_to_route = true;
        }
        break;

        case MSG_ID_STOP_COOKING_CMD:
        {
            rmt_obj.stopCooking(ptr);
            puts(ptr);
            send_msg_to_route = true;
        }
        break;

        case MSG_ID_RESUME_COOKING_CMD:
        {
            rmt_obj.resumeCooking(ptr);
            puts(ptr);
            send_msg_to_route = true;
        }
        break;

        case MSG_ID_PAUSE_COOKING_CMD:
        {
            rmt_obj.pauseCooking(ptr);
            puts(ptr);
            send_msg_to_route = true;
        }
        break;

        case MSG_ID_MAGNETRON_TIME_CMD:
        {
            if (document.HasMember("time"))
            {
                if (document["time"].IsUint())
                {
                    int val = document["time"].GetUint();

                    printf("Success, magnetron timming is set to : %d \n", val);
                }
            }
            else
            {
                printf("Error, data has no member 'time' \n");
            }
        }

        case MSG_ID_CHILD_LOCK_CMD:
        {
            if (document.HasMember("lock_status"))
            {
                if (document["lock_status"].IsUint())
                {
                    int l_status = document["lock_status"].GetUint();
                    (l_status) ? printf("Success, Child lock on") : printf("Success, child lock off");
                }
            }
            else
            {
                printf("Error, data has no member 'lock_status' \n");
            }
        }
        default:
            printf("Error, Message id mismatch\n");
            break;
        }
    }

    if (send_msg_to_route)
    {
        IOTHUB_MESSAGE_HANDLE new_message;

        new_message = IoTHubMessage_CreateFromString(ptr);

        MESSAGE_INSTANCE *messageInstance = CreateMessageInstance(new_message);
        if (NULL == messageInstance)
        {
            result = IOTHUBMESSAGE_ABANDONED;
        }
        else
        {
            printf("Sending message %s, cnt (%zu), to the next module in pipeline\n\n", ptr, messagesReceivedByInput1Queue);

            clientResult = IoTHubModuleClient_LL_SendEventToOutputAsync(iotHubModuleClientHandle, messageInstance->messageHandle, "output1", SendConfirmationCallback, (void *)messageInstance);
            if (clientResult != IOTHUB_CLIENT_OK)
            {
                IoTHubMessage_Destroy(messageInstance->messageHandle);
                free(messageInstance);
                printf("IoTHubModuleClient_LL_SendEventToOutputAsync failed on sending msg#=%zu, err=%d\n", messagesReceivedByInput1Queue, clientResult);
                result = IOTHUBMESSAGE_ABANDONED;
            }
            else
            {
                result = IOTHUBMESSAGE_ACCEPTED;
            }
        }
    }
    messagesReceivedByInput1Queue++;
    return result;
}

static IOTHUB_MODULE_CLIENT_LL_HANDLE InitializeConnection()
{
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;

    if (IoTHub_Init() != 0)
    {
        printf("Failed to initialize the platform.\r\n");
        iotHubModuleClientHandle = NULL;
    }
    else if ((iotHubModuleClientHandle = IoTHubModuleClient_LL_CreateFromEnvironment(MQTT_Protocol)) == NULL)
    {
        printf("ERROR: IoTHubModuleClient_LL_CreateFromEnvironment failed\r\n");
    }
    else
    {
        // Uncomment the following lines to enable verbose logging.
        // bool traceOn = true;
        // IoTHubModuleClient_LL_SetOption(iotHubModuleClientHandle, OPTION_LOG_TRACE, &trace);
    }

    return iotHubModuleClientHandle;
}

static void DeInitializeConnection(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle)
{
    if (iotHubModuleClientHandle != NULL)
    {
        IoTHubModuleClient_LL_Destroy(iotHubModuleClientHandle);
    }
    IoTHub_Deinit();
}

static int SetupCallbacksForModule(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle)
{
    int ret;

    if (IoTHubModuleClient_LL_SetInputMessageCallback(iotHubModuleClientHandle, "input1", InputQueue1Callback, (void*)iotHubModuleClientHandle) != IOTHUB_CLIENT_OK)
    {
        printf("ERROR: IoTHubModuleClient_LL_SetInputMessageCallback(\"input1\")..........FAILED!\r\n");
        ret = 1;
    }
    else
    {
        ret = 0;
    }

    return ret;
}

void iothub_module_cpp()
{
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;

    srand((unsigned int)time(NULL));

    if ((iotHubModuleClientHandle = InitializeConnection()) != NULL && SetupCallbacksForModule(iotHubModuleClientHandle) == 0)
    {
        // The receiver just loops constantly waiting for messages.
        printf("Waiting for incoming messages.\r\n");
        while (true)
        {
            IoTHubModuleClient_LL_DoWork(iotHubModuleClientHandle);
            ThreadAPI_Sleep(100);
        }
    }

    DeInitializeConnection(iotHubModuleClientHandle);
}

#endif 
