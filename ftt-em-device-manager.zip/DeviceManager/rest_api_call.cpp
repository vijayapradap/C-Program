#include "rest_api_call.h"
#include "device_twin.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>
#include <map>
#include <curl/curl.h>
#include "json.hpp"

using json = nlohmann::json;

const std::string BIND_URL = "https://api-microoven.dev.yingzi.com/api/appservice/frd/v1/deviceInfo/getDeviceInfoByUniqueCodeUnencrypted/";
const std::string USER_DET_URL = "https://api-microoven.dev.yingzi.com/api/hmc/v3/user/list";
const std::string UNBIND_USER_DET_URL = "https://api-microoven.dev.yingzi.com/api/appservice/frd/v1/deviceInfo/unBindDevice/";
const std::string PRIVACY_POLICY_URL = "https://api-microoven.dev.yingzi.com/api/klc/v1/knowledgeManage/getOneKnowledgeByKnowledgeCode/PRIACYPOLICY";
const std::string USER_AGREE_URL = "https://api-microoven.dev.yingzi.com/api/klc/v1/knowledgeManage/getOneKnowledgeByKnowledgeCode/USERAGREEMENT";
const std::string WEATHER_ADCODE_URL = "https://api-microoven.dev.yingzi.com/api/bsc/v1/areaNew/location";
const std::string WEATHER_INFO_URL = "https://api-microoven.dev.yingzi.com/api/bsc/v1/weather/query/adcode";
const std::string WEATHER_INFO_FILE_PATH = "/etc/smart_oven/config/weather_details.json";


static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

std::string makeCurlRequest(const std::string& url, const std::map<std::string, std::string>& headersMap) 
{
    CURL* curl;
    CURLcode res;
    std::string responseStr;
    int timeoutInSeconds = 15, maxRetries = 3;

    for (int attempt = 1; attempt <= maxRetries; ++attempt) {
        std::cout << "Attempt " << attempt << " of " << maxRetries << std::endl;

        curl_global_init(CURL_GLOBAL_DEFAULT);
        curl = curl_easy_init();

        if (curl) 
        {
            curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
            curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeoutInSeconds);

            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseStr);

            curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

            struct curl_slist* headers = nullptr;
            for (const auto& header : headersMap) 
            {
                headers = curl_slist_append(headers, (header.first + ": " + header.second).c_str());
            }
            curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

            res = curl_easy_perform(curl);
            if (res == CURLE_OK) 
            {
                std::cout << "Response received successfully on attempt " << attempt << "." << std::endl;
                curl_slist_free_all(headers);
                curl_easy_cleanup(curl);
                curl_global_cleanup();

                // std::cout << "Response for API GET call: " << responseStr << std::endl;
                return responseStr;
            }
            else
            {
                std::cerr << "Error on attempt " << attempt << ": " << curl_easy_strerror(res) << std::endl;
                if (attempt < maxRetries) 
                {
                    std::cout << "Retrying... Now trying for attempt " << (attempt + 1) << " after timeout of " << timeoutInSeconds << " seconds." << std::endl;
                }
            }

            curl_slist_free_all(headers);
            curl_easy_cleanup(curl);
        } 
        else 
        {
            std::cerr << "Failed to initialize CURL on attempt " << attempt << std::endl;
        }

        curl_global_cleanup();

        if (attempt < maxRetries) 
        {
            ThreadAPI_Sleep(1000);
        }

        else if (attempt == maxRetries) 
        {
            std::cerr << "Failed to get a valid response after " << maxRetries << " attempts." << std::endl;
            return NULL;
        }
    }

    return NULL;
}

bool unbindUserDetails(const std::string userBindId)
{
    std::string UniqueCode = registrationId;
    std::cout << "UniqueCode: " << UniqueCode << std::endl;
    std::string tmpSalt = "bTVsm373Xq3dcG7PoDHQ";
    std::string modelCode = "DW223";
    uint64_t timeMiliSec = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    std::string timeStamp = std::to_string(timeMiliSec);
    std::string azureSignature = generateSign(UniqueCode, modelCode, timeStamp, tmpSalt);
    std::cout << "Azure TimeStamp: " << timeStamp << std::endl;
    std::cout << "Azure Signature: " << azureSignature << std::endl;

    std::string urlParam = UNBIND_USER_DET_URL + "?ids=" + userBindId;
    std::cout << "User Unbinding URL:" << urlParam << std::endl;

    std::map<std::string, std::string> headers = {
        {"signature", azureSignature},
        {"timestamp", timeStamp},
        {"uniqueCode", UniqueCode},
        {"accept", "application/json;charset=UTF-8"},
        {"appId", "1002"},
        {"operator", "1177412832732327938"},
        {"x-gray-route", "0"},
        {"version", "v1"},
        {"x-bfw-deviceVersion", "2.0"},
        {"iotPlatform", "azure"},
        {"modelCode", modelCode}
    };

    std::string response = std::move(makeCurlRequest(urlParam, headers));
    std::cout<<"User Unbind API response:"<<response<<std::endl;
    return true;
}

bool updateUserDetails(const std::string userBindId) {
    std::string UniqueCode = registrationId;

    std::cout << "UniqueCode: " << UniqueCode << std::endl;
    std::string tmpSalt = "bTVsm373Xq3dcG7PoDHQ";
    std::string modelCode = "DW223";
    uint64_t timeMiliSec = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    std::string timeStamp = std::to_string(timeMiliSec);
    std::string azureSignature = generateSign(UniqueCode, modelCode, timeStamp, tmpSalt);
    std::cout << "Azure TimeStamp: " << timeStamp << std::endl;
    std::cout << "Azure Signature: " << azureSignature << std::endl;

    std::string urlParam = USER_DET_URL + "?ids=" + userBindId;
    std::cout << "ids to be sent:" << urlParam << std::endl;

    std::map<std::string, std::string> headers = {
        {"signature", azureSignature},
        {"timestamp", timeStamp},
        {"uniqueCode", UniqueCode},
        {"accept", "application/json;charset=UTF-8"},
        {"appId", "1002"},
        {"operator", "1177412832732327938"},
        {"x-gray-route", "0"},
        {"version", "v1"},
        {"x-bfw-deviceVersion", "2.0"},
        {"iotPlatform", "azure"},
        {"modelCode", modelCode}
    };

    std::string response = std::move(makeCurlRequest(urlParam, headers));

    // Save the response to a file
    std::ofstream outFile(USER_CONFIG_FILE_PATH);
    if (outFile.is_open()) {
        outFile << std::move(response);
        outFile.close();
        std::cout << "Response saved to " << USER_CONFIG_FILE_PATH << std::endl;
        return true;
    } else {
        std::cerr << "Failed to open file: " << USER_CONFIG_FILE_PATH << std::endl;
        return false;
    }
}

bool updatePrivacyPolicy( void ) {
    std::string UniqueCode = registrationId;

    std::cout << "UniqueCode: " << UniqueCode << std::endl;
    std::string tmpSalt = "bTVsm373Xq3dcG7PoDHQ";
    std::string modelCode = "DW223";
    uint64_t timeMiliSec = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    std::string timeStamp = std::to_string(timeMiliSec);
    std::string azureSignature = generateSign(UniqueCode, modelCode, timeStamp, tmpSalt);
    std::cout << "Azure TimeStamp: " << timeStamp << std::endl;
    std::cout << "Azure Signature: " << azureSignature << std::endl;

    std::string urlParam = PRIVACY_POLICY_URL;
    std::cout << "ids to be sent:" << urlParam << std::endl;

    std::map<std::string, std::string> headers = {
        {"signature", azureSignature},
        {"timestamp", timeStamp},
        {"uniqueCode", UniqueCode},
        {"accept", "application/json;charset=UTF-8"},
        {"appId", "1002"},
        {"operator", "1177412832732327938"},
        {"x-gray-route", "0"},
        {"version", "v1"},
        {"x-bfw-deviceVersion", "2.0"},
        {"iotPlatform", "azure"},
        {"modelCode", modelCode}
    };

    std::string response = std::move(makeCurlRequest(urlParam, headers));

    try {
        // Parse the JSON response
        nlohmann::json jsonResponse = nlohmann::json::parse(response);

        // Check if "data" exists and if "content" exists inside "data"
        if (jsonResponse.contains("data") && jsonResponse["data"].contains("content")) {
            // Save the response to the file if the conditions are met
            std::ofstream outFile(PRIVACY_POLICY_FILE_PATH);
            if (outFile.is_open()) {
                outFile << response;  // Save the response without std::move since it's not needed here
                outFile.close();
                std::cout << "Response saved to " << PRIVACY_POLICY_FILE_PATH << std::endl;
                return true;
            } else {
                std::cerr << "Failed to open file: " << PRIVACY_POLICY_FILE_PATH << std::endl;
                return false;
            }
        } else {
            std::cout << "No 'content' found in 'data'. Privacy Policy response not saved." << std::endl;
            return false;
        }
    } catch (const nlohmann::json::parse_error& e) {
        std::cerr << "JSON parse error: " << e.what() << std::endl;
        return false;
    }
}

bool updateUserAgreement( void ) {
    std::string UniqueCode = registrationId;
    std::cout << "UniqueCode: " << UniqueCode << std::endl;
    std::string tmpSalt = "bTVsm373Xq3dcG7PoDHQ";
    std::string modelCode = "DW223";
    uint64_t timeMiliSec = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    std::string timeStamp = std::to_string(timeMiliSec);
    std::string azureSignature = generateSign(UniqueCode, modelCode, timeStamp, tmpSalt);
    std::cout << "Azure TimeStamp: " << timeStamp << std::endl;
    std::cout << "Azure Signature: " << azureSignature << std::endl;

    std::string urlParam = USER_AGREE_URL;
    std::cout << "ids to be sent:" << urlParam << std::endl;

    std::map<std::string, std::string> headers = {
        {"signature", azureSignature},
        {"timestamp", timeStamp},
        {"uniqueCode", UniqueCode},
        {"accept", "application/json;charset=UTF-8"},
        {"appId", "1002"},
        {"operator", "1177412832732327938"},
        {"x-gray-route", "0"},
        {"version", "v1"},
        {"x-bfw-deviceVersion", "2.0"},
        {"iotPlatform", "azure"},
        {"modelCode", modelCode}
    };

    std::string response = std::move(makeCurlRequest(urlParam, headers));

    try {
        // Parse the JSON response
        nlohmann::json jsonResponse = nlohmann::json::parse(response);

        // Check if "data" exists and if "content" exists inside "data"
        if (jsonResponse.contains("data") && jsonResponse["data"].contains("content")) {
            // Save the response to the file if the conditions are met
            std::ofstream outFile(USER_AGREEMENT_FILE_PATH);
            if (outFile.is_open()) {
                outFile << response;
                outFile.close();
                std::cout << "Response saved to " << USER_AGREEMENT_FILE_PATH << std::endl;
                return true;
            } else {
                std::cerr << "Failed to open file: " << USER_AGREEMENT_FILE_PATH << std::endl;
                return false;
            }
        } else {
            std::cout << "No 'content' found in 'data'. Response not saved." << std::endl;
            return false;
        }
    } catch (const nlohmann::json::parse_error& e) {
        std::cerr << "JSON parse error: " << e.what() << std::endl;
        return false;
    }
}

bool updateUserBinding(bool newStatus) {
    // Open the JSON file
    std::ifstream inputFile(DEVICE_SETTING_FILE_PATH);
    if (!inputFile.is_open()) {
        std::cerr << "Failed to open file: " << DEVICE_SETTING_FILE_PATH << std::endl;
        return false;
    }

    // Parse the JSON data
    json j;
    inputFile >> j;
    inputFile.close();

    // Update the "user_binding_done" field
    j["user_binding_done"] = newStatus;

    // Save the updated JSON data back to the file
    std::ofstream outputFile(DEVICE_SETTING_FILE_PATH);
    if (!outputFile.is_open()) {
        std::cerr << "Failed to open file for writing: " << DEVICE_SETTING_FILE_PATH << std::endl;
        return false;
    }

    outputFile << std::setw(4) << j << std::endl;
    outputFile.close();

    std::cout << "user_binding_done updated to " << std::boolalpha << newStatus << " in " << DEVICE_SETTING_FILE_PATH << std::endl;
    return true;
}

bool updateWeatherInfo( void )
{
    std::string UniqueCode = registrationId;
    //std::string filePath = "/etc/smart_oven/config/dps_config.json";
    //std::string uniqueCode = getRegistrationId(filePath);

    if (!UniqueCode.empty()) {
        std::cout << "Registration ID: " << UniqueCode << std::endl;
    } else {
        std::cout << "Failed to retrieve Registration ID." << std::endl;
    }

    std::string latitude = "22.554";
    std::string longitude = "113.884";

    std::cout << "UniqueCode: " << UniqueCode << std::endl;
    std::string tmpSalt = "bTVsm373Xq3dcG7PoDHQ";
    std::string modelCode = "DW223";
    uint64_t timeMiliSec = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    std::string timeStamp = std::to_string(timeMiliSec);
    std::string azureSignature = generateSign(UniqueCode, modelCode, timeStamp, tmpSalt);
    std::cout << "Azure TimeStamp: " << timeStamp << std::endl;
    std::cout << "Azure Signature: " << azureSignature << std::endl;

    std::string urlParam = WEATHER_ADCODE_URL + "?latitude=" + latitude + "&longitude="+longitude;
    std::cout << "ids to be sent:" << urlParam << std::endl;

    std::map<std::string, std::string> headers = {
        {"signature", azureSignature},
        {"timestamp", timeStamp},
        {"uniqueCode", UniqueCode},
        {"accept", "application/json;charset=UTF-8"},
        {"appId", "1002"},
        {"operator", "1177412832732327938"},
        {"x-gray-route", "0"},
        {"version", "v1"},
        {"x-bfw-deviceVersion", "2.0"},
        {"iotPlatform", "azure"},
        {"modelCode", modelCode}
    };

    std::string response = std::move(makeCurlRequest(urlParam, headers));

    // Parse the JSON string into a JSON object
    json jsonObject = json::parse(response);

    // Search for the "districtAreaCode" and get its value
    std::string districtAreaCode;
    if (jsonObject.contains("data") && jsonObject["data"].contains("districtAreaCode")) {
        districtAreaCode = jsonObject["data"]["districtAreaCode"];
        std::cout << "districtAreaCode: " << districtAreaCode << std::endl;
    } else {
        std::cout << "districtAreaCode not found" << std::endl;
    }

    std::string urlParam2 = WEATHER_INFO_URL +"?adcode=" + districtAreaCode;

    std::cout << "ids to be sent:" << urlParam2 << std::endl;


    response = std::move(makeCurlRequest(urlParam2, headers));

    try {
        nlohmann::json jsonResponse = nlohmann::json::parse(response);

        // Check if "data" object and "forecasts" field are present
        if (jsonResponse.contains("data") && jsonResponse["data"].contains("forecasts") && !jsonResponse["data"]["forecasts"].empty()) {
            // Write the response to the file since "forecasts" is found inside "data"
            std::ofstream outFile(WEATHER_INFO_FILE_PATH);
            if (outFile.is_open()) {
                outFile << std::move(response);
                outFile.close();
                std::cout << "Response saved to " << WEATHER_INFO_FILE_PATH << std::endl;
                return true;
            } else {
                std::cerr << "Failed to open file: " << WEATHER_INFO_FILE_PATH << std::endl;
                return false;
            }
        } else {
            std::cerr << "\"forecasts\" not found in \"data\" object of JSON!" << std::endl;
            return false; // Skip saving the file if "forecasts" is missing inside "data"
        }
    } catch (const std::exception& e) {
        std::cerr << "Error parsing JSON: " << e.what() << std::endl;
        return false; // Skip saving the file in case of a parsing error
    }
    return true;
}