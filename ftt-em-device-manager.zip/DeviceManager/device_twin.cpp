/**
 *
 * @copyright (c) 2024. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd.
 *
 ******************************************************************************
 * @file      device_twin.cpp
 * @brief     This file handles device twin related functionalty
 *
 ******************************************************************************
 */


/*==============================================================================
                              System Includes
==============================================================================*/

/*=============================================================================
                              Project Includes
==============================================================================*/

/*==============================================================================
                              Private Includes
==============================================================================*/

/*==============================================================================
                              Private Macros
==============================================================================*/
#include "device_twin.h"
#include "rest_api_call.h"
/*==============================================================================
                              External/Public Variables
==============================================================================*/
std::string iotHubConnectionString;
std::string deviceId;
std::string deviceConnectionString;
std::string iotHubName;
std::string registrationId;
/*==============================================================================
                              Static Variables
==============================================================================*/

/*==============================================================================
                              Static Functions 
==============================================================================*/

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/
using json = nlohmann::json;
using namespace std;

void DeviceTwin_fnReportedStateCallback(int status_code, void *userContextCallback);

namespace DeviceManager
{

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
DeviceTwinHandler::DeviceTwinHandler()
{
    DeviceTwin_fnInitialize();
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
DeviceTwinHandler::~DeviceTwinHandler()
{
    DeviceTwin_fnCleanup();
}

void DeviceTwinHandler::DeviceTwin_fnFetchDpsInfo()
{
    while (true)
    {
        try
        {
            json dpsConfigJson = DeviceManager::DeviceTwinHandler::DeviceTwin_fnReadJsonFromFile(DPS_CONFIG_FILE_PATH);
            
            if (dpsConfigJson.contains("registration_id") && dpsConfigJson["registration_id"].is_string() && !dpsConfigJson["registration_id"].empty())
            {
                registrationId = dpsConfigJson["registration_id"];
                printf("reg id after reading dps_config.json file is %s\n", registrationId.c_str());
                fflush(stdout);
                break;
            }
            else
            {
                printf("Error: Missing or invalid 'registration_id' in config file. Retrying...\n");
                fflush(stdout);
            }
        }
        catch (const std::exception &e)
        {
            printf("Exception in DeviceTwin_fnFetchDpsInfo:: %s\n", e.what());
            fflush(stdout);
        }
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void DeviceTwinHandler::DeviceTwin_fnSetInitialReportedProperties()
{
    try
    {
        printf("Inside DeviceTwin_fnSetInitialReportedProperties function \n");
        json dpsConfigJson = DeviceManager::DeviceTwinHandler::DeviceTwin_fnReadJsonFromFile(DPS_CONFIG_FILE_PATH);
        std::string registration_id;
        std::string sn_code;
        std::string device_type;
        bool dps_provisioning = true;

        if (dpsConfigJson.contains("registration_id") && dpsConfigJson["registration_id"].is_string())
        {
            registration_id = dpsConfigJson["registration_id"];
        }
        else
        {
            printf("Error: Missing or invalid 'registration_id' in config file\n");
            fflush(stdout);
        }

        if (dpsConfigJson.contains("sn_code") && dpsConfigJson["sn_code"].is_string())
        {
            sn_code = dpsConfigJson["sn_code"];
        }
        else
        {
            printf("Error: Missing or invalid 'sn_code' in config file\n");
            fflush(stdout);
        }

        if (dpsConfigJson.contains("dps_provisioning") && dpsConfigJson["dps_provisioning"].is_boolean())
        {
            dps_provisioning = dpsConfigJson["dps_provisioning"];
        }
        else
        {
            printf("Error: Missing or invalid 'dps_provisioning' in config file\n");
            fflush(stdout);
        }

        if (dpsConfigJson.contains("devicetype") && dpsConfigJson["devicetype"].is_string())
        {
            device_type = dpsConfigJson["devicetype"];
        }
        else
        {
            printf("Error: Missing or invalid 'devicetype' in config file\n");
            fflush(stdout);
        }

        json deviceConfigJson = DeviceManager::DeviceTwinHandler::DeviceTwin_fnReadJsonFromFile(DEVICE_CONFIG_FILE_PATH);
        std::string device_model;
        std::string mac_address;
        std::string product;

        if (deviceConfigJson.contains("device_model") && deviceConfigJson["device_model"].is_string())
        {
            device_model = deviceConfigJson["device_model"];
        }
        else
        {
            printf("Error: Missing or invalid 'device_model' in config file\n");
            fflush(stdout);
        }

        if (deviceConfigJson.contains("mac_address") && deviceConfigJson["mac_address"].is_string())
        {
            mac_address = deviceConfigJson["mac_address"];
        }
        else
        {
            printf("Error: Missing or invalid 'mac_address' in config file\n");
            fflush(stdout);
        }

        if (deviceConfigJson.contains("product") && deviceConfigJson["product"].is_string())
        {
            product = deviceConfigJson["product"];
        }
        else
        {
            printf("Error: Missing or invalid 'product' in config file\n");
            fflush(stdout);
        }

        json initialReportedJson = {
            {"macAddr", mac_address},
            {"sn", sn_code},
            {"product", product},
            {"MAC_Address", mac_address},
            {"SN", sn_code},
            {"Product", product},
            {"Device_Model", device_model},
            {"Device_ID", registration_id},
            {"Device_Type", device_type}};

        const std::string initialReportedJsonString = initialReportedJson.dump();

        if(dps_provisioning)
        {
            if (DeviceManager::DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(initialReportedJsonString))
            {
                dpsConfigJson["dps_provisioning"] = false;
                std::ofstream outFile(DPS_CONFIG_FILE_PATH);
                if (outFile.is_open())
                {
                    outFile << dpsConfigJson.dump(4);
                    outFile.close();
                }
                else
                {
                    printf("Error: Unable to open config file for writing\n");
                    fflush(stdout);
                }
            }
        }
    }
    catch (const std::exception &e)
    {
        printf("Exception in DeviceTwin_fnSetInitialReportedProperties:: %s\n", e.what());
        fflush(stdout);
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
nlohmann::json DeviceTwinHandler::DeviceTwin_fnReadJsonFromFile(const std::string& filePath) 
{
    std::ifstream file(filePath);
    nlohmann::json jsonObject;

    try
    {
        if (!file)
        {
            throw std::runtime_error("Failed to open file: " + filePath);
        }

        file >> jsonObject;
        if (file.fail())
        {
            throw std::runtime_error("Failed to parse JSON from file: " + filePath);
        }

        printf("%s file read successfully \n",filePath.c_str());
        fflush(stdout);
    }
    catch (const std::exception &e)
    {
        printf("Exception in DeviceTwin_fnReadJsonFromFile: %s\n", e.what());
        fflush(stdout);
        return {};
    }

    return jsonObject;
}

const char* DeviceTwinHandler::read_certificate()
{
    static std::string cert_data;

    try
    {
        std::ifstream file(DEV_CERT_PEM_PATH);
        if (!file.is_open())
        {
            throw std::runtime_error(std::string("Unable to open file: ") + DEV_CERT_PEM_PATH);
        }

        std::stringstream buffer;
        buffer << file.rdbuf();
        cert_data = buffer.str();
        file.close();

        cert_data += ";";

        return cert_data.c_str();
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Exception caught: " << ex.what() << std::endl;
        return nullptr;
    }
}

const char* DeviceTwinHandler::read_keys()
{
    static std::string key_data;

    try
    {
        std::ifstream file(DEV_CERT_KEY_PATH);
        if (!file.is_open())
        {
            throw std::runtime_error(std::string("Unable to open file: ") + DEV_CERT_KEY_PATH);
        }

        std::stringstream buffer;
        buffer << file.rdbuf();
        key_data = buffer.str();
        file.close();

        key_data += ";";

        return key_data.c_str();
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Exception caught: " << ex.what() << std::endl;
        return nullptr;
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
bool DeviceTwinHandler::DeviceTwin_fnSetReportedProperties(const std::string &reportedJson)
{
    if (deviceClientHandle != nullptr)
    {
        IOTHUB_CLIENT_RESULT result = IoTHubDeviceClient_LL_SendReportedState(
            deviceClientHandle,
            (const unsigned char *)reportedJson.c_str(),
            reportedJson.length(),
            DeviceTwin_fnReportedStateCallback,
            nullptr);
        
        if (result == IOTHUB_CLIENT_OK)
        {
            return true;
        }
    }
    return false;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void DeviceTwinHandler::DeviceTwin_fnReportedStateCallback(int status_code, void *userContextCallback)
{
    if (status_code == 204)
    {
        printf("Reported Property updated successfully, status code : %d\n ", status_code);
        fflush(stdout);
    }

    else
    {
        printf("Reported Property updation failed, status code : %d\n ", status_code);
        fflush(stdout);
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
bool DeviceTwinHandler::DeviceTwin_fnInitialize()
{
    platform_init();
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void DeviceTwinHandler::DeviceTwin_fnCleanup()
{
    platform_deinit();
}
// Namespace
/************ (C) COPYRIGHT (c) 2024 *********END OF FILE****/
}