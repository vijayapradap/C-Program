

#ifdef __cplusplus
    extern "C"{
#endif

void iothub_module_cpp();

#ifdef __cplusplus
    }
#endif

