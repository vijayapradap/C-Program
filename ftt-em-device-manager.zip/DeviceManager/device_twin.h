/**
 *
 * @copyright (c) 2024. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 *
 ******************************************************************************
 * @file      device_twin.h
 * @brief     Header for device_twin.cpp, dewin twin API for read,update declared here.
 *
 ******************************************************************************
 */

#ifndef DEVICETWINHANDLER_H
#define DEVICETWINHANDLER_H

/*==============================================================================
                              System Includes
==============================================================================*/
#include <string>
#include <thread>
#include <mutex>
#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <ctime>
#include <chrono>
#include <atomic>
/*==============================================================================
                              Project Includes
==============================================================================*/
#include "json.hpp"
#include "time.h"
#include "jsoncpp/json/json.h"
#include "parson.h"
#include "iothub_service_client/iothub_service_client_auth.h"
#include "iothub_service_client/iothub_devicetwin.h"
#include "iothub_service_client/iothub_registrymanager.h"
#include "azureiot/iothub_client.h"
#include "azureiot/iothub_device_client.h"
#include "azureiot/iothub_module_client_ll.h"
#include "azureiot/iothub_client_options.h"
#include "azureiot/iothub_message.h"
#include "azureiot/iothub_client_version.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "azureiot/iothubtransportmqtt.h"
#include "azureiot/iothub.h"
#include "azureiot/iothubtransportmqtt.h"

#include "azure_c_shared_utility/threadapi.h"
/*==============================================================================
                              Exported Defines
==============================================================================*/
#define MSG_ID_UPDATE_REPORTED_PROPERTY 200
#define MSG_ID_OTA_UPDATE_RECEIVED 1001
#define MSG_ID_OTA_UPDATE_ACK 1002
#define MSG_ID_OTA_UPDATE_CONFIRMATION  1003
#define MSG_ID_OTA_UPDATE_INPROGRESS 1005
#define MSG_ID_OTA_UPDATE_SUCCESS    1007
#define MSG_ID_OTA_UPDATE_FAILED    1009
#define MSG_ID_FACTORY_RESET 1300
#define MSG_ID_FACTORY_RESET_PROGRESS  1301
#define MSG_ID_FACTORY_RESET_ACK  1302
#define MSG_ID_INVALID 0
#define DATA_BUFFER_SIZE 200
#define INVALID_COMMAND -1
#define REPORTED_PROP_BUFFER_LENGTH 100
#define DEVICE_MANAGER_INPUT_ROUTE "device_manager_in"
#define DEVICE_MANAGER_OUTPUT_ROUTE "device_manager_out"
#define OTA_MANAGER_OUTPUT_ROUTE "ota_manager_out"
#define OTA_MANAGER_INPUT_ROUTE "ota_manager_in"

#define DEVICE_TWIN_CONFIG_FILE_PATH "/etc/smart_oven/config/device_twin_config.json"
#define DPS_CONFIG_FILE_PATH "/etc/smart_oven/config/dps_config.json"
#define DEVICE_CONFIG_FILE_PATH "/etc/smart_oven/config/device_config.json"
#define DEVICE_SETTING_FILE_PATH "/etc/smart_oven/config/device_settings.json"
#define USER_CONFIG_FILE_PATH "/etc/smart_oven/config/user_config.json"
#define USER_AGREEMENT_FILE_PATH "/etc/smart_oven/config/user_agreement.json"
#define PRIVACY_POLICY_FILE_PATH "/etc/smart_oven/config/privacy_policy.json"
#define COOKING_RECORD_FILE_PATH "/etc/smart_oven/cooking_records/"
#define SMART_OVEN_LOGS_PATH "/etc/smart_oven/log/"
#define DEV_CERT_KEY_PATH "/etc/smart_oven/certs/dev_cert.key"
#define DEV_CERT_PEM_PATH "/etc/smart_oven/certs/dev_cert.pem"
/*==============================================================================
                              Exported Macros
==============================================================================*/
extern IOTHUB_DEVICE_CLIENT_LL_HANDLE deviceClientHandle;
extern IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;
extern std::string iotHubConnectionString;
extern std::string deviceConnectionString;
extern std::string iotHubName;
extern std::string registrationId;
extern std::string deviceId;
/*==============================================================================
                              Exported Enums
==============================================================================*/
enum AckCode {
    ACK_CODE_OTA_UPDATE_ACK = 1000,
    ACK_CODE_OTA_UPDATE_CONFIRMATION = 1004,
    ACK_CODE_OTA_UPDATE_INPROGRESS = 1006,
    ACK_CODE_OTA_UPDATE_SUCCESS = 1008,
    ACK_CODE_OTA_UPDATE_FAILED = 1010
};
/*==============================================================================
                              Exported Structures
==============================================================================*/

/*==============================================================================
                              Exported functions prototypes
==============================================================================*/

namespace DeviceManager
{
    class DeviceTwinHandler
    {
    public:
        /*
        
        @brief		<b> Constructor for Device Twin Handler.</b>
        @param

        @retval     None

        */
        DeviceTwinHandler();

        /*
        
        @brief		<b> Destructor for Device Twin Handler.</b>
        @param

        @retval     None

        */
        ~DeviceTwinHandler();

        /*!

        @brief      <b> Sets the initial reported properties for a device twin fetched from dps_config and device_config files. </b>
        @param[in]  None

        @retval     None

        */
        static void DeviceTwin_fnSetInitialReportedProperties();

        static const char * read_certificate();
        static const char* read_keys();
        static void DeviceTwin_fnFetchDpsInfo();
        /*!

        @brief      <b> Get the device twin JSON for a specific device. </b>
        @param[out]  deviceTwinJson Reference to store the fetched device twin JSON.

        @retval     true if the device twin JSON was successfully fetched, false otherwise.

        */
        static bool DeviceTwin_fnGetDeviceTwin(std::string &deviceTwinJson);

        /*!

        @brief      Set reported properties for the device.
        @param[in]  reportedJson JSON string containing the reported properties to set.

        @retval     true if the reported properties were successfully set, false otherwise.

        */
        static bool DeviceTwin_fnSetReportedProperties(const std::string &reportedJson);

        /*!

        @brief      Update the device twin with the provided update JSON.
        @param[in]  updateJson JSON string containing the updates to apply to the device twin.

        @param[out] updatedDeviceTwinJson Reference to store the updated device twin JSON after the update.

        @retval     true if the device twin was successfully updated, false otherwise.

        */
        static bool DeviceTwin_fnUpdateDeviceTwin(const std::string &updateJson, std::string &updatedDeviceTwinJson);

        /*!

        @brief      Read JSON data from a file.
        @param[in]  filePath Path to the JSON file to read.

        @retval     nlohmann::json object containing the parsed JSON data.

        */
        static nlohmann::json DeviceTwin_fnReadJsonFromFile(const std::string& filePath);

    private:

        /*!

        
        @brief      Initializes the DeviceTwinHandler by initializing the platform.
        @param      

        @retval     true if initialization succeeds, false otherwise.

        */
        bool DeviceTwin_fnInitialize();

        /*!

        @brief      Cleans up resources used by DeviceTwinHandler, including IoT Hub client and service handles.
        @param      

        @retval     None

        */
        void DeviceTwin_fnCleanup();

        /*!

        @brief      Callback function for handling reported properties state.
        @param[in]  status_code The status code returned by the IoT Hub for the reported properties operation.
        @param[in]  userContextCallback Optional user context data. Not used in this callback.

        @retval     None

        */
        static void DeviceTwin_fnReportedStateCallback(int status_code, void *userContextCallback);
    };
}

/*==============================================================================
                              Footer
==============================================================================*/

#endif /* DEVICETWINHANDLER_H */

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/