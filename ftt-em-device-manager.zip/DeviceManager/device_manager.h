/**
 *
 * @copyright (c) 2024. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 *
 ******************************************************************************
 * @file      device_manager.h
 * @brief     Header for device_manger.cpp, remote command ID`s & exposeable API are declared here.
 *
 ******************************************************************************
 */

#ifndef DEVICE_MANAGER_H_
#define DEVICE_MANAGER_H_

#ifdef __cplusplus
    extern "C"{
#endif

/*==============================================================================
                              Private Macros
==============================================================================*/

/*! Id for start cooking */
#define MSG_ID_START_COOKING_CMD        0
/*! Id for stop cooking */
#define MSG_ID_STOP_COOKING_CMD         1
/*! Id for resume cooking */
#define MSG_ID_RESUME_COOKING_CMD       2
/*! Id for pause cooking */
#define MSG_ID_PAUSE_COOKING_CMD        3
/*! Id to set magnetron timmings*/
#define MSG_ID_MAGNETRON_TIME_CMD       2015
/*! Id to enable disable child lock*/
#define MSG_ID_CHILD_LOCK_CMD           2016

#define ALGO_TEST_OUTPUT_ROUTE  "routeOut"

/*==============================================================================
                              Global functions
==============================================================================*/

/**
 * @brief This handler intiates the connection with azure it hub.
 * Sets the callback for routes.
 */



#ifdef __cplusplus
    }
#endif
void IothubModuleHandler(void);
#endif
/************ (C) COPYRIGHT (c) 2024 *********END OF FILE****/
