/**
 *
 * @copyright (c) 2023 Organization Name. All rights reserved.
 * All trademarks are owned or licensed by Organization Name,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      sample_template.h
 * @brief     This is the header file for doing so and so task
 * @author    Dipendra.Kumar
 * @version   1.0
 * @date      June 1, 2023
 *
 ******************************************************************************
 */

#ifndef DEVICE_MANAGER_H_
#define DEVICE_MANAGER_H_

/*==============================================================================
                              System Includes
==============================================================================*/

/*==============================================================================
                              Project Includes
==============================================================================*/
extern "C"
{
#include "azure_macro_utils/macro_utils.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/platform.h"
#include "parson.h"
}
/*==============================================================================
                              Exported Defines
==============================================================================*/

/*==============================================================================
                              Exported Macros
==============================================================================*/

/*==============================================================================
                              Exported Enums
==============================================================================*/

/*==============================================================================
                              Exported Structures
==============================================================================*/
typedef struct
{
    char* pMakerName;
    char* pStyle;
    int32_t i32Year;
} stMaker_t;

typedef struct
{
    double dLongitude;
    double dLatitude;
} stGeo_t;

typedef struct
{
    int32_t i32SoftwareVersion;        // reported property
    uint8_t u8ReportedMaxSpeed;      // reported property
    char* pVanityPlate;              // reported property
} stCarstState_t;

typedef struct
{
    uint8_t u8DesiredMaxSpeed;       // desired property
    stGeo_t stLocation;                   // desired property
} stCarSettings_t;

typedef struct
{
    char* plastOilChangeDate;        // reported property
    char* pChangeOilReminder;        // desired property
    stMaker_t stMaker;                    // reported property
    stCarstState_t stState;                 // reported property
    stCarSettings_t stSettings;           // desired property
} Car;

/*==============================================================================
                              Exported functions prototypes
==============================================================================*/

namespace DEVICE_MANAGER
{
    class DeviceTwin
    {
        public:

            void DEVICE_TWIN_fnDeviceTwinRun(void);

            char* DEVICE_TWIN_fnSerializeToJson(Car* pCar);
            
            Car* DEVICE_TWIN_fnParseFromJson(const char* pJson, DEVICE_TWIN_UPDATE_STATE UpdateState);



        private:
            static void DEVICE_TWIN_fnGetCompleteDeviceTwinOnDemandCallback(DEVICE_TWIN_UPDATE_STATE UpdateState, 
                    const unsigned char* pPayLoad, size_t size, void* userContextCallback);

            static void DEVICE_TWIN_fnDeviceTwinCallback( DEVICE_TWIN_UPDATE_STATE UpdateState, 
                                const unsigned char* pPayLoad, size_t size, void* pUserContextCallback);

            static void DEVICE_TWIN_fnReportedStateCallback(int i32StatusCode, void* pUserContextCallback);
            
        protected:

    };

}

/*==============================================================================
                              Footer
==============================================================================*/


#endif /* DEVICE_MANAGER_H_ */

/************ (C) COPYRIGHT (c) 2023 Organization Name *********END OF FILE****/
 
