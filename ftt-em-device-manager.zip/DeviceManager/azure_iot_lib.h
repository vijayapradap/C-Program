/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      sample_module.h
 * @brief     This header file contains .
 * @version   1.0
 *
 ******************************************************************************
 */

#ifndef AZURE_IOT_LIB_H_
#define AZURE_IOT_LIB_H_

/*==============================================================================
                              System Includes
==============================================================================*/


/*==============================================================================
                              Project Includes
==============================================================================*/

#include "azureiot/iothub_module_client_ll.h"
#include "azureiot/iothub_client_options.h"
#include "azureiot/iothub_message.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "azureiot/iothubtransportmqtt.h"
#include "azureiot/iothub.h"
#include "time.h"
/*==============================================================================
                              Exported Defines
==============================================================================*/

/*==============================================================================
                              Exported Macros
==============================================================================*/

/*==============================================================================
                              Exported Enums
==============================================================================*/

/*==============================================================================
                              Exported Structures
==============================================================================*/
typedef struct MESSAGE_INSTANCE_TAG
{
    IOTHUB_MESSAGE_HANDLE messageHandle;
    size_t messageTrackingId;  // For tracking the messages within the user callback.
} 
MESSAGE_INSTANCE;
/*==============================================================================
                              Exported functions prototypes
==============================================================================*/
/*!

@brief      <b> Initializes Azure IoT COnnection </b>
@param[in]  None

@retval     IOTHUB_MODULE_CLIENT_LL_HANDLE :  Connection handle for Azure client 

*/   
IOTHUB_MODULE_CLIENT_LL_HANDLE AZURE_IOT_fnInitConnection( void );

/*!

@brief      <b> Initializes Azure IoT Connection </b>
@param[in]  IOTHUB_MODULE_CLIENT_LL_HANDLE :  Connection handle for Azure client 

@retval     None

*/   
void AZURE_IOT_fnDeInitConnection( IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle );

/*!

@brief      <b> Creates message Instance for the messages to be sent over the Routes </b>
@param[in]  messageHandle : Message Handle for preparing the route message

@retval     messageInstance: Message Instance Structure used to publish message over the routes

*/   
MESSAGE_INSTANCE* AZURE_IOT_CreateMessageInstance(IOTHUB_MESSAGE_HANDLE messageHandle );

/*!

@brief      <b> Function to convert Byte array recieved on the routes to String </b>
@param[in]  pInputByteArrayBuffer : Input Buffer ( Bytearray ) recieved from IoT Hub
            inputBufferLength : Length of Input Buffer ( Bytearray ) recieved from IoT Hub

@retval     pStringBuffer : Returns string buffer after converting pInputByteArrayBuffer to string

*/
unsigned char *AZURE_IOT_fnByteArrayToString(const unsigned char *pInputByteArrayBuffer, size_t inputBufferLength);

/*!

@brief      <b> Function to publish message over the defined Routes </b>
@param[in]  iotHubModuleClientHandle : The connection client handle
            pCommand : The actual message to be published to the Route
            pRoute : Route Name

@retval     ePublishMessageStatus : IOTHUB_CLIENT_OK if Message is sent successfully 
                                    IOTHUB_CLIENT_ERROR if Message send fails   

*/
IOTHUB_CLIENT_RESULT AZURE_IOT_fnPublishMessageToRoute( IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle, 
                                                                        const char *pCommand, const char *pRoute );

/*!

@brief      <b> Callback Function that gets triggered after publishing message to the Routes </b>
@param[in]  result : Status of messages being sent via route
            userContextCallback : 

@retval     None

*/
void AZURE_IOT_fnSendConfirmationCb( IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback );

/*!

@brief      <b> Function to Set up the callback on specific input routes </b>
@param[in]  iotHubModuleClientHandle : The connection client handle
            callbackFunctionName : Callback to be triggered upon recieving messaged over the defined input Route
            pInputRoute : Input Route Name
            userContextCallback : 

@retval     i32CallbackStatus : IOTHUB_CLIENT_OK if Callback is registered successfully 
                                IOTHUB_CLIENT_ERROR if Callback is registration fails 

*/
int AZURE_IOT_fnRegisterInputMessageCallback(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle, const char *pInputRoute, 
                                IOTHUB_CLIENT_MESSAGE_CALLBACK_ASYNC callbackFunctionName,void *userContextCallback );

/*!

@brief      <b> This function continuopusly listens to the incoming message </b>
@param[in]  activeClientHandle : The connection client handle

@retval     None

*/
void AZURE_IOT_fnListenIncomingMessageLoop( IOTHUB_MODULE_CLIENT_LL_HANDLE activeClientHandle );

/*==============================================================================
                              Footer
==============================================================================*/

#endif /* AZURE_IOT_LIB_H_ */

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/













// /*!

// @brief      <b> Initialize Azure IoT Hub Module </b>
// @param[in]  result : Status of messages being sent via route
//             userContextCallback : 

// @retval     iotHubModuleClientHandle: The connection client handle

// */
// IOTHUB_MODULE_CLIENT_LL_HANDLE AZURE_IOT_fnInitIothubModule( const char *pInputRoute );
