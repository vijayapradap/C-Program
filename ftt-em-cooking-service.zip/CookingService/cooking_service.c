/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      cooking_service.c
 * @brief     This module is responsible for cooking service functionalities
 * @author    Vijayapradap M
 * @version   1.0
 * @date      July 12 , 2024
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/
#define _GNU_SOURCE

/**/
#include <signal.h>
#include <unistd.h>
#include <resolv.h>
#include <arpa/inet.h>
#include <errno.h>

/*=============================================================================
                              Project Includes
==============================================================================*/

#include "cooking_service.h"
#include "oven_wrapper_apis_lib.h"

/*==============================================================================
                              Private Includes
==============================================================================*/

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/

/*==============================================================================
                              Static Variables
==============================================================================*/

static bool bDiyEnable = false, bPwrEnable = false, bPrevDoor = false, bCkStart = true;
static bool bTimerHandler = false, bTimerRegister = false, bDoorOpened = false;
static stCookingData_t stCookingData;
static eCookMode_t eCookMode;
char *gRemainTime = NULL;
static long lCookingRecordId = 0;

/*==============================================================================
                              Static Functions
==============================================================================*/

void watchdog( int signum );
static long record_id( void );
char *generate_msg_id( void );
static void COOKING_SERVICE_WRAPPER_fnStartTimer( void );
static void COOKING_SERVICE_WRAPPER_fnStartCooking( void );
static void COOKING_SERVICE_WRAPPER_fnStopCooking( void );
static void COOKING_SERVICE_WRAPPER_fnPauseCooking( void );
static void COOKING_SERVICE_WRAPPER_fnResumeCooking( void );
int8_t COOKING_SERVICE_fnUpdateCookingRecord( eState_t eState, eResult_t eResult, uint64_t u64Timestamp );
int8_t COOKING_SERVICE_fnUpdateCookingStatus( eHeatStat_t eHeatStat, eHeatCode_t eHeatCode, uint64_t u64Timestamp );
static void COOKING_SERVICE_fnSentResponse( uint16_t u16Cmd, bool bStatus, char* cpCommand, char **deviceMethodResponse );

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void watchdog( int signum )
{
    (void)signum;

    if (bTimerHandler)
    {
        if (eCookMode == eAI)
        {
            stCookingData.i16HeatingInterval++;
            alarm(1);
        }
        else
        {
            stCookingData.i16RemainingCookingTime--;
            if ( 0 < stCookingData.i16RemainingCookingTime )
            {
                alarm(1);
                asprintf(&gRemainTime, "{\"route_message_id\" : 339, \"remaining_time\" : %d, \"timestamp\" : \"%lu\"}", \
                    stCookingData.i16RemainingCookingTime, epochTimestamp());
                COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), gRemainTime, COOKING_OUTPUT_ROUTE );
                free(gRemainTime);
            }
            else
            {
                bTimerHandler = false;
                if ( eCookMode == eDiy)
                {
                    asprintf(&gRemainTime, "{\"route_message_id\" : 339, \"remaining_time\" : 0, \"timestamp\" : \"%lu\"}", epochTimestamp());
                    COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), gRemainTime, COOKING_OUTPUT_ROUTE );
                    COOKING_SERVICE_WRAPPER_fnStopCooking();
                    free(gRemainTime);
                }
                COOKING_SERVICE_fnUpdateCookingStatus( eHeatingCompleted, eNoException, epochTimestamp() );
                COOKING_SERVICE_fnUpdateCookingRecord( eDoneCooking, eResultSuccessful, epochTimestamp() );
            }
        }
    }
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
char *generate_msg_id( void )
{
    int msgid_length = 32;
    srand((unsigned int)time(NULL));
    const char charset[] = "abcdefghijklmnopqrstuvwxyz0123456789";
    char *msgId = (char*)malloc((msgid_length + 1) * sizeof(char));
    for (int i = 0; i < msgid_length; i++) {
        int random_index = rand() % (sizeof(charset) - 1);
        msgId[i] = charset[random_index];
    }
    msgId[msgid_length] = '\0';
    return msgId;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static long record_id( void )
{
    srand((unsigned int)time(NULL));
    long random_number = rand() % 900000000000000000 + 100000000000000000;
    return random_number;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
uint64_t epochTimestamp( void )
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static bool connectivityCheck( void )
{
    const char *hostname = "bing.com";
    unsigned char response[NS_PACKETSZ];
    int response_length;
    struct __res_state res_state;

    // Initialize resolver state
    if (res_ninit(&res_state) == -1) {
        perror("res_ninit failed");
        return false;
    }

    // Set timeout to 1 second (modify as needed)
    res_state.retry = 1;
    res_state.retrans = 1;

    // Perform the DNS query for the A (IPv4) record
    response_length = res_nquery(&res_state, hostname, ns_c_in, ns_t_a, response, sizeof(response));
    if (response_length < 0) {
        perror("res_nquery failed");
        return false;  // DNS query failed
    }

    // Process the response (first address in the response)
    struct sockaddr_in addr;
    ns_msg msg;
    ns_initparse(response, response_length, &msg);
    ns_rr rr;
    
    // We now need to check the answer section (ns_sect_answer is correct)
    int result = ns_parserr(&msg, ns_s_an, 0, &rr);  // Use ns_s_an instead of ns_sect_answer
    if (result == 0) {
        memcpy(&addr.sin_addr, ns_rr_rdata(rr), sizeof(struct in_addr));
        return true;  // Success
    }

    return false;  // No address found
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t COOKING_SERVICE_fnReadOfflineData(const char* filePath )
{
    JSON_Value* pRecordValue = json_parse_file( filePath );
    if (pRecordValue == NULL)
    {
        PRINT(DERR, "Unable to read the record from : %s\n", filePath)
        return -1;
    }

    COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), json_serialize_to_string_pretty(pRecordValue), COOKING_UPSTREAM_ROUTE );
    json_value_free( pRecordValue );
    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
void COOKING_SERVICE_fnUploadOfflineRecord( void )
{
    if ( connectivityCheck() == false )
    {
        PRINT(DINF, "No Internet connectivity to upload offline records%s", "\n");
        return;
    }

    FILE *filePtr = NULL;
    char carrTempBuff[ 1024 ], *pTemp = NULL;
    filePtr = popen("ls -ltr /tmp/storage/ | awk '{print $NF}'", "r");
    if (filePtr == NULL)
    {
        PRINT(DERR, "Reading offline record failed%s", "\n");
        return;
    }

    while( fgets(carrTempBuff, sizeof(carrTempBuff), filePtr) != NULL )
    {
        if (!strstr(carrTempBuff, ".json"))
        {
            memset(carrTempBuff, 0, sizeof(carrTempBuff));
            continue;
        }

        carrTempBuff[strlen(carrTempBuff)-1] = '\0';
        asprintf(&pTemp, "/tmp/storage/%s", carrTempBuff);

        if( COOKING_SERVICE_fnReadOfflineData(pTemp) == 0)
        {
            PRINT(DINF, "Uploaded offline cooking record : %s\n", carrTempBuff);
            free(pTemp);
            asprintf(&pTemp, "rm /tmp/storage/%s", carrTempBuff);
            system(pTemp);
            free(pTemp);
        }
        else
        {
            PRINT(DINF, "Failed to upload offline cooking record%s", "\n");
            free(pTemp);
        }

        memset(carrTempBuff, 0, sizeof(carrTempBuff));
        break;
    }

    pclose(filePtr);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t COOKING_SERVICE_fnUpdateCookingStatus( eHeatStat_t eHeatStat, eHeatCode_t eHeatCode, uint64_t u64Timestamp )
{
    JSON_Value* pRecordValue = json_parse_file( ( bCkStart == true ) ? "cookingReport.json" : "cookingReport_temp.json" );
    JSON_Object* pRecordObject = json_value_get_object( pRecordValue );
    JSON_Array *pRecordArray = json_object_dotget_array( pRecordObject, "params.heat_temp" );
    JSON_Object* pArrayObject = json_array_get_object( pRecordArray, 0 );

    char *uniqueID = generate_msg_id();
    json_object_set_string( pRecordObject, "msgId", uniqueID );
    json_object_set_number( pRecordObject, "timestamp", u64Timestamp );
    json_object_set_string( pRecordObject, "deviceUuid", xDeviceUUID );
    free(uniqueID);

    if ( eHeatStat == eHeatingStarted && bCkStart == true)
    {
        json_object_dotset_number( pRecordObject, "params.start_timestamp", u64Timestamp );
        json_object_dotset_number( pRecordObject, "params.cooking_record_id", lCookingRecordId );
        json_object_dotset_number( pRecordObject, "params.end_timestamp", 0 );
        bCkStart = false;
    }
    else if ( eHeatStat == eHeatingCompleted )
    {
        json_object_dotset_number( pRecordObject, "params.end_timestamp", u64Timestamp );
        bCkStart = true;
    }
    else if ( eHeatStat == eCookingTerminated)
    {
        bCkStart = true;
    }
    
    json_object_dotset_number( pRecordObject, "params.heat_stat", eHeatStat );
    json_object_dotset_number( pRecordObject, "params.heat_code", eHeatCode );
    json_object_dotset_number( pRecordObject, "params.door_stat", bDoorOpened );

    if (eCookMode == eAI)
        json_object_set_number( pArrayObject, "heat_realtime", stCookingData.i16HeatingInterval );
    else    
        json_object_set_number( pArrayObject, "heat_realtime", (stCookingData.i16HeatingInterval - stCookingData.i16RemainingCookingTime) );
    
    json_object_set_string( pArrayObject, "inside_temp", "null" );
    json_object_set_string( pArrayObject, "stage", "0" );

    COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), json_serialize_to_string_pretty( pRecordValue ), COOKING_UPSTREAM_ROUTE );

    if ( eHeatStat == eHeatingStarted )
        PRINT(DINF, "File write status : %d\n", json_serialize_to_file_pretty( pRecordValue, "/app/cookingReport_temp.json" ));

    json_value_free( pRecordValue );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int8_t COOKING_SERVICE_fnUpdateCookingRecord( eState_t eState, eResult_t eResult, uint64_t u64Timestamp )
{
    JSON_Value* pRecordValue = json_parse_file( ( eState == eStartCooking ) ? "cookingRecord.json" : "cookingRecord_temp.json" );
    JSON_Object* pRecordObject = json_value_get_object( pRecordValue );
    JSON_Array *pRecordArray = json_object_dotget_array( pRecordObject, "params.cookingRecordStageReqDtoList" );
    JSON_Object* pArrayObject = json_array_get_object( pRecordArray, 0 );

    switch ( eState )
    {
        case eStartCooking:
        {
            char *uniqueID = generate_msg_id();
            json_object_set_string( pRecordObject, "deviceUuid", xDeviceUUID );
            json_object_set_string( pRecordObject, "msgId", generate_msg_id() );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.cookingRecordId", lCookingRecordId );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.cookingStartTime", u64Timestamp );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.ifOnline", (eCookMode == eAI) ? 1 : 0 );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.cookingType", (bDiyEnable) ? COOKING_TYPE_DIY : (bPwrEnable) ? COOKING_TYPE_PWR : COOKING_TYPE_AI );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.targetCookingTime", (eCookMode == eAI) ? 0 : stCookingData.i16HeatingInterval );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.createTime", u64Timestamp );

            json_object_set_number( pArrayObject, "targetExecutionTime", (eCookMode == eAI) ? 0 : stCookingData.i16HeatingInterval );
            json_object_set_number( pArrayObject, "targetPower", stCookingData.i16HeatingPower );
            json_object_set_number( pArrayObject, "cookingRecordId", lCookingRecordId );
            json_object_set_number( pArrayObject, "cookingRecordStageId", 0 );
            json_object_set_number( pArrayObject, "mode", eCookMode );
            json_object_set_number( pArrayObject, "createTime", u64Timestamp );

            JSON_Value* pUserValue = json_parse_file( "/var/tmp/user_config.json" );
            if ( pUserValue != NULL )
            {
                JSON_Object* pUserObject = json_value_get_object( pUserValue );
                JSON_Array *pUserArray = json_object_get_array( pUserObject, "data" );
                JSON_Object* pUsersObject = json_array_get_object( pUserArray, 0 );

                json_object_set_number( pArrayObject, "createUserId",  (int)json_object_get_number( pUsersObject, "id" ));
                json_object_set_string( pArrayObject, "createUserName",  json_object_get_string( pUsersObject, "name" ));

                json_object_clear( pUserObject );
                json_value_free( pUserValue );
            }

            free(uniqueID);
            PRINT(DINF, "File write status : %d\n", json_serialize_to_file_pretty( pRecordValue, "/app/cookingRecord_temp.json" ));
        }
        break;
        case eStopCooking:
        case eDoneCooking:
        {
            char *uploadFileName = NULL;
            json_object_dotset_number( pRecordObject, "timestamp", u64Timestamp );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.actualCookingTime", (eCookMode != eAI) ? (stCookingData.i16HeatingInterval - stCookingData.i16RemainingCookingTime) : stCookingData.i16HeatingInterval);
            json_object_dotset_number( pRecordObject, "params.cookingRecord.cookingEndTime", u64Timestamp );
            json_object_dotset_number( pRecordObject, "params.cookingRecord.cookingResult", eResult );
            json_object_set_number( pArrayObject, "remainTime", (eCookMode == eAI) ? 0 : stCookingData.i16RemainingCookingTime );
            json_object_set_number( pArrayObject, "actualExecutionTime", (eCookMode != eAI) ? (stCookingData.i16HeatingInterval - stCookingData.i16RemainingCookingTime) : stCookingData.i16HeatingInterval);

            if ( connectivityCheck() == false )
            {
                PRINT(DINF, "Network connection status : DISCONNECTED %s", "\n");
                asprintf(&uploadFileName, "/tmp/storage/%ld.json", u64Timestamp);
                PRINT(DINF, "File created on Cooking Record Folder : %d\n", json_serialize_to_file_pretty( pRecordValue, uploadFileName ));
                free(uploadFileName);
            } else {
                PRINT(DINF, "Network connection status : ALIVE %s", "\n");
	            COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), json_serialize_to_string_pretty( pRecordValue ), COOKING_UPSTREAM_ROUTE );
            }
        }
        break;
    }

    // json_object_clear( pArrayObject );
    // json_array_clear( pRecordArray );
    // json_object_clear( pRecordObject );
    json_value_free( pRecordValue );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_WRAPPER_fnStartTimer( void )
{
    if (!bTimerRegister) {
        signal( SIGALRM, watchdog );
        bTimerRegister = true;
    }

    bTimerHandler = true;
    alarm(1);
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_WRAPPER_fnStartCooking( void )
{
    PRINT(DINF, "Start Cooking Route Triggered %s", "\n");
    OVEN_WRAPPER_INTERFACE_fnStartCooking( getHandle(), COOKING_OUTPUT_ROUTE, stCookingData.i16HeatingPower, lCookingRecordId );

    /* Start the timer and stop heating after iHeatingInterval */
    COOKING_SERVICE_WRAPPER_fnStartTimer();
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_WRAPPER_fnStopCooking( void )
{
    PRINT(DINF, "Stop Cooking Route Triggered %s", "\n");
    bTimerHandler = false;
    // stCookingData.i16RemainingCookingTime = 0;
    OVEN_WRAPPER_INTERFACE_fnFinishHeating( getHandle(), COOKING_OUTPUT_ROUTE );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_WRAPPER_fnPauseCooking( void )
{
    PRINT(DINF, "Heating Pause Command Published to Oven Service %s", "\n");
    /* Store the current cooking stage snapshot in the structure ( Snapshot of Cooking Stage )*/
    /* Remaining Cooking Time will become the total cooking time for that stage when Resume Cooking is triggered */
    bTimerHandler = false;
    OVEN_WRAPPER_INTERFACE_fnPauseHeating( getHandle(), COOKING_OUTPUT_ROUTE );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_WRAPPER_fnResumeCooking( void )
{
    /* Resume Cooking triggered with previously saved Cooking Data Snapshot */
    PRINT(DINF, "Resume Cooking Command Publish to Oven Service %s", "\n");
    OVEN_WRAPPER_INTERFACE_fnResumeHeating( getHandle(), COOKING_OUTPUT_ROUTE, stCookingData.i16HeatingPower, lCookingRecordId );
    COOKING_SERVICE_WRAPPER_fnStartTimer();
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_fnSentResponse ( uint16_t u16Cmd, bool bStatus, char* cpCommand, char **deviceMethodResponse )
{
    JSON_Value *pResonseValue = json_value_init_object();
    JSON_Object *pResponseObject = json_value_get_object( pResonseValue );

    json_object_set_number(pResponseObject, "route_message_id", u16Cmd);
    if (cpCommand == NULL) {
        json_object_set_number(pResponseObject, "status", bStatus );
    } else {
        json_object_set_string(pResponseObject, "command", cpCommand);
    }
    json_object_set_number(pResponseObject, "timestamp", epochTimestamp());

    asprintf(*(&deviceMethodResponse), "%s", json_serialize_to_string_pretty(pResonseValue));
    json_object_clear( pResponseObject );
    json_value_free( pResonseValue );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int16_t COOKING_SERVICE_fnFuncSelection( eMethod_t eMethod, const unsigned char *pReceivedJsonMessage, unsigned char **response, size_t *response_size )
{
    int result, routeMessageId;
    bool statusFail = true;
    char *pAckResponse = NULL;

    JSON_Value *pRootValue = json_parse_string( (const char *)pReceivedJsonMessage );
    JSON_Object *pRootObject = json_value_get_object( pRootValue );

    routeMessageId = json_object_get_number( pRootObject, "route_message_id" );
    if ( routeMessageId == 0 )
        routeMessageId = json_object_get_number( pRootObject ,"routeMessageId" );
    else if ( routeMessageId == 0 )
        routeMessageId = json_object_get_number( pRootObject ,"msgid" );

    switch( routeMessageId )
    {
        case START_HEATING_MSG_ID:
        {
            bDiyEnable = false; bPwrEnable = false;
            if ( eMethod == eDirectMethod )
                stCookingData.i16HeatingPower = json_object_dotget_number( pRootObject, "params.value.power" );
            else
                stCookingData.i16HeatingPower = json_object_get_number( pRootObject, "power" );
            
            if ( stCookingData.i16HeatingPower > 0 ) {
                lCookingRecordId = record_id();
                OVEN_WRAPPER_INTERFACE_fnStartCooking( getHandle(), COOKING_OUTPUT_ROUTE, stCookingData.i16HeatingPower, lCookingRecordId );
                PRINT(DINF, "%s: Start Heating command executed successfully with %d Power\n", (!eMethod) ? "DIRECT": "ROUTE", stCookingData.i16HeatingPower);
                statusFail = false;
            } else {
                PRINT( DERR, "%s: Start Heating command failed, Heating Power : %d is not acceptable\n", (!eMethod) ? "DIRECT": "ROUTE", stCookingData.i16HeatingPower );
            }

            if ( eMethod == eDirectMethod )
            {
                COOKING_SERVICE_fnSentResponse(DIRECT_RES_START_HEATING, statusFail, NULL, &pAckResponse);
                char *deviceMethodResponse = pAckResponse;
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                free(pAckResponse);
            }

            result = (statusFail) ? RESULT_NOT_ACCEPTABLE : RESULT_OK;
            break;
        }
        case STOP_HEATING_MSG_ID:
        case DIY_STOP_COOKING_MSG_ID_NEW:
        // case PWR_STOP_COOKING_MSG_ID_NEW:
        {
            if ( eMethod == eDirectMethod && (!bDiyEnable || !bPwrEnable) )
            {
                OVEN_WRAPPER_INTERFACE_fnFinishHeating( getHandle(), COOKING_OUTPUT_ROUTE );
                PRINT(DINF, "DIRECT: Stop Cooking Triggered command executed successfully %s", "\n");

                COOKING_SERVICE_fnSentResponse(DIRECT_RES_STOP_HEATING, 0, NULL, &pAckResponse);
                char *deviceMethodResponse = pAckResponse;
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                free(pAckResponse);
            }
            else if ( eMethod == eRouteMethod && ( bPwrEnable || bDiyEnable) )
            {
                COOKING_SERVICE_WRAPPER_fnStopCooking();

                COOKING_SERVICE_fnSentResponse( (bDiyEnable) ? DIY_STOP_RESPONSE_MSG_ID_NEW : PWR_STOP_RESPONSE_MSG_ID_NEW, 0, NULL, &pAckResponse );
                COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), pAckResponse, COOKING_OUTPUT_ROUTE );
                free(pAckResponse);
                PRINT(DINF, "%s: Stop Cooking Triggered command executed successfully %s", (bDiyEnable) ? "DIY": "PWR", "\n");
            }
            else
            {
                OVEN_WRAPPER_INTERFACE_fnFinishHeating( getHandle(), COOKING_OUTPUT_ROUTE );
                PRINT(DINF, "ROUTE: Stop Cooking Triggered command executed successfully %s", "\n");
            }

            if ( bDiyEnable || bPwrEnable )
            {
                COOKING_SERVICE_fnUpdateCookingStatus( eCookingTerminated, eNoException,epochTimestamp() );
                COOKING_SERVICE_fnUpdateCookingRecord( eStopCooking, eResultTerminated, epochTimestamp() );
            }

            bDiyEnable = false;
            bPwrEnable = false;
            result = RESULT_OK;
            break;
        }
        case PAUSE_HEATING_MSG_ID:
        case DIY_PAUSE_COOKING_MSG_ID_NEW:
        // case PWR_PAUSE_COOKING_MSG_ID_NEW:
        {
            if ( bDiyEnable || bPwrEnable )
            {
                COOKING_SERVICE_WRAPPER_fnPauseCooking();
                PRINT(DINF, "%s: Pause Heating Triggered command executed successfully%s", (bDiyEnable) ? "DIY": "PWR", "\n");
                uint16_t u16CookedTime = (stCookingData.i16HeatingInterval - stCookingData.i16RemainingCookingTime);
                /* Remaining Cooking Time will become the total cooking time for that stage when Resume is triggered */
                PRINT(DINF, "%s: Total Cook Time: %d sec, Cooked Time: %d sec, Heating Power: %d \n", (bDiyEnable) ? "DIY": "PWR", stCookingData.i16HeatingInterval, u16CookedTime, stCookingData.i16HeatingPower );
                PRINT(DINF, "%s: Remaining Time: %d sec, Heating Power: %d \n", (bDiyEnable) ? "DIY": "PWR", stCookingData.i16RemainingCookingTime, stCookingData.i16HeatingPower );

                COOKING_SERVICE_fnUpdateCookingStatus( ePaused, eNoException, epochTimestamp() );
                COOKING_SERVICE_fnSentResponse( (bDiyEnable) ? DIY_PAUSE_RESPONSE_MSG_ID_NEW : PWR_PAUSE_RESPONSE_MSG_ID_NEW, 0, NULL, &pAckResponse );
                COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), pAckResponse, COOKING_OUTPUT_ROUTE );
                free(pAckResponse);
            }
            else
            {
                PRINT(DINF, "ROUTE: Pause Heating Triggered command executed successfully%s", "\n");
                OVEN_WRAPPER_INTERFACE_fnPauseHeating( getHandle(), COOKING_OUTPUT_ROUTE );
            }
        }
        break;
        case RESUME_HEATING_MSG_ID:
        case DIY_RESUME_COOKING_MSG_ID_NEW:
        // case PWR_RESUME_COOKING_MSG_ID_NEW:
        {
            lCookingRecordId = record_id();
            if ( bDiyEnable || bPwrEnable ) {
                COOKING_SERVICE_WRAPPER_fnResumeCooking();
                PRINT(DINF, "%s: Resume heating for remaining %d sec initiated\n", (bDiyEnable) ? "DIY": "PWR", stCookingData.i16RemainingCookingTime);

                COOKING_SERVICE_fnUpdateCookingStatus( eHeatingStarted, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
                COOKING_SERVICE_fnSentResponse( (bDiyEnable) ? DIY_RESUME_RESPONSE_MSG_ID_NEW : PWR_RESUME_RESPONSE_MSG_ID_NEW, 0, NULL, &pAckResponse );
                COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), pAckResponse, COOKING_OUTPUT_ROUTE );
                free(pAckResponse);
                PRINT(DINF, "%s: Resume Heating Triggered command executed successfully%s", (bDiyEnable) ? "DIY": "PWR", "\n");

            } else {
                OVEN_WRAPPER_INTERFACE_fnResumeHeating( getHandle(), COOKING_OUTPUT_ROUTE, stCookingData.i16HeatingPower, lCookingRecordId );
                PRINT(DINF, "ROUTE: Resume Heating Triggered command executed successfully%s", "\n");
            }
        }
        break;
        case START_DIY_COOKING_MSG_ID:
        case DIY_START_COOKING_MSG_ID_NEW:
            bDiyEnable = true;
        // case PWR_START_COOKING_MSG_ID_NEW:
        {
            lCookingRecordId = record_id();
            JSON_Array *pCookingInstructions = json_object_get_array(pRootObject, "cooking_instruction");

            JSON_Object *pInstruction = json_array_get_object( pCookingInstructions, 0 );
            stCookingData.i16HeatingPower = json_object_get_number( pInstruction ,"power" );
            stCookingData.i16HeatingInterval = json_object_get_number( pInstruction ,"heating_interval" );
            PRINT(DINF, "%s: Cooking started with Heating interval: %d sec, Heating Power: %d \n",(bDiyEnable) ? "DIY": "PWR",
                stCookingData.i16HeatingInterval, stCookingData.i16HeatingPower);

            if ( stCookingData.i16HeatingPower > 0 && stCookingData.i16HeatingInterval > 10 )
            {
                stCookingData.i16RemainingCookingTime = stCookingData.i16HeatingInterval;
                COOKING_SERVICE_WRAPPER_fnStartCooking();
                PRINT(DINF, "%s: Cooking Triggered command executed successfully%s", (bDiyEnable) ? "DIY": "PWR","\n");
                statusFail = false;
                // bPwrEnable = (!bDiyEnable) ? true: false;
                bPwrEnable = false;
                eCookMode = eDiy;

                // json_array_clear( pCookingInstructions );
                // json_object_clear( pInstruction );
            }
            else
            {
                PRINT(DERR, "%s: Cooking Triggered command failed with invalid cooking data%s", (bDiyEnable) ? "DIY": "PWR","\n");
                bDiyEnable = false;
                statusFail = true;
            }

            COOKING_SERVICE_fnSentResponse( (bDiyEnable) ? DIY_START_RESPONSE_MSG_ID_NEW : PWR_START_RESPONSE_MSG_ID_NEW, statusFail, NULL, &pAckResponse );
            COOKING_SERVICE_fnPublishMessageToRoute( getHandle(), pAckResponse, COOKING_OUTPUT_ROUTE );

            COOKING_SERVICE_fnUpdateCookingStatus( eHeatingStarted, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
            COOKING_SERVICE_fnUpdateCookingRecord( eStartCooking, eResultSuccessful, epochTimestamp() );
            free(pAckResponse);
        }
        break;
        case REGISTER_OVEN_STATUS_CB_MSG_ID:
        {
            int publishReportInterval;

            if ( eMethod == eDirectMethod )
                publishReportInterval = json_object_dotget_number( pRootObject, "params.interval" );
            else
                publishReportInterval = json_object_get_number( pRootObject, "interval" );

            if (publishReportInterval > 0) {
                statusFail = false;
                OVEN_WRAPPER_INTERFACE_fnRegisterMicrowavesOvenStatusCb( getHandle(), COOKING_OUTPUT_ROUTE, publishReportInterval );
                PRINT(DINF, "register_oven_status Triggered command executed successfully for Interval : %d \n", publishReportInterval );
            } else {
                PRINT(DERR, "register_oven_status command failed interval : %d is not acceptable\n", publishReportInterval);
            }

            if ( eMethod == eDirectMethod ) 
            {
                COOKING_SERVICE_fnSentResponse(DIRECT_RES_REG_STATUS_CB, statusFail, NULL, &pAckResponse);
                char *deviceMethodResponse = pAckResponse;
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                free(pAckResponse);
            }
            result = (statusFail) ? RESULT_NOT_ACCEPTABLE : RESULT_OK;
        }
        break;
        case UNREGISTER_OVEN_STATUS_CB_MSG_ID:
        {
            OVEN_WRAPPER_INTERFACE_fnUnRegisterMicrowavesOvenStatusCb( getHandle(), COOKING_OUTPUT_ROUTE );
            PRINT(DINF, "unregister_oven_status command executed successfully%s", "\n");

            if ( eMethod == eDirectMethod ) 
            {
                COOKING_SERVICE_fnSentResponse(DIRECT_RES_UNREG_STATUS_CB, 0, NULL, &pAckResponse);
                char *deviceMethodResponse = pAckResponse;
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                free(pAckResponse);
            }
            result = RESULT_OK;
        }
        break;
        case REGISTER_IR_MATRIX_SENSOR_DATA:
        {
            int publishReportInterval;

            if ( eMethod == eDirectMethod ) 
                publishReportInterval = json_object_dotget_number(pRootObject, "params.interval");
            else
                publishReportInterval = json_object_get_number( pRootObject, "interval" );

            if ( publishReportInterval > 0 ) {
                statusFail = false;
                OVEN_WRAPPER_INTERFACE_fnTurnOnThermalSensor( getHandle(), COOKING_OUTPUT_ROUTE );
                OVEN_WRAPPER_INTERFACE_RegisterIRSensorDataCB( getHandle(), COOKING_OUTPUT_ROUTE );
                PRINT(DINF, "Register Thermal Sensor Callback command executed successfully for Interval : %d \n", publishReportInterval );
            } else {
                PRINT(DERR, "Register Thermal Sensor Callback commnad failed interval %d not acceptable\n", publishReportInterval);
            }

            if ( eMethod == eDirectMethod )
            {
                COOKING_SERVICE_fnSentResponse(DIRECT_RES_REG_IR_CB, statusFail, NULL, &pAckResponse);
                char *deviceMethodResponse = pAckResponse;
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                free(pAckResponse);
            }
            result = (statusFail) ? RESULT_NOT_ACCEPTABLE : RESULT_OK;
        }
        break;
        case UNREGISTER_IR_MATRIX_SENSOR_DATA:
        {
            OVEN_WRAPPER_INTERFACE_UnRegisterIRSensorDataCB( getHandle(), COOKING_OUTPUT_ROUTE );
            PRINT(DINF, "Un-Register Thermal Sensor Callback command executed successfully%s", "\n");

            if ( eMethod == eDirectMethod )
            {
                COOKING_SERVICE_fnSentResponse(DIRECT_RES_UNREG_STATUS_CB, 0, NULL, &pAckResponse);
                char *deviceMethodResponse = pAckResponse;
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
                free(pAckResponse);
            }
            result = RESULT_OK;
        }
        break;
        case DOOR_OPEN_DIY_PAUSE_CMD:
        {
            if ( (json_object_get_number( pRootObject, "CookingState")) == DOOR_OPEN_DIY_PAUSE && (bDiyEnable || bPwrEnable) )
            {
                COOKING_SERVICE_fnUpdateCookingStatus( ePaused, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );

                bDoorOpened = true;
                bTimerHandler = false;
                uint16_t u16CookedTime = (stCookingData.i16HeatingInterval - stCookingData.i16RemainingCookingTime);
                PRINT(DINF, "Door opened while cooking, command received%s", "\n");
                PRINT(DINF, "%s: Total Cook Time: %d sec, Cooked Time: %d sec, Heating Power: %d \n", (bDiyEnable) ? "DIY": "PWR", stCookingData.i16HeatingInterval, u16CookedTime, stCookingData.i16HeatingPower );
                PRINT(DINF, "%s: Remaning Time: %d sec, Heating Power: %d \n", (bDiyEnable) ? "DIY": "PWR", stCookingData.i16RemainingCookingTime, stCookingData.i16HeatingPower );
            }
        }
        break;
        case DOOR_STATUS_MSG_ID:
        {
            bDoorOpened = json_object_dotget_number(pRootObject, "data.door_state");
            if ( bPrevDoor != bDoorOpened )
            {
                PRINT(DINF, "Door status : %s\n", (bDoorOpened) ? "Opened" : "Closed");
                bPrevDoor = bDoorOpened;
            }
        }
        break;
        case START_AI_COOKING:
        {
            eCookMode = eAI;
            lCookingRecordId = json_object_dotget_number(pRootObject, "params.cooking_id");
            PRINT(DINF, "cooking ID : %d\n", json_object_dotget_number(pRootObject, "params.cooking_id"));
            PRINT(DINF, "food ID    : %s\n", json_object_dotget_string(pRootObject, "params.food_id"));
            bPwrEnable = false;
            bDiyEnable = false;

            COOKING_SERVICE_fnUpdateCookingStatus( eHeatingStarted, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
            COOKING_SERVICE_fnUpdateCookingRecord( eStartCooking, eResultSuccessful, epochTimestamp() );
        }
        break;
        case START_SMART_COOKING:
        {
            // COOKING_SERVICE_WRAPPER_fnStartTimer();
            lCookingRecordId = json_object_dotget_number(pRootObject, "params.cooking_id");
            PRINT(DINF, "cooking ID : %d\n", json_object_dotget_number(pRootObject, "params.cooking_id"));
            JSON_Array *pCookingStages = json_object_dotget_array(pRootObject, "params.cooking_stages");
            JSON_Object *pStage = json_array_get_object( pCookingStages, 0 );

            eCookMode = (uint8_t)json_object_get_number(pStage, "mode");
            stCookingData.i16HeatingInterval = json_object_get_number(pStage, "duration");

            PRINT(DINF, "cooking Mode : %d\n", eCookMode);
            PRINT(DINF, "cooking Duration : %d\n", stCookingData.i16HeatingInterval);
            stCookingData.i16RemainingCookingTime = stCookingData.i16HeatingInterval;

            bPwrEnable = true;
            bDiyEnable = false;

            COOKING_SERVICE_fnUpdateCookingStatus( eHeatingStarted, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
            COOKING_SERVICE_fnUpdateCookingRecord( eStartCooking, eResultSuccessful, epochTimestamp() );
        }
        break;
        case PAUSE_AI_SMART_COOKING:
        {
            bTimerHandler = false;
            COOKING_SERVICE_fnUpdateCookingStatus( ePaused, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
        }
        break;
        case RESUME_AI_SMART_COOKING:
        {
            if (eCookMode != eAI)
            {
                COOKING_SERVICE_WRAPPER_fnStartTimer();
            }
            COOKING_SERVICE_fnUpdateCookingStatus( eHeatingStarted, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
        }
        break;
        case STOP_AI_SMART_COOKING:
        {
            bTimerHandler = false;
            COOKING_SERVICE_fnUpdateCookingStatus( eCookingTerminated, (bDoorOpened ) ? eHeatingStatedwithDoorOpen : eNoException, epochTimestamp() );
            COOKING_SERVICE_fnUpdateCookingRecord( eStopCooking, eResultTerminated, epochTimestamp() );
        }
        break;
        default:
        {
            if ( eMethod == eDirectMethod )
            {
                char *deviceMethodResponse = "{\"Response\" : \"ID Missing or Invalid\"}";
                *response_size = strlen(deviceMethodResponse);
                *response = (unsigned char *)malloc(*response_size);
                (void)memcpy(*response, deviceMethodResponse, *response_size);
            }
            PRINT(DERR, "ID <%d> Missing or Invalid%s", routeMessageId, "\n");
            result = RESULT_BAD_REQUEST;
        }
    }
    json_object_clear( pRootObject );
    json_value_free( pRootValue );
    return result;
}

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/
