/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      cooking_service.h
 * @brief     Common header for cooking services
 * @author    Vijayapradap M
 * @version   1.0
 * @date      July 12, 2024
 *
 ******************************************************************************
 */

#ifndef COOKING_COMMON_MODULE_H_
#define COOKING_COMMON_MODULE_H_

/*==============================================================================
                              System Includes
==============================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "iothub_module_client_ll.h"
#include "iothub_client_options.h"
#include "iothub_device_client_ll.h"
#include "iothub_device_client.h"
#include "iothub_message.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "iothubtransportmqtt.h"
#include "iothub_client_core_common.h"
#include "iothub.h"
#include "time.h"
#include <sys/time.h>
/*==============================================================================
                              Project Includes
==============================================================================*/
#include "parson.h"
/*==============================================================================
                              Exported Defines
==============================================================================*/

#define DERR "ERROR"
#define DINF "INFO"
#define DWAR "WARN"
#define DDBG "DEBUG"

#define TIMESTAMP_FORMAT "%Y-%m-%d %H:%M:%S.%03d"
#define UUID_LEN 32

extern char xDeviceUUID[UUID_LEN];

/* Macro to log for debugging purposes */
// #define PRINT(LEVEL, FORMAT, ...) do { \
//     time_t now;  time(&now); \
//     char* timestamp = ctime(&now); \
//     timestamp[strlen(timestamp) - 1] = '\0'; \
//     printf("%s : %s %s() in %s, line %i:\t" FORMAT, \
//     LEVEL, timestamp, __func__, __FILE__, __LINE__, __VA_ARGS__); \
//     fflush(stdout); } while(0);

#define PRINT(LEVEL, FORMAT, ...) do { \
    time_t now = time(NULL); char timestamp[24]; \
    struct tm *tm_info = localtime(&now); \
    if ( xDeviceUUID[0] == '\0' ) getDeviceUUID(); \
    strftime(timestamp, sizeof(timestamp), TIMESTAMP_FORMAT, tm_info); \
    printf("%s %*s-{deviceId:%s} - %s(%i) - " FORMAT, \
    timestamp, -5, LEVEL, xDeviceUUID, __func__, __LINE__, __VA_ARGS__); \
    fflush(stdout); } while(0);

/*==============================================================================
                              Exported Macros
==============================================================================*/

// #define RESULT_OK                   200
// #define RESULT_PARTIAL_CONTENT      206
// #define RESULT_BAD_REQUEST          400
// #define RESULT_METHOD_NOT_ALLOWED   405
// #define RESULT_NOT_ACCEPTABLE       406

#define RESULT_OK 200
#define RESULT_PARTIAL_CONTENT -1
#define RESULT_BAD_REQUEST -1
#define RESULT_METHOD_NOT_ALLOWED -1
#define RESULT_NOT_ACCEPTABLE -1

#define START_HEATING_MSG_ID 201
#define REGISTER_OVEN_STATUS_CB_MSG_ID 203
#define UNREGISTER_OVEN_STATUS_CB_MSG_ID 205
#define DOOR_STATUS_MSG_ID 208
#define STOP_HEATING_MSG_ID 210
#define REGISTER_IR_MATRIX_SENSOR_DATA 212
#define UNREGISTER_IR_MATRIX_SENSOR_DATA 214
#define PAUSE_HEATING_MSG_ID 217
#define RESUME_HEATING_MSG_ID 219
#define START_DIY_COOKING_MSG_ID 221
#define OVEN_STATUS_DATA_REQ 227
#define OVEN_STATUS_DATA_RES 228
#define DOOR_OPEN_DIY_PAUSE_CMD 299
#define DOOR_OPEN_DIY_PAUSE 2

#define DIY_START_COOKING_MSG_ID_NEW 331
#define DIY_START_RESPONSE_MSG_ID_NEW 332
#define DIY_PAUSE_COOKING_MSG_ID_NEW 333
#define DIY_PAUSE_RESPONSE_MSG_ID_NEW 334
#define DIY_RESUME_COOKING_MSG_ID_NEW 335
#define DIY_RESUME_RESPONSE_MSG_ID_NEW 336
#define DIY_STOP_COOKING_MSG_ID_NEW 337
#define DIY_STOP_RESPONSE_MSG_ID_NEW 338

#define PWR_START_COOKING_MSG_ID_NEW 441
#define PWR_START_RESPONSE_MSG_ID_NEW 442
#define PWR_PAUSE_COOKING_MSG_ID_NEW 443
#define PWR_PAUSE_RESPONSE_MSG_ID_NEW 444
#define PWR_RESUME_COOKING_MSG_ID_NEW 445
#define PWR_RESUME_RESPONSE_MSG_ID_NEW 446
#define PWR_STOP_COOKING_MSG_ID_NEW 447
#define PWR_STOP_RESPONSE_MSG_ID_NEW 448

#define DIRECT_RES_START_HEATING 202
#define DIRECT_RES_STOP_HEATING 211
#define DIRECT_RES_REG_STATUS_CB 204
#define DIRECT_RES_UNREG_STATUS_CB 206
#define DIRECT_RES_REG_IR_CB 213
#define DIRECT_RES_UNREG_IR_CB 215

#define START_AI_COOKING 1201
#define START_SMART_COOKING 601
#define PAUSE_AI_SMART_COOKING 1203
#define RESUME_AI_SMART_COOKING 1205
#define STOP_AI_SMART_COOKING 1207

#define COOKING_TYPE_DIY 3
#define COOKING_TYPE_PWR 6
#define COOKING_TYPE_AI 7

/* Route at which cooking service reads the messages published from other modules */
#define COOKING_INPUT_ROUTE "cooking_service_in"

/* Route at which cooking service publishes the messages to other Modules */
#define COOKING_OUTPUT_ROUTE "cooking_service_out"

/* cooking service method name to communicate through direct method  */
#define COOKING_DIRECT_METHOD "methodCookingService"

/* Route at which cooking service publishes the messages to stream */
#define COOKING_UPSTREAM_ROUTE "cooking_service_upstream"

/*==============================================================================
                              Exported Enums
==============================================================================*/

typedef enum {
    eDirectMethod,
    eRouteMethod
} eMethod_t;

typedef enum {
    eStartCooking,
    eStopCooking,
    eDoneCooking
} eState_t;

typedef enum {
    eResultFailed,
    eResultSuccessful,
    eResultTerminated,
    eResultInprogress
} eResult_t;

typedef enum {
    eDiy,
    eThawing,
    eLowHeat,
    eMediumTemp,
    eMediumHighTemp,
    eHighTemp,
    eAI
} eCookMode_t;

typedef enum {
    eNotHeating,
    eHeatingStarted,
    eHeatingCompleted,
    eAbnormal,
    eCookingTerminated,
    ePaused
} eHeatStat_t;

typedef enum {
    eNoException,
    eHeatingInProgress,
    eHeatingStatedwithDoorOpen,
    eHardwareFailure
} eHeatCode_t;

/*==============================================================================
                              Exported Structures
==============================================================================*/

typedef struct {
    int16_t i16HeatingPower;
    int16_t i16HeatingInterval;
    volatile int16_t i16RemainingCookingTime;
} stCookingData_t;

/*==============================================================================
                              Exported functions prototypes
==============================================================================*/
/*!
 * @brief               This function for get device UUID
 *
 * @param[in]           void - nothing
 *
 * @retval success      void - nothing
 */
void getDeviceUUID( void );

/*!
 * @brief               This function for get current epoch timestamp
 *
 * @param[in]           void - nothing
 *
 * @retval success      returns current epoch timestamp value
 */
uint64_t epochTimestamp(void);

/*!
 * @brief               This function for get iothub client handle
 *
 * @param[in]           void - nothing
 *
 * @retval success      returns IOTHUB_MODULE_CLIENT_LL_HANDLE structure
 */
IOTHUB_MODULE_CLIENT_LL_HANDLE getHandle( void );

/*!
 * @brief               This function return connection availability
 *
 * @param[in]           void - nothing
 *
 * @retval success      returns true if connection alive, false connection dead
 */
bool connectionAlive( void );

/*!
 * @brief               This function upload offline cooking records
 *
 * @param[in]           void - nothing
 *
 * @retval none         void - nothing
 */
void COOKING_SERVICE_fnUploadOfflineRecord( void );

/*!
 * @brief               This function for publish the given data to given route
 *
 * @param[in]           IOTHUB_MODULE_CLIENT_LL_HANDLE - structure
 * @param[in]           pJsonMessage - data need to be published through route
 * @param[in]           pOutputRoute - route path to publish
 *
 * @retval @link        returns IOTHUBMESSAGE_DISPOSITION_RESULT enumeration
 */
IOTHUBMESSAGE_DISPOSITION_RESULT COOKING_SERVICE_fnPublishMessageToRoute(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle, const char *pJsonMessage, const char *pOutputRoute);

/*!
 * @brief               This function for controls all cooking selection and execution
 *
 * @param[in]           eMethod_t - enum parameter for select the method / route
 * @param[in]           pReceivedJsonMessage - data from callback from route / direct method
 * @param[out]          response - return data or reponse for direct method
 * @param[out]          resonse_size - return data or response size for direct method
 *
 * @retval 200          Operation success
 * @retval -1           Operation failed
 */
int16_t COOKING_SERVICE_fnFuncSelection( eMethod_t eMethod, const unsigned char *pReceivedJsonMessage, unsigned char **response, size_t *response_size );

/*==============================================================================
                              Footer
==============================================================================*/

#endif /* COOKING_COMMON_MODULE_H_ */

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/