/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 * @file      main.c
 * @brief     This module is responsible for cooking service 
 * @author    Vijayapradap M
 * @version   1.0
 * @date      July 12 , 2024
 *
 ******************************************************************************
 */

/*==============================================================================
                              System Includes
==============================================================================*/

/*=============================================================================
                              Project Includes
==============================================================================*/

#include "cooking_service.h"

/*==============================================================================
                              Private Includes
==============================================================================*/

/*=============================================================================
                              Private Macros
==============================================================================*/

/*==============================================================================
                              External/Public Variables
==============================================================================*/

char xDeviceUUID[UUID_LEN];

/*==============================================================================
                              Static Variables
==============================================================================*/

static IOTHUB_MODULE_CLIENT_LL_HANDLE gIotHubModuleHandle;

/*==============================================================================
                              Static Functions
==============================================================================*/

static void COOKING_SERVICE_fnDeInitializeConnection( void );
static int COOKING_SERVICE_fnSetupCallbacksForModule( void );
static int COOKING_SERVICE_fnSetupCallbackForDirectMethod( void );
static IOTHUB_MODULE_CLIENT_LL_HANDLE COOKING_SERVICE_fnInitializeConnection( void );
static void COOKING_SERVICE_fnSendConfirmationCb( IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback );
static IOTHUBMESSAGE_DISPOSITION_RESULT COOKING_SERVICE_fnReceiveMessageProcessCb(IOTHUB_MESSAGE_HANDLE message, 
    void* userContextCallback );
static int COOKING_SERVICE_fnModuleDirectMethodCb( const char *method_name, const unsigned char *payload, size_t size, 
    unsigned char **response, size_t *response_size, void *userContextCallback);

/*==============================================================================
                              DEFINE Functions
==============================================================================*/

/*==============================================================================
                              Local Function Prototypes
==============================================================================*/

void getDeviceUUID( void ) {

    JSON_Value* pDeviceValue = json_parse_file("/var/tmp/dps_config.json");

    if ( pDeviceValue == NULL) {
        strcpy( xDeviceUUID, "xyz_device_id" );
        PRINT(DERR, "unable to read the deviceUuid%s", "\n");
    } else {
        JSON_Object* pDeviceObject = json_value_get_object( pDeviceValue );
        strncpy( xDeviceUUID, json_object_get_string( pDeviceObject,"registration_id" ), UUID_LEN );
        json_value_free( pDeviceValue );
    }
}
/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
IOTHUB_MODULE_CLIENT_LL_HANDLE getHandle( void ) {
    return gIotHubModuleHandle;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_fnSendConfirmationCb( IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback )
{
    (void)userContextCallback;
    // IOTHUB_MESSAGE_HANDLE *messageInstance = (IOTHUB_MESSAGE_HANDLE *)userContextCallback;
    PRINT(DINF, "Acknowledgement Recieved for Publishing message with result = %d\r\n", result);
    /* Frees all resources associated with the given message handle */
    // IoTHubMessage_Destroy( messageInstance );
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
IOTHUBMESSAGE_DISPOSITION_RESULT COOKING_SERVICE_fnPublishMessageToRoute(IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle, const char *pJsonMessage, const char *pOutputRoute)
{
    IOTHUB_CLIENT_RESULT ePublishMessageStatus;
    IOTHUB_MESSAGE_HANDLE publishMessageHandle, pPublicMessageHandle;
    
    if (pJsonMessage == NULL)
        return IOTHUB_CLIENT_ERROR;

    /* Creates a new IoT hub message from a null terminated string. */
    publishMessageHandle = IoTHubMessage_CreateFromString( pJsonMessage );
    // pPublicMessageHandle = (IOTHUB_MESSAGE_HANDLE *) malloc (sizeof(IOTHUB_MESSAGE_HANDLE));
    pPublicMessageHandle = IoTHubMessage_Clone(publishMessageHandle);

    if ( iotHubModuleClientHandle != NULL )
    {
        if (pPublicMessageHandle == NULL )
        {
            ePublishMessageStatus = IOTHUB_CLIENT_ERROR;
        }
        else
        {
            /* Returns Enumeration specifying the status of calls to IoT Hub client. */
            ePublishMessageStatus = IoTHubModuleClient_LL_SendEventToOutputAsync( iotHubModuleClientHandle, pPublicMessageHandle, 
                pOutputRoute, COOKING_SERVICE_fnSendConfirmationCb, (void *)pPublicMessageHandle);
            
            if ( ePublishMessageStatus != IOTHUB_CLIENT_OK )
            {
                IoTHubMessage_Destroy(pPublicMessageHandle);
                PRINT(DERR, "failed to publish message on Route : %d : %s \n",ePublishMessageStatus, pOutputRoute );
            }
            else
            {
                PRINT(DINF, "Published Message on Route : <'%s'> Successfully \n \n\n", pJsonMessage );
            }
        }
    }
    else
    {
        PRINT(DERR, "Invalid Client handle%s", "\n");
    }

    return ePublishMessageStatus;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int COOKING_SERVICE_fnModuleDirectMethodCb(const char *method_name, const unsigned char *payload, size_t size, unsigned char **response, size_t *response_size, void *userContextCallback) 
{
    (void)userContextCallback;
    int result = 0;

    if ( (strcmp( (char *)COOKING_DIRECT_METHOD, method_name) == 0) ) {
        result = COOKING_SERVICE_fnFuncSelection(eDirectMethod, payload, response, response_size);
    } else {

        JSON_Value *pResonseValue = json_value_init_object();
        JSON_Object *pResponseObject = json_value_get_object(pResonseValue);

        PRINT(DERR,"method name / command missing / invalid !!%s", "\r\n");
        json_object_set_string(pResponseObject, "Response", "Method name / Command Missing or Invalid");
        result = RESULT_METHOD_NOT_ALLOWED;

        char *deviceMethodResponse = json_serialize_to_string_pretty(pResonseValue);
        *response_size = strlen(deviceMethodResponse);
        *response = (unsigned char *)malloc(*response_size);
        (void)memcpy(*response, deviceMethodResponse, *response_size);

        json_value_free(pResonseValue);
    }
    return result;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static IOTHUBMESSAGE_DISPOSITION_RESULT COOKING_SERVICE_fnReceiveMessageProcessCb(IOTHUB_MESSAGE_HANDLE message, void* userContextCallback)
{
    IOTHUBMESSAGE_DISPOSITION_RESULT result;
    IOTHUB_CLIENT_RESULT clientResult;
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle = (IOTHUB_MODULE_CLIENT_LL_HANDLE)userContextCallback;

    unsigned const char* messageBody;
    size_t contentSize;

    if (IoTHubMessage_GetByteArray(message, &messageBody, &contentSize) != IOTHUB_MESSAGE_OK)
    {
        messageBody = "<null>";
        result = IOTHUBMESSAGE_ABANDONED;
        goto exit;
    }
    else
    {
        PRINT(DINF, "Received Message Data: [%s]\r\n", messageBody);
    }

    if( messageBody != NULL )
    {
        COOKING_SERVICE_fnFuncSelection( eRouteMethod, messageBody, NULL, &contentSize );
        result = IOTHUBMESSAGE_ACCEPTED;
    }
    else
    {
        PRINT(DERR, "Recieved Message is an Empty String !!!%s", "\n");
        result = IOTHUBMESSAGE_ABANDONED;
    }
exit:
    return result;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_fnConnectionStatusCb(IOTHUB_CLIENT_CONNECTION_STATUS result, IOTHUB_CLIENT_CONNECTION_STATUS_REASON reason, void* user_context)
{
	(void)user_context;
	if (result == IOTHUB_CLIENT_CONNECTION_AUTHENTICATED )
	{
		PRINT(DINF, "The device client is connected with edgeHub/edgeAgent (Status : %s)\n", MU_ENUM_TO_STRING(IOTHUB_CLIENT_CONNECTION_STATUS_REASON, reason));

        // COOKING_SERVICE_fnUploadOfflineRecord();
	}
	else
	{
        PRINT(DINF, "The device client has been disconnected with edgeHub/edgeAgent (Reason : %s)\n", MU_ENUM_TO_STRING(IOTHUB_CLIENT_CONNECTION_STATUS_REASON, reason));
	}
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static IOTHUB_MODULE_CLIENT_LL_HANDLE COOKING_SERVICE_fnInitializeConnection()
{
    IOTHUB_MODULE_CLIENT_LL_HANDLE iotHubModuleClientHandle;

    if (IoTHub_Init() != 0)
    {
        PRINT(DERR, "Failed to initialize the platform%s", "\n");
        iotHubModuleClientHandle = NULL;
    }
    else if ((iotHubModuleClientHandle = IoTHubModuleClient_LL_CreateFromEnvironment(MQTT_Protocol)) == NULL)
    {
        PRINT(DERR, "IoTHubModuleClient_LL_CreateFromEnvironment failed%s", "\n");
    }
    else
    {
        // bool traceOn = true;
        // IoTHubModuleClient_LL_SetOption(iotHubModuleClientHandle, OPTION_LOG_TRACE, &traceOn);
    }

    return iotHubModuleClientHandle;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static void COOKING_SERVICE_fnDeInitializeConnection( void )
{
    if (gIotHubModuleHandle != NULL)
    {
        IoTHubModuleClient_LL_Destroy(gIotHubModuleHandle);
    }
    IoTHub_Deinit();
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int COOKING_SERVICE_fnSetupCallbacksForModule( void )
{
    if (IoTHubModuleClient_LL_SetInputMessageCallback( gIotHubModuleHandle, COOKING_INPUT_ROUTE, COOKING_SERVICE_fnReceiveMessageProcessCb, (void*)gIotHubModuleHandle) != IOTHUB_CLIENT_OK )
    {
        PRINT(DERR, "IoTHubModuleClient_LL_SetInputMessageCallback failed%s", "\n");
        return 1;
    }
    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int COOKING_SERVICE_fnSetupCallbackForDirectMethod( void )
{
    if (IoTHubModuleClient_LL_SetModuleMethodCallback( gIotHubModuleHandle, COOKING_SERVICE_fnModuleDirectMethodCb, NULL ) != IOTHUB_CLIENT_OK)
    {
        PRINT(DERR, "IoTHubModuleClient_LL_SetModuleMethodCallback failed%s", "\n");
        return 1;
    }
    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
static int COOKING_SERVICE_fnSetupCallbackforConnectionStatus( void )
{
    if (IoTHubModuleClient_LL_SetConnectionStatusCallback( gIotHubModuleHandle, COOKING_SERVICE_fnConnectionStatusCb, NULL ) != IOTHUB_CLIENT_OK)
    {
        PRINT(DERR, "IoTHubDeviceClient_SetConnectionStatusCallback failed%s", "\n");
        return 1;
    }
    return 0;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int COOKING_SERVICE_fnIotHubInitHandler(void *argv)
{
    (void)argv;

    srand((unsigned int)time(NULL));

    if ( (gIotHubModuleHandle = COOKING_SERVICE_fnInitializeConnection()) == NULL ) {
        PRINT(DERR, "IoTHub module client Initialization getting failed%s","\n\n");
        return THREADAPI_ERROR;
    }
    PRINT(DINF, "IoTHub module client Initialized successfully%s", "\n\n");

    if( COOKING_SERVICE_fnSetupCallbacksForModule() != 0 ) {
        PRINT(DERR, "setting module callback getting failed%s","\n\n");
        goto exit;
    }
    PRINT(DINF, "IoTHub module callback registered successfully%s", "\n\n");

    if( COOKING_SERVICE_fnSetupCallbackForDirectMethod() != 0 ) {
        PRINT(DERR, "setting direct method callback getting failed%s","\n\n");
        goto exit;
    }
    PRINT(DINF, "IoTHub direct method callback registered successfully%s", "\n\n");

    // if ( COOKING_SERVICE_fnSetupCallbackforConnectionStatus() != 0 ) {
    //     PRINT(DERR, "setting connection status callback getting failed%s","\n\n");
    //     goto exit;
    // }
    // PRINT(DINF, "IoTHub connection status callback registered successfully%s", "\n\n");
    PRINT(DINF, "Waiting for incoming messages %s", "\n\n");
    
    int beat = 0, upload = 0;
    while (true)
    {
        if( beat++ > 1000 ) {
            PRINT(DINF, "Waiting for incoming messages %s", "\n\n");
            beat = 0;
        }

        if( upload++ > 10 ) {
            COOKING_SERVICE_fnUploadOfflineRecord();
            upload = 0;
        }

        IoTHubModuleClient_LL_DoWork(gIotHubModuleHandle);
        ThreadAPI_Sleep(200);
    }

exit:
    COOKING_SERVICE_fnDeInitializeConnection();
    PRINT(DINF, "IoTHub module client Deinitializated successfully%s","\n\n");
    return THREADAPI_OK;
}

/*
 *****************************************************************************************
 * See header file for function definition.
 *****************************************************************************************
 */
int main(void)
{
    THREAD_HANDLE stModuleHandle;

    if ( ThreadAPI_Create ( &stModuleHandle, COOKING_SERVICE_fnIotHubInitHandler, NULL ) != THREADAPI_OK ) {
        PRINT(DERR, "Creating thread getting failed%s", "\n");
    }

    ThreadAPI_Join(stModuleHandle, NULL);
    return 0;
}

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/