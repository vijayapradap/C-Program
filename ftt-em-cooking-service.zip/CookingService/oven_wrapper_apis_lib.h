/**
 *
 * @copyright (c) 2023 Eaden Technology Pte Ltd. All rights reserved.
 * All trademarks are owned or licensed by Eaden Technology Pte Ltd,
 * its subsidiaries or affiliated companies.
 *
 ******************************************************************************
 *
 * @file      oven_wrapper_apis_lib.h
 * @brief     This header file contains functions to be exposed to Intelligent Cooking or other modules to trigger actions on Oven.
 * @version   1.0
 *
 ******************************************************************************
 */

#ifndef OVEN_WRAPPER_INTERFACE_H_
#define OVEN_WRAPPER_INTERFACE_H_

/*==============================================================================
                              System Includes
==============================================================================*/

/*==============================================================================
                              Project Includes
==============================================================================*/
#include "azure_iot_lib.h"
/*==============================================================================
                              Exported Defines
==============================================================================*/

/*==============================================================================
                              Exported Macros
==============================================================================*/

/*==============================================================================
                              Exported Enums
==============================================================================*/

/*==============================================================================
                              Exported Structures
==============================================================================*/

/*==============================================================================
                              Exported functions prototypes
==============================================================================*/
/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/   
void OVEN_WRAPPER_INTERFACE_fnStartHeating( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                            const char *pOutputRoute, int HeatingPower,long lCookingId );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnStopHeating(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnPause( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnResumeHeating(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute, int HeatingPower, long CookingId);

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/
void OVEN_WRAPPER_INTERFACE_fnPauseHeating(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/
void OVEN_WRAPPER_INTERFACE_fnStartCooking( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute, int HeatingPower,long CookingId );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterMicrowavesOvenStatusCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                        const char *pOutputRoute, int publishInterval );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnUnRegisterMicrowavesOvenStatusCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterOvenFaultDataCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnUnRegisterOvenFaultDataCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );


/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOnFan( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOffFan( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnPauseFan(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/
void OVEN_WRAPPER_INTERFACE_fnTurnOnFanForResumeHeat( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/
void OVEN_WRAPPER_INTERFACE_fnOffLightFanForFinishHeat(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );


void OVEN_WRAPPER_INTERFACE_fnFinishHeating(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );
/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnStartExaustFan(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );
/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOffFanOnHeatingCompletion(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOnMotor(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOffMotor(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOnLight(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOffLight(  IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnInitFocalTasteSensor( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterBurntSmellCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnUnRegisterBurntSmellCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnInitEnvTemperatureSensor( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                        const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterEnvTemperatureReportCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnUnRegisterEnvTemperatureReportCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnInitInnerCavityTemperature( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterInnerCavityTemperatureCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                                const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnUnRegisterInnerCavityTemperatureCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                                const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnInitBarcodeScanner( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterBarcodeScannerListenerCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnUnRegisterBarcodeScannerListenerCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOnThermalSensor( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                    const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnTurnOffThermalSensor( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                    const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_fnRegisterIRThermalSensorDataCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle,
                                                                 const char *pOutputRoute, int publishInterval );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/  
void OVEN_WRAPPER_INTERFACE_fnUnRegisterIRThermalSensorDataCb( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, 
                                                                                            const char *pOutputRoute );


/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_RegisterIRSensorDataCB( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*!

@brief      <b>  </b>
@param[in]  None

@retval     

*/ 
void OVEN_WRAPPER_INTERFACE_UnRegisterIRSensorDataCB( IOTHUB_MODULE_CLIENT_LL_HANDLE moduleClientHandle, const char *pOutputRoute );

/*==============================================================================
                              Footer
==============================================================================*/

#endif /* OVEN_WRAPPER_INTERFACE_H_ */

/************ (C) COPYRIGHT (c) 2023 Eaden Technology Pte Ltd *********END OF FILE****/
