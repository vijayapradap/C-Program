# Cooking Service Module

## Overview
The Cooking Service module is designed to control cooking support hardware, such as turning on/off the magnetron and fan, etc. It is an Azure IoT Edge module that maintains a continuous connection with the Azure cloud. Cooking service collecting and maintaining three modes of cooking status and records.

1. **DIY Cooking (Do It Yourself):**
   - In this mode, users manually set cooking parameters such as time, power level, and specific instructions.
   - DIY cooking allows flexibility and creativity, as users can experiment with their own recipes and preferences.
   - The Cooking Service records the user-defined settings and cooking duration for future reference.

2. **Smart Cooking (Temperature-Based Cooking):**
   - Smart cooking relies on temperature sensors and predefined cooking profiles.
   - Users select a dish or food type (e.g., pizza, chicken, vegetables), and the Cooking Service adjusts cooking parameters automatically.
   - Temperature-based cooking ensures consistent results by adapting to the specific food being prepared.

3. **AI Cooking (Artificial Intelligent Cooking):**
   - AI cooking takes automation to the next level.
   - The Cooking Service uses machine learning algorithms to analyze data from various sensors (temperature, humidity, etc.).
   - Based on historical data and real-time conditions, it optimizes cooking settings dynamically.
   - AI cooking aims for precision, energy efficiency, and superior taste.
## Functionlity of Cooking Service:

1. **Functionality:**
   - The Cooking Service module handles hardware control during cooking.
   - Even in DIY mode, it manages hardware based on time and power input, ensuring safe operation.
   - When the timer expires, it turns off all hardware components.

2. **Data Transmission:**
   - When connected to the internet, the Cooking Service sends cooking records and relevant data (such as topsea data) to the cloud.
   - It ensures seamless data synchronization with the cloud for analysis and monitoring.

3. **Offline Mode:**
   - In cases of internet unavailability, the Cooking Service stores all records in an offline datastore.
   - Once internet connectivity is restored, it uploads the stored data to the cloud without fail.

4. **JSON Data Format:**
   - The Cooking Service provides data in JSON format, including cooking status and records.
   - You can refer to the accompanying document [万得厨2.0-DW223 - Azure云边通迅协议（Azure Cloud-to-Edge Communication Protocol)](https://dev.azure.com/FTTTEC/a6ce8df8-e6fc-43ce-a715-07745b6d685b/_apis/git/repositories/a2b5b5d7-6720-45fb-ac8f-3cf293147bbe/Items?path=/.attachments/%E4%B8%87%E5%BE%97%E5%8E%A82.0-DW223%20-%20Azure%E4%BA%91%E8%BE%B9%E9%80%9A%E8%BF%85%E5%8D%8F%E8%AE%AE%EF%BC%88Azure%20Cloud-to-Edge%20Communication%20Protocol%EF%BC%89-v27-20240531-415337a2-b770-456d-b8b0-172da7747b89.pdf&download=false&resolveLfs=true&%24format=octetStream&api-version=5.0-preview.1&sanitize=true&includeContentMetadata=true&versionDescriptor.version=wikiMaster) for detailed information on the JSON structure.

```sh
Report Device Heating and Cooking Status:
{
    "msgType": "rpc",
    "msgId": "be0e673667364c3f8bc31df5338a948a",
    "timestamp": 1604396382112,
    "deviceUuid": "5103c97f33fa4dd79c6c57f4beca3e3e",
    "businessName": "hwm",
    "command": "device_status",
    "params": {
        "start_timestamp": 1716344206344,
        "end_timestamp": 1716344209200,
        "heat_stat": 1,
        "heat_code": 0,
        "door_stat": 0,
        "cooking_record_id": 875532121263727600,
        "nfc_tag": "userQrcodeIdentity",
        "nfc_user_id": 1716344206344999,
        "heat_temp": [
            {
                "heat_realtime": 1,
                "inside_temp": "null",
                "stage": "0"
            },
            {
                "heat_realtime": 120,
                "inside_temp": "null",
                "stage": "1"
            }
        ]
    },
    "topsea": {
        "organization": {
            "id": "xxx",
            "name": "xxx"
        },
        "person": {
            "id": "xxx",
            "name": "xxx"
        },
        "elements": [
            {
                "elementType": "Food",
                "id": "xxx",
                "name": "xxx"
            },
            {
                "elementType": "Device",
                "id": "xxx",
                "name": "xxx"
            }
        ],
        "space": {
            "id": "xxx",
            "name": "xxx",
            "coordinates": {
                "latitude": "40.753°N",
                "longitude": "73.983°W"
            }
        },
        "activity": {
            "id": "xxxx",
            "name": "xxxx"
        }
    }
}
```

```sh
Reported Device Heating and Cooking Record for all three modes
{
    "msgType": "rpc",
    "msgId": "be0e673667364c3f8bc31df5338a948a",
    "timestamp": 1604396382112,
    "deviceUuid": "5103c97f33fa4dd79c6c57f4beca3e3e",
    "businessName": "hwm",
    "command": "cooking_record_info",
    "params": {
        "cookingRecord": {
            "actualCookingTime": 4,
            "actualStageQuantity": 0,
            "cookingEndTime": 1716343498448,
            "cookingRecordId": 459164751631614140,
            "cookingResult": 2,
            "cookingSourceType": 1,
            "cookingStartTime": 1716343492991,
            "cookingType": 3,
            "foodName": "",
            "ifOnline": 0,
            "isExpanded": false,
            "msgBizId": "",
            "targetCookingTime": 30,
            "targetStageQuantity": 1,
            "createTime": 1716343492991,
            "createUserId": 10000,
            "createUserName": "万得厨机器人"
        },
        "cookingRecordStageReqDtoList": [
            {
                "actualExecutionTime": 4,
                "cookingRecordId": 459164751631614140,
                "cookingRecordStageId": 128798131226337310,
                "remainTime": 30,
                "stage": 0,
                "stageName": "",
                "stageSkip": false,
                "targetExecutionTime": 30,
                "targetPower": 200,
                "createTime": 1716343493020,
                "createUserId": 10000,
                "createUserName": "万得厨机器人"
            }
        ],
        "sync_data_id": 933839780683510400,
        "sn": "",
        "appVersion": "consume"
    },
    "topsea": {
        "organization": {
            "id": "xxx",
            "name": "xxx"
        },
        "person": {
            "id": "xxx",
            "name": "xxx"
        },
        "elements": [
            {
                "elementType": "Food",
                "id": "xxx",
                "name": "xxx"
            },
            {
                "elementType": "Device",
                "id": "xxx",
                "name": "xxx"
            }
        ],
        "space": {
            "id": "xxx",
            "name": "xxx",
            "coordinates": {
                "latitude": "40.753°N",
                "longitude": "73.983°W"
            }
        },
        "activity": {
            "id": "xxxx",
            "name": "xxxx"
        }
    }
}

```
---
Contributor: Vijayapradap M (vijayapradap.m@happiestminds.com)

