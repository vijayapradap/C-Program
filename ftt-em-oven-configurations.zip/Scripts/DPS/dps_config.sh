#!/bin/bash

# Function to check for internet connectivity
# Function to check for internet connectivity
check_internet() {
  if wget -q --spider http://bing.com; then
    return 0
  elif wget -q --spider http://google.com; then
    return 0
  elif wget -q --spider http://baidu.com; then
    return 0
  else
    response=$(curl -s -o /dev/null -w "%{http_code}" "https://api-az-dev.yingzi.com/ftt-iot-certificatemanagement/health")
    # Check if the response code is 200
    if [ "$response" -eq 200 ]; then
        return 0
    else
        return 1
    fi
  fi
}

# Check for internet connectivity
if ! check_internet; then
  echo "No internet connection. Exiting."
  exit 1
fi

# Ensure the device config file exists
DEVICE_CONFIG_FILE="/etc/smart_oven/config/dps_config.json"

if [ ! -f "$DEVICE_CONFIG_FILE" ]; then
  echo "Device config file $DEVICE_CONFIG_FILE does not exist."
  exit 1
fi

# Extract the registration ID, id_scope, global_endpoint, and cert_endpoint from the device config file
REGISTRATION_ID=$(jq -r '.registration_id' "$DEVICE_CONFIG_FILE")
DEVICE_TYPE=$(jq -r '.devicetype' "$DEVICE_CONFIG_FILE")
ID_SCOPE=$(jq -r '.id_scope' "$DEVICE_CONFIG_FILE")
GLOBAL_ENDPOINT=$(jq -r '.global_endpoint' "$DEVICE_CONFIG_FILE")
CERT_ENDPOINT=$(jq -r '.cert_endpoint' "$DEVICE_CONFIG_FILE")
CERT_RENEWAL_ENDPOINT=$(jq -r '.cert_renewal_endpoint' "$DEVICE_CONFIG_FILE")


if [ -z "$REGISTRATION_ID" ] || [ -z "$ID_SCOPE" ] || [ -z "$GLOBAL_ENDPOINT" ] || [ -z "$CERT_ENDPOINT" ]; then
  echo "REGISTRATION_ID, ID_SCOPE, GLOBAL_ENDPOINT, or CERT_ENDPOINT not found in $DEVICE_CONFIG_FILE."
  exit 1
fi

# Paths to the certificate files
CERT_PEM="/etc/smart_oven/certs/dev_cert.pem"
CERT_KEY="/etc/smart_oven/certs/dev_cert.key"

# Check if certificates already exist
if [ -f "$CERT_PEM" ] && [ -f "$CERT_KEY" ]; then
  echo "Certificates already exist. No need to download again."
  exit 0
fi

# Path to the config.toml file
CONFIG_FILE="/etc/smart_oven/config/dps.toml"

# Check if the config file exists
if [ ! -f "$CONFIG_FILE" ]; then
  echo "Config file $CONFIG_FILE does not exist."
  exit 1
fi

# Update registration_id, id_scope, and global_endpoint in the config file
sudo sed -i "s/^registration_id = .*/registration_id = \"$REGISTRATION_ID\"/" "$CONFIG_FILE"
sudo sed -i "s/^id_scope = .*/id_scope = \"$ID_SCOPE\"/" "$CONFIG_FILE"
sudo sed -i "s|^global_endpoint = .*|global_endpoint = \"$GLOBAL_ENDPOINT\"|" "$CONFIG_FILE"

# Check if sed command was successful
if [ $? -eq 0 ]; then
  echo "Updated $CONFIG_FILE with registration_id = $REGISTRATION_ID, id_scope = $ID_SCOPE, and global_endpoint = $GLOBAL_ENDPOINT"
else
  echo "Failed to update $CONFIG_FILE"
  exit 1
fi

#echo "$CERT_ENDPOINT?deviceId=$REGISTRATION_ID&deviceType=$DEVICE_TYPE&certificateType=DEVICE"

CERT_PEM_URL="$CERT_ENDPOINT?deviceId=$REGISTRATION_ID&deviceType=$DEVICE_TYPE&certificateType=DEVICE"
CERT_KEY_URL="$CERT_ENDPOINT?deviceId=$REGISTRATION_ID&deviceType=$DEVICE_TYPE&certificateType=PRIVATE_KEY"

 
# Function to download a certificate
download_certificate() {
  local url=$1
  local output_file=$2

  sudo curl  -o "$output_file" -w "%{http_code}" "$url"
  local http_status=$(sudo curl -s -o "$output_file" -w "%{http_code}" "$url")
 
  if [ "$http_status" -ne 200 ]; then
    echo "Failed to download certificate from $url. HTTP status: $http_status"
    sudo rm "$CERT_PEM"
    return 1
  elif [ ! -s "$output_file" ]; then
    echo "Downloaded certificate from $url is empty."
    return 1
  fi
 
  return 0
}

#echo "$CERT_RENEWAL_ENDPOINT?deviceId=$REGISTRATION_ID&deviceType=$DEVICE_TYPE"

download_certificate "$CERT_PEM_URL" "$CERT_PEM"
if [ $? -ne 0 ]; then
  echo "Failed to download device certificate."
  exit 1
fi
 
download_certificate "$CERT_KEY_URL" "$CERT_KEY"
if [ $? -ne 0 ]; then
  echo "Failed to download private key."
  exit 1
fi


# Apply the IoT Edge configuration
sudo iotedge config apply -c "$CONFIG_FILE"

# Check if the iotedge command was successful
if [ $? -eq 0 ]; then
  echo "IoT Edge configuration applied successfully."
else
  echo "Failed to apply IoT Edge configuration."
  exit 1
fi

# Check if Renewal is true or false
if jq '.dps_provisioning' "$DEVICE_CONFIG_FILE" | grep -q true; then
  echo "dps provisioning is already true."
else
  # Update Renewal to true
sudo jq '.dps_provisioning = true' "$DEVICE_CONFIG_FILE" > tmp.$$.json && sudo mv tmp.$$.json "$DEVICE_CONFIG_FILE"
  echo "Renewal has been updated to true."
fi

sudo chmod 777 /etc/smart_oven/config/dps_config.json




