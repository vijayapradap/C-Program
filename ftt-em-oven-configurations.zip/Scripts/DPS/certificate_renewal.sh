#!/bin/bash

# Ensure the script itself has no carriage returns
sed -i 's/\r$//' "$0"

# Paths to device configuration and certificates
DEVICE_CONFIG_FILE="/etc/smart_oven/config/dps_config.json"
CERT_PEM="/etc/smart_oven/certs/dev_cert.pem"
CERT_KEY="/etc/smart_oven/certs/dev_cert.key"

# Ensure the device config file exists
if [ ! -f "$DEVICE_CONFIG_FILE" ]; then
  echo "Device config file $DEVICE_CONFIG_FILE does not exist."
  exit 1
fi

# Extract values from the config file using jq
REGISTRATION_ID=$(jq -r '.registration_id' "$DEVICE_CONFIG_FILE")
DEVICE_TYPE=$(jq -r '.devicetype' "$DEVICE_CONFIG_FILE")
ID_SCOPE=$(jq -r '.id_scope' "$DEVICE_CONFIG_FILE")
GLOBAL_ENDPOINT=$(jq -r '.global_endpoint' "$DEVICE_CONFIG_FILE")
CERT_ENDPOINT=$(jq -r '.cert_endpoint' "$DEVICE_CONFIG_FILE")
CERT_RENEWAL_ENDPOINT=$(jq -r '.cert_renewal_endpoint' "$DEVICE_CONFIG_FILE")

# Define URLs for downloading the certificates
CERT_PEM_URL="${CERT_ENDPOINT}?deviceId=${REGISTRATION_ID}&deviceType=${DEVICE_TYPE}&certificateType=DEVICE"
CERT_KEY_URL="${CERT_ENDPOINT}?deviceId=${REGISTRATION_ID}&deviceType=${DEVICE_TYPE}&certificateType=PRIVATE_KEY"

# Check if the certificates directory exists
CERT_DIR=$(dirname "$CERT_PEM")
if [ ! -d "$CERT_DIR" ]; then
  echo "Certificates directory $CERT_DIR does not exist."
  exit 1
fi

# Check if the certificate files exist
if [ ! -f "$CERT_PEM" ]; then
  echo "Certificate file $CERT_PEM does not exist."
  exit 1
fi

if [ ! -f "$CERT_KEY" ]; then
  echo "Key file $CERT_KEY does not exist."
  exit 1
fi

# Function to check for internet connectivity
check_internet() {
  if wget -q --spider http://bing.com; then
    return 0
  elif wget -q --spider http://google.com; then
    return 0
  elif wget -q --spider http://baidu.com; then
    return 0
  else
    response=$(curl -s -o /dev/null -w "%{http_code}" "https://api-az-dev.yingzi.com/ftt-iot-certificatemanagement/health")
    # Check if the response code is 200
    if [ "$response" -eq 200 ]; then
        return 0
    else
        return 1
    fi
  fi
}

# Function to download a certificate
download_certificate() {
  local url=$1
  local output_file=$2

  local http_status
  http_status=$(sudo curl -o "$output_file" -w "%{http_code}" "$url")

  if [ "$http_status" -ne 200 ] || [ ! -s "$output_file" ]; then
    echo "Failed to download certificate from $url. HTTP status: $http_status"
    sudo rm -f "$output_file"
    return 1
  fi
  return 0
}

# Function to check the certificate expiration
check_certificate() {
  local not_after
  not_after=$(openssl x509 -noout -text -in "$CERT_PEM" | grep -E 'Not After' | sed -E 's/^ *Not After : //')
 

  local not_after_timestamp
  not_after_timestamp=$(date -d "$not_after" +%s)
  local current_date_secs
  current_date_secs=$(date -u +%s)

  if [ "$current_date_secs" -gt "$not_after_timestamp" ]; then
    echo "Certificate expired on: $not_after"
    return 1
  else
    echo "Certificate is valid until: $not_after"
    return 0
  fi
}

# Function to handle certificate renewal and re-download
handle_certificate_redownload() {
  if ! check_internet; then
    echo "No internet connection. Exiting."
    exit 1
  fi

  echo "Removing old certificates..."
  sudo rm -f "$CERT_PEM" "$CERT_KEY"

  echo "Requesting certificate renewal..."
  sudo curl -X PUT -H "Content-Length: 0" "${CERT_RENEWAL_ENDPOINT}?deviceId=${REGISTRATION_ID}&deviceType=${DEVICE_TYPE}"

  echo "Downloading new certificate from $CERT_PEM_URL"
  # Download new certificates
  download_certificate "$CERT_PEM_URL" "$CERT_PEM"
  if [ $? -ne 0 ]; then
    echo "Failed to download device certificate."
    exit 1
  fi

  echo "Downloading new key from $CERT_KEY_URL"
  download_certificate "$CERT_KEY_URL" "$CERT_KEY"
  if [ $? -ne 0 ]; then
    echo "Failed to download private key."
    exit 1
  fi

}

# Continuous check with an interval
if ! check_certificate; then
  handle_certificate_redownload
fi

# Check if DeviceTypeCertRenewed is true and handle renewal
if jq '.isDeviceTypeCertRenewed' "$DEVICE_CONFIG_FILE" | grep -q true; then
  echo "Renewing intermediate certificates..."
  handle_certificate_redownload
  sudo jq '.deviceCertRenewed = true' "$DEVICE_CONFIG_FILE" > tmp.$$.json && sudo mv tmp.$$.json "$DEVICE_CONFIG_FILE"
else
  echo "Intermediate certificates are not expired."
fi



